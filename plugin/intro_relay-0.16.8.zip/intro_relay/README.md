# Intro Relay (plugin de Dispatcharr)

Muestra una intro (imagen o vídeo) mientras arranca un canal y, cuando el canal real empieza a emitir,
lo empalma en el mismo stream sin cortes. Pensado para canales "on demand" que tardan en arrancar.

Probado con Dispatcharr 0.32.0 y la conversión que hace Emby 4.11 para Fire TV (ffmpeg de Emby).

## Qué hace

- Añade a cada canal una fuente «Intro (relevo)» y la pone **la primera**. Las fuentes originales siguen
  detrás, en su orden.
- Al pedir el canal, el relevo pide a Dispatcharr la primera fuente original:
  - el canal cuenta como «listo» cuando llega su primer fotograma clave de vídeo (no basta con audio o
    relleno, que algunas fuentes envían mucho antes que la imagen);
  - si está listo en menos de *Espera antes de mostrar la intro* (4 s), lo pasa directamente, sin intro;
  - si tarda, envía la intro (los primeros 6 s de golpe para que Dispatcharr y Emby arranquen enseguida,
    luego a tiempo real) y, cuando el canal está listo, corta la intro en un fotograma completo y
    empalma el canal con tiempos continuos y marca de discontinuidad MPEG-TS;
  - si una fuente falla antes de arrancar, prueba la siguiente del canal sin cortar la intro.
- El canal sale siempre con el mismo formato que la intro, para que nada cambie en el empalme:

  | PID | Pista |
  |---|---|
  | 0x100 | vídeo H.264 |
  | 0x101 | audio AAC `spa`: la pista `spa`/`esp`/`cas`…; si no hay, una sin idioma; si no, otra que no sea versión original ni audiodescripción |
  | 0x102 | audio AAC `qaa`: la versión original (`qaa`, `vo`, `vos`, `ov`); si no hay, otra pista que no sea audiodescripción; si no, copia de `spa` |
  | 0x103 | audio AAC `ads`: la audiodescripción (`ads`/`qad`); si no hay, copia de `spa` |

  Copiar una pista no recodifica. Solo se convierte a AAC una pista que venga en otro códec (AC3, MP2…).
- El canal empieza siempre en una imagen IDR (las de arranque). Muchas emisiones de difusión (UDP del operador)
  marcan como fotograma clave imágenes I que no lo son; empezar ahí deja en negro a los clientes que reciben HLS sin
  transcodificar, porque las cabeceras del vídeo del canal no pueden sustituir a las de la intro en esa imagen.
  Si una fuente no envía ninguna IDR en 8 s, se empieza en el siguiente fotograma clave y se avisa en el log.
- Las fuentes se prueban en el orden que tienen en el canal, y se saltan las mismas que salta Dispatcharr: las de
  una lista M3U desactivada (o sin su perfil por defecto activo). El registro anota en cada apertura la lista usada.
- La intro (y el vídeo de reconexión) se generan 16 píxeles más estrechos que el canal (ajuste *Intro más estrecha
  que el canal*; 0 = misma resolución). Los reproductores de
  navegador (hls.js, el de Emby web) solo cambian a las cabeceras del vídeo del canal si cambia la resolución;
  con la misma, la imagen se quedaba parada al terminar la intro en HLS sin transcodificar.
- Si el relevo está caído, Dispatcharr salta solo a la fuente original (el canal se ve sin intro), y el
  evento de inicio de canal vuelve a arrancar el relevo.

## Instalar

1. En Dispatcharr: *Plugins → Importar* y elige `intro-relay-<versión>.zip` (o descomprímelo en
   `/data/plugins/`).
2. Activa el plugin y rellena *Imagen o vídeo de la intro* con una ruta del volumen de datos,
   por ejemplo `/data/intro.png`.
3. Pulsa **Aplicar**.

## Ajustes

| Ajuste | Por defecto | Qué hace |
|---|---|---|
| Imagen o vídeo de la intro | | Ruta dentro del volumen de datos de Dispatcharr |
| Canales con intro | vacío | Un nombre o número por línea. **Vacío (y sin grupos) = todos los canales** |
| Grupos con intro | vacío | Un grupo por línea; se suma a la lista de canales |
| Ancho / Alto / FPS | 1920×1080, 25 | Mejor igual que tus canales |
| Intro más estrecha que el canal | 16 px | Para que el navegador no se pare tras la intro; 0 = misma resolución |
| Espera antes de mostrar la intro | 4 s | Si el canal llega antes, no hay intro |
| Espera máxima del canal | 90 s | Después se corta y Dispatcharr pasa a la fuente original |
| Puerto local del relevo | 9722 | Dentro del contenedor |
| Dirección interna de Dispatcharr | http://127.0.0.1:9191 | Donde el relevo pide las fuentes originales |
| Aplicar a los canales nuevos | sí | Tras cada actualización de las listas M3U |

Botones: **Aplicar**, **Estado**, **Revisar canales** (también tras cada actualización M3U),
**Arrancar el relevo si está parado** (también al empezar cualquier canal; un relevo en marcha no se
reinicia nunca desde aquí, aunque vaya cargado) y **Quitar la intro** (deja los canales como
estaban).

## Una sesión, un proceso

Cada espectador se atiende en un proceso propio del relevo. Si una sesión se cuelga o se cae, solo se corta esa.
Al pulsar Aplicar o instalar una versión nueva del plugin solo se renueva el proceso principal: las sesiones en
curso siguen con el suyo hasta que el espectador cierra el canal, y las nuevas entran ya con la versión nueva.

## Salida HLS para Emby (opcional)

Con el ajuste **Salida HLS para Emby**, el relevo sirve cada canal también en HLS, troceando lo mismo que sale
por MPEG-TS (intro, empalme, reconexiones) sin convertir el vídeo. En Emby, la URL del sintonizador M3U pasa a
ser `http://<IP de la máquina>:9722/h/lista.m3u` (la lista de Dispatcharr con cada canal apuntando a su HLS; la
guía sigue igual). El puerto 9722 tiene que estar publicado en Docker. Cada apertura de un canal es una sesión
HLS propia (su proceso y su conexión con Dispatcharr) y se cierra a los 25 s sin peticiones. El relevo escucha
entonces en todas las interfaces y no tiene contraseña: solo para la red local.

## Idiomas de las pistas en HLS

Si Dispatcharr entrega HLS (versiones con live_proxy), el plugin hace que la primera petición de la lista de cada
sesión reciba una lista maestra con el idioma de cada pista de audio, leído de la tabla PMT del propio stream. El
ffmpeg de Emby (5.1) no toma el idioma de los segmentos HLS, pero sí el declarado en la lista maestra. El relevo
pide sus fuentes a Dispatcharr con ?output_format=ts, sea cual sea el formato que Dispatcharr entregue a Emby.

## A tener en cuenta

- Cada espectador sigue ocupando una sola conexión con el proveedor: el relevo pide la fuente original a
  Dispatcharr, que reserva la conexión y respeta los límites de la cuenta M3U.
- Dispatcharr cuenta cada fuente personalizada como un sintonizador más en la emulación HDHomeRun, así que
  Emby verá más sintonizadores (uno por canal con intro). No cambia el límite real del proveedor.
- La intro se codifica una vez a tasa fija (8 Mbit/s, por el búfer de ~1 MB que Dispatcharr acumula antes
  de entregar nada) y se guarda en `.runtime/cache`. Ese caudal solo se usa mientras dura la intro.
- Registro del relevo: `.runtime/relay.log` dentro de la carpeta del plugin.

## Solo normalización del audio (0.9.0)

Con **Intro y vídeo de reconexión** desactivado (lo normal desde la 0.9.0), el relevo no envía intro ni vídeo de reconexión: solo reenvía cada canal con las pistas fijas (vídeo 0x100; audio SPA 0x101, QAA 0x102, ADS 0x103 en AAC), y reconecta en silencio si se pierde la fuente. Pulsa **Aplicar** tras cambiar el ajuste.

## Intro con las cabeceras del canal (0.10.0)

Cada canal H.264 tiene su propia versión de la intro hecha con sus **cabeceras de vídeo exactas** (los mismos bytes de
SPS y PPS). x264 codifica la intro de forma compatible (misma codificación entrópica, transformada 8x8, entrelazado y
desplazamiento de croma, sin fotogramas B) y `irelay/h264.py` le pone el SPS/PPS del canal y reescribe la cabecera de
cada porción de imagen. Para el decodificador del cliente la intro y el canal son la misma secuencia de vídeo: en el
empalme no hay nada que reconfigurar. Antes de usarla se comprueba que se decodifica sin un solo error; si no se puede
(no H.264, 10 bits, matrices propias...), se usa la intro de siempre con el formato del canal.

La **primera reproducción de cada fuente** va sin intro: se espera al canal (tarde lo que tarde) y sale directo, sin
empalme, mientras se guardan sus cabeceras y se prepara su intro. Desde la segunda, intro con sus cabeceras exactas.
No se abre ninguna conexión de más ni se deducen cabeceras de otros canales.

Mientras se espera a un canal sin intro (primera vez, modo sin intro o reconexión sin vídeo) el relevo manda
paquetes nulos MPEG-TS cada segundo: Dispatcharr salta a la siguiente fuente si una no manda nada en 8 s
(`stream_startup_timeout`), y los reproductores descartan esos paquetes.

## Pistas de audio fijas (0.12.0)

Todos los canales (y todas las intros) llevan siempre las mismas pistas, las del ajuste **Pistas de audio** (por
defecto `spa, qaa, ads, qcb, qcc, qcd, qce`), en PID 0x101, 0x102... Cada una lleva la pista del canal con ese idioma
si la tiene en ese momento; si no, una copia de la española. Si el canal añade o quita pistas a mitad de emisión (un
partido con comentarios alternativos), el relevo lo nota en su tabla de pistas y en la siguiente imagen clave vuelve a
repartirlas, sin hueco de imagen: la lista de pistas que ve Emby no cambia nunca.

## Subtítulos (0.13.0)

La salida lleva siempre una pista de subtítulos DVB, «spa» para sordos, en el PID 0x120 (vacía si el canal no trae).
Los subtítulos DVB del canal (los de la TDT, marcados «srd») se pasan a la página que declara la
tabla fija (cada fuente usa la suya). La tabla de pistas (PMT) la escribe siempre el relevo, idéntica en la intro, en
el canal y en todos los canales. En la salida HLS para Emby los subtítulos van en la lista del vídeo.

## Subtítulos legibles por el OCR de Emby (0.15.0)

Emby (4.11 con el parche `subtitles-ocr-keep-codec` de emby-parched) pasa los subtítulos DVB a texto con su OCR y
los da a sus apps en la lista HLS. Su OCR lee región a región, así que el relevo le da cada frase en una sola imagen:

- **Subtítulos DVB de la TDT:** algunas cadenas (La 1) parten cada línea en dos tiras (mitad de arriba y mitad de
  abajo de las letras) y el OCR se inventa la frase. El relevo pinta la página como el reproductor y la vuelve a
  mandar como una sola región con la misma paleta: se ve igual y se lee entera. Si una fuente manda algo que no
  sabe rehacer (regiones de 2 u 8 bits, varias paletas), los deja tal cual.
- **Subtítulos de texto de las fuentes DRM** (AXN, Comedy Central...): traen la frase como texto plano, sin idioma
  y sin final (el idioma y las frases enteras están en las pistas WebVTT de su lista maestra HLS). El relevo lee esa
  lista mientras se ve el canal (como un reproductor: la lista cada 2 s y solo los segmentos nuevos; va de 2 a 14 s
  por delante del TS) y le pone a cada frase su final real; si no la encuentra, una duración según su longitud. Las
  frases van en su PID (0x121, 0x122...) con su inicio, final y texto (`irelay/cues.py`), y la salida HLS las sirve
  como pistas de subtítulos WebVTT de la lista maestra, con su idioma: Emby las da a sus apps como texto, sin OCR
  y sin recodificar nada. Las que la fuente reenvía al empezar cada segmento no se repiten.
- **Nombre e idioma en Emby (subtítulos DVB):** el ffmpeg de Emby pierde el idioma de los subtítulos que van dentro de los segmentos
  HLS, pero no su página DVB. El relevo pone el idioma en la página (0x8000 | letra1 << 10 | letra2 << 5 | letra3,
  a = 1 ... z = 26; «spa» = 0xCE01) y el parche `dvb-subtitle-language` de emby-parched lo recupera al analizar el
  canal, con la marca «para sordos» si el tipo es 0x20-0x25: salen como «Español (SDH)», «Español», «Inglés»...
  Sin ese parche se ven igual, solo que sin idioma. En Emby conviene desmarcar «Negrita» en el reconocimiento del
  OCR: si no, mete `<b>` sueltas.

Cada
canal lleva en su tabla de pistas solo los subtítulos que tiene (los de la fuente con que empieza la sesión).

