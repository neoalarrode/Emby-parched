"""Intro Relay para Dispatcharr: intro mientras arranca el canal y empalme limpio con el canal real."""
from __future__ import annotations

import json
import sys
from pathlib import Path

_BASE = Path(__file__).resolve().parent
if str(_BASE) not in sys.path:
    sys.path.insert(0, str(_BASE))

from irelay import channels, hlslang, intro, process, sessions, slots  # noqa: E402

_MANIFEST = json.loads((_BASE / "plugin.json").read_text(encoding="utf-8"))

# Dispatcharr importa los plugins en cada proceso al arrancar: aquí se instalan las sesiones independientes
# (se activan o desactivan con el ajuste, sin reiniciar).
sessions.install(_BASE.name.replace(" ", "_").lower())
try:
    hlslang.install()   # idioma de cada pista de audio en la salida HLS de Dispatcharr (para el ffmpeg de Emby)
except Exception:
    pass
process.ensure_on_boot(_BASE.name.replace(" ", "_").lower(), lambda settings: Plugin()._apply(settings))


def _num(settings: dict, key: str, default: float) -> float:
    try:
        return float(settings.get(key, default))
    except (TypeError, ValueError):
        return default


def _proxy_profile_id() -> int | None:
    from core.models import StreamProfile

    profile = StreamProfile.objects.filter(name__iexact="Proxy").first()
    return profile.id if profile else None


class Plugin:
    name = _MANIFEST["name"]
    version = _MANIFEST["version"]
    description = _MANIFEST["description"]
    fields = _MANIFEST["fields"]
    actions = _MANIFEST["actions"]

    def _cover(self, settings: dict) -> dict:
        port = int(_num(settings, "port", 9722))
        ids = channels.target_channel_ids(settings.get("channels"), settings.get("groups"))
        result = channels.sync(f"http://127.0.0.1:{port}", ids, _proxy_profile_id())
        return {"canales": len(ids), **result}

    def _apply(self, settings: dict) -> dict:
        port = int(_num(settings, "port", 9722))
        layout = slots.parse_layout(settings.get("audio_tracks"))
        process.RUNTIME.mkdir(parents=True, exist_ok=True)
        (process.RUNTIME / "idiomas.json").write_text(json.dumps(slots.parse_overrides(settings.get("audio_overrides"))))
        common = ["--audio", ",".join(layout),"--max-wait", str(int(_num(settings, "max_wait", 90))),
                  "--reconnect-wait", str(int(_num(settings, "reconnect_wait", 300))),
                  "--stall", str(_num(settings, "stall_seconds", 4)),
                  "--dispatcharr-url", str(settings.get("dispatcharr_url") or "http://127.0.0.1:9191"),
                  *(["--hls", "--listen", "0.0.0.0"] if settings.get("hls_output") else [])]
        if not settings.get("intro_enabled", False):
            # Solo normalización del audio (huecos SPA/QAA/ADS, E-AC-3 a AAC): sin intro ni vídeo de reconexión
            process.start(["--no-intro", "--fps", str(int(_num(settings, "fps", 25))), "--cushion", "0", *common], port)
            result = self._cover(settings)
            return {"status": "ok", "message": "Normalización del audio aplicada (sin intro)", **result}
        media = Path(str(settings.get("media_source") or "").strip())
        if not media.is_file():
            return {"status": "error", "message": f"No encuentro la imagen o vídeo de la intro: {media}"}
        fps = int(_num(settings, "fps", 25))
        options = intro.IntroOptions(width=int(_num(settings, "width", 1920)),
                                     height=int(_num(settings, "height", 1080)), fps=fps,
                                     profile=str(settings.get("h264_profile") or "main"),
                                     level=str(settings.get("h264_level") or "4.0"), audio=tuple(layout))
        reconnect_media = Path(str(settings.get("reconnect_source") or "").strip() or str(media))
        if not reconnect_media.is_file():
            return {"status": "error", "message": f"No encuentro el vídeo de reconexión: {reconnect_media}"}
        # Las rutas de los vídeos quedan guardadas: el relevo las necesita para preparar las versiones de la intro
        # con el formato de cada canal, lo arranque quien lo arranque
        process.RUNTIME.mkdir(parents=True, exist_ok=True)
        (process.RUNTIME / "sources.json").write_text(json.dumps({"intro": str(media),
                                                                  "reconnect": str(reconnect_media)}))
        clip = intro.build(media, process.RUNTIME / "cache", options)
        reconnect = intro.build(reconnect_media, process.RUNTIME / "cache", options)
        process.start(["--intro", str(clip), "--reconnect", str(reconnect), "--fps", str(fps),
                       "--instant", str(_num(settings, "instant_seconds", 6)),
                       "--min-intro", str(_num(settings, "min_intro_seconds", 8)),
                       "--cushion", str(_num(settings, "cushion_seconds", 10)),
                       "--intro-narrower", str(int(_num(settings, "intro_narrower", 16))),
                       "--intro-src", str(media), "--reconnect-src", str(reconnect_media), *common], port)
        intro.cleanup(process.RUNTIME / "cache", {clip, reconnect})
        result = self._cover(settings)
        return {"status": "ok", "message": "Intro aplicada", **result}

    def run(self, action: str, params: dict, context: dict):
        settings = context.get("settings", {}) or {}
        logger = context.get("logger")
        port = int(_num(settings, "port", 9722))

        if action == "apply":
            result = self._apply(settings)
            if logger:
                logger.info("Intro Relay aplicado: %s", result)
            return result

        if action == "cover":
            if params.get("event") and not settings.get("auto_cover", True):
                return {"status": "ok", "message": "Aplicar a canales nuevos está desactivado"}
            return {"status": "ok", **self._cover(settings)}

        if action == "ensure":
            if not process.needs_start():
                return {"status": "ok", "message": "El relevo ya estaba en marcha"}
            return self._apply(settings)

        if action == "status":
            return {"status": "ok", "relevo": "en marcha" if process.healthy(port) else "parado",
                    "canales_con_intro": channels.covered_count()}

        if action == "remove":
            removed = channels.remove_all()
            process.stop(sessions=True)
            return {"status": "ok", "message": f"Intro quitada de {removed} canales"}

        return {"status": "error", "message": f"Acción desconocida: {action}"}

    def stop(self, context: dict) -> None:
        process.stop()
