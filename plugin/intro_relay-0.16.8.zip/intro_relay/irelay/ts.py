"""Lectura mínima de MPEG-TS: lo justo para cortar la intro en un punto limpio y saber dónde acaban sus tiempos."""
from __future__ import annotations

PACKET = 188
NULL_PID = 0x1FFF
CLOCK = 90000


def pid_of(packet: bytes) -> int:
    return ((packet[1] & 0x1F) << 8) | packet[2]


def pusi(packet: bytes) -> bool:
    return bool(packet[1] & 0x40)


def payload(packet: bytes) -> bytes:
    afc = (packet[3] >> 4) & 0x3
    if afc == 1:
        return packet[4:]
    if afc == 3:
        return packet[5 + packet[4]:]
    return b""


def pes_pts(first_packet: bytes) -> int | None:
    """PTS del PES que empieza en este paquete (con PUSI), en unidades de 90 kHz."""
    data = payload(first_packet)
    if len(data) < 14 or data[0:3] != b"\x00\x00\x01" or not (data[7] & 0x80):
        return None
    p = data[9:14]
    return ((p[0] >> 1) & 0x07) << 30 | p[1] << 22 | (p[2] >> 1) << 15 | p[3] << 7 | p[4] >> 1


def pes_dts(first_packet: bytes) -> int | None:
    """DTS del PES (o su PTS si no lleva DTS aparte)."""
    data = payload(first_packet)
    if len(data) < 19 or data[0:3] != b"\x00\x00\x01" or (data[7] & 0xC0) != 0xC0:
        return pes_pts(first_packet)
    p = data[14:19]
    return ((p[0] >> 1) & 0x07) << 30 | p[1] << 22 | (p[2] >> 1) << 15 | p[3] << 7 | p[4] >> 1


def adts_frames(pes_payload: bytes) -> int:
    """Número de tramas AAC (ADTS) en el contenido de un PES de audio."""
    if len(pes_payload) < 9 or pes_payload[0:3] != b"\x00\x00\x01":
        return 0
    i = 9 + pes_payload[8]
    frames = 0
    while i + 7 <= len(pes_payload) and pes_payload[i] == 0xFF and (pes_payload[i + 1] & 0xF0) == 0xF0:
        length = ((pes_payload[i + 3] & 0x03) << 11) | (pes_payload[i + 4] << 3) | (pes_payload[i + 5] >> 5)
        if length < 7:
            break
        frames += 1
        i += length
    return frames


def pmt_pids(data: bytes) -> set[int] | None:
    """PIDs de PMT anunciados en una PAT (si el paquete la contiene)."""
    if pid_of(data) != 0 or not pusi(data):
        return None
    p = payload(data)
    if not p:
        return None
    sec = p[1 + p[0]:]
    if len(sec) < 8 or sec[0] != 0x00:
        return None
    length = ((sec[1] & 0x0F) << 8) | sec[2]
    body = sec[8:3 + length - 4]
    pids = set()
    for k in range(0, len(body) - 3, 4):
        program = (body[k] << 8) | body[k + 1]
        if program != 0:
            pids.add(((body[k + 2] & 0x1F) << 8) | body[k + 3])
    return pids


VIDEO_TYPES = {0x01, 0x02, 0x1B, 0x24}     # MPEG-1/2, H.264, HEVC


def pmt_video_pid(packet: bytes) -> int | None:
    """PID de vídeo anunciado en un paquete de PMT; -1 si es una PMT sin vídeo (radio); None si no es una PMT."""
    info = pmt_video(packet)
    return info if info is None or info == -1 else info[0]


def pmt_video(packet: bytes) -> tuple[int, int] | int | None:
    """(PID, tipo de pista) del vídeo anunciado en un paquete de PMT; -1 sin vídeo; None si no es una PMT."""
    if not pusi(packet):
        return None
    p = payload(packet)
    if not p:
        return None
    sec = p[1 + p[0]:]
    if len(sec) < 12 or sec[0] != 0x02:
        return None
    length = ((sec[1] & 0x0F) << 8) | sec[2]
    info_len = ((sec[10] & 0x0F) << 8) | sec[11]
    i, end = 12 + info_len, min(3 + length - 4, len(sec))
    while i + 5 <= end:
        stream_type = sec[i]
        pid = ((sec[i + 1] & 0x1F) << 8) | sec[i + 2]
        if stream_type in VIDEO_TYPES:
            return pid, stream_type
        i += 5 + (((sec[i + 3] & 0x0F) << 8) | sec[i + 4])
    return -1


def pes_es(first_packet: bytes) -> bytes:
    """Contenido (sin la cabecera PES) del primer paquete de un PES."""
    data = payload(first_packet)
    if len(data) < 9 or data[0:3] != b"\x00\x00\x01":
        return b""
    return data[9 + data[8]:]


def es_of(data: bytes, pid: int, limit: int = 4 * 1024 * 1024) -> bytes:
    """Contenido (sin cabeceras PES) de un PID en un trozo de MPEG-TS, hasta `limit` bytes."""
    out = bytearray()
    for i in range(0, len(data) - PACKET + 1, PACKET):
        packet = data[i:i + PACKET]
        if packet[0] != 0x47 or pid_of(packet) != pid:
            continue
        if pusi(packet):
            out += pes_es(packet)
        else:
            out += payload(packet)
        if len(out) >= limit:
            break
    return bytes(out)


def video_access(es: bytes, stream_type: int | None) -> str | None:
    """Cómo empieza una imagen, por el contenido de su PES: "idr" si se puede empezar a decodificar ahí sin nada
    anterior (IDR en H.264, IRAP en HEVC, cabecera de secuencia en MPEG-2), "other" si es otra imagen (también un
    fotograma I con punto de recuperación, que no es IDR), None si aún falta contenido para saberlo."""
    i = es.find(b"\x00\x00\x01")
    while 0 <= i < len(es) - 4:
        h = es[i + 3]
        if stream_type in (0x01, 0x02):
            if h == 0xB3:
                return "idr"
            if h == 0x00:                                # imagen sin cabecera de secuencia delante
                return "other"
        elif stream_type == 0x24:
            t = (h >> 1) & 0x3F
            if t < 32:                                   # primera porción de imagen
                return "idr" if 16 <= t <= 21 else "other"
        else:
            t = h & 0x1F
            if 1 <= t <= 5:                              # primera porción de imagen
                return "idr" if t == 5 else "other"
        i = es.find(b"\x00\x00\x01", i + 3)
    return None


def is_keyframe_start(packet: bytes) -> bool:
    """¿Empieza en este paquete (PUSI) un fotograma clave? Por el indicador de acceso aleatorio o por las
    cabeceras del propio vídeo (SPS/IDR en H.264, VPS/SPS/IRAP en HEVC, cabecera de secuencia en MPEG-2)."""
    if not pusi(packet):
        return False
    afc = (packet[3] >> 4) & 0x3
    if afc in (2, 3) and packet[4] > 0 and packet[5] & 0x40:
        return True
    data = payload(packet)
    if len(data) < 9 or data[0:3] != b"\x00\x00\x01":
        return False
    es = data[9 + data[8]:]
    i = es.find(b"\x00\x00\x01")
    while 0 <= i < len(es) - 4:
        h = es[i + 3]
        if h == 0xB3:                                    # MPEG-2: cabecera de secuencia
            return True
        if (h & 0x1F) in (5, 7):                         # H.264: IDR o SPS
            return True
        if ((h >> 1) & 0x3F) in (16, 17, 18, 19, 20, 21, 32, 33):   # HEVC: IRAP, VPS o SPS
            return True
        i = es.find(b"\x00\x00\x01", i + 3)
    return False


class PesCutter:
    """Deja pasar el MPEG-TS de la intro guardando cada PES hasta que está completo, para poder
    cortar en cualquier momento sin dejar ningún fotograma ni trama de audio a medias.
    Calcula el instante en que acaba lo enviado (end_pts) para empalmar después."""

    def __init__(self, video_pid: int, audio_pids: set[int], fps: float, sample_rate: int = 48000):
        self.video_pid = video_pid
        self.audio_pids = set(audio_pids)
        self.frame = CLOCK / fps
        self.aac_frame = CLOCK * 1024 / sample_rate
        self.pending: dict[int, list[bytes]] = {}
        self.end_pts = 0.0
        self.start_pts: float | None = None
        # El audio se envía como mucho hasta donde llega la imagen: el que va por delante espera. Si no, al
        # cortar quedaba audio más allá del último fotograma y el canal empalmaba con un hueco de imagen
        self.video_end = 0.0
        self.held: list[tuple[float, bytes]] = []
        # Tras cada corte: dónde empiezan realmente imagen y audio de lo siguiente (para el log del empalme)
        self.cut_at: float | None = None
        self.splice: dict[str, float] = {}
        self.splice_report: dict[str, float] | None = None
        self._carry = b""

    def _end(self, pid: int, packets: list[bytes]) -> float | None:
        pts = pes_pts(packets[0])
        if pts is None:
            return None
        if self.start_pts is None:
            self.start_pts = pts
        if pid == self.video_pid:
            return pts + self.frame
        return pts + self.aac_frame * max(1, adts_frames(b"".join(payload(p) for p in packets)))

    def media_seconds(self) -> float:
        """Segundos de intro ya entregados (para marcar el ritmo)."""
        return 0.0 if self.start_pts is None else (self.end_pts - self.start_pts) / CLOCK

    def feed(self, data: bytes) -> bytes:
        """Recibe bytes de la intro y devuelve los que ya se pueden enviar."""
        data = self._carry + data
        whole = len(data) - len(data) % PACKET
        self._carry = data[whole:]
        out = bytearray()
        for i in range(0, whole, PACKET):
            packet = data[i:i + PACKET]
            if packet[0] != 0x47:
                continue
            pid = pid_of(packet)
            if pid != self.video_pid and pid not in self.audio_pids:
                out += packet  # PAT, PMT, SDT...: pasan tal cual
                continue
            if pusi(packet):
                done = self.pending.pop(pid, None)
                if done:
                    out += self._release(pid, done)
                self.pending[pid] = [packet]
            elif pid in self.pending:
                self.pending[pid].append(packet)
        return bytes(out)

    def _note_splice(self, pid: int, packets: list[bytes]) -> None:
        pts = pes_pts(packets[0])
        if pts is None:
            return
        key = "video" if pid == self.video_pid else "audio"
        if key not in self.splice:
            self.splice[key] = pts / CLOCK - self.cut_at
            if key == "video":
                self.splice["video_dts"] = (pes_dts(packets[0]) or pts) / CLOCK - self.cut_at
        if "video" in self.splice and "audio" in self.splice:
            self.splice_report, self.cut_at = dict(self.splice), None

    def _release(self, pid: int, packets: list[bytes]) -> bytes:
        if self.cut_at is not None:
            self._note_splice(pid, packets)
        end = self._end(pid, packets)
        data = b"".join(packets)
        if end is None:
            return data
        if pid == self.video_pid:
            self.video_end = max(self.video_end, end)
            self.end_pts = max(self.end_pts, end)
            out = bytearray(data)
            while self.held and self.held[0][0] <= self.video_end:
                audio_end, audio = self.held.pop(0)
                self.end_pts = max(self.end_pts, audio_end)
                out += audio
            return bytes(out)
        if end <= self.video_end and not self.held:
            self.end_pts = max(self.end_pts, end)
            return data
        self.held.append((end, data))
        return b""

    def flush(self) -> bytes:
        """Suelta lo que queda guardado cuando lo que se estaba enviando terminó entero (no a medias): el último
        fotograma y el audio que le corresponde. Después hay que llamar a cut()."""
        pending, self.pending = self.pending, {}
        out = bytearray()
        if self.video_pid in pending:
            out += self._release(self.video_pid, pending.pop(self.video_pid))
        for pid, packets in pending.items():
            out += self._release(pid, packets)
        return bytes(out)

    def cut(self) -> float:
        """Descarta lo que está a medias (y el audio que iba por delante de la imagen) y devuelve dónde
        acaba lo enviado, en segundos."""
        self.pending.clear()
        self.held.clear()
        self._carry = b""
        self.cut_at, self.splice = self.end_pts / CLOCK, {}
        return self.end_pts / CLOCK


WRAP = 1 << 33


def _read_ts(b: bytes) -> int:
    return ((b[0] >> 1) & 0x07) << 30 | b[1] << 22 | (b[2] >> 1) << 15 | b[3] << 7 | b[4] >> 1


def _write_ts(prefix: int, value: int) -> bytes:
    value %= WRAP
    return bytes([(prefix & 0xF0) | ((value >> 29) & 0x0E) | 1, (value >> 22) & 0xFF,
                  ((value >> 14) & 0xFE) | 1, (value >> 7) & 0xFF, ((value << 1) & 0xFE) | 1])


class Retimer:
    """Desplaza todas las marcas de tiempo (PTS, DTS y PCR) del canal para que el primer fotograma se
    decodifique justo donde acaba la intro. Así el empalme es exacto sea cual sea la fuente: sin hueco de
    imagen y sin decodificación hacia atrás (los fotogramas B hacían que una u otra cosa pasara).
    Lo que llega antes del primer fotograma de vídeo se guarda hasta saber el desplazamiento; el audio que
    quedaría antes del corte se descarta (se solaparía con el de la intro)."""

    def __init__(self, video_pid: int, cut_seconds: float, by_pts: bool = False):
        # by_pts: el primer fotograma se presenta justo en el corte (para seguir la misma fuente sin hueco cuando
        # se vuelve a repartir las pistas); si no, se decodifica en el corte (empalme con la intro)
        self.by_pts = by_pts
        self.video_pid = video_pid
        self.cut = int(round(cut_seconds * CLOCK))
        self.delta: int | None = None
        self.pending = bytearray()
        self.drop: dict[int, bool] = {}
        self._carry = b""

    def _shift_packet(self, packet: bytes) -> bytes | None:
        pid = pid_of(packet)
        p = bytearray(packet)
        afc = (p[3] >> 4) & 0x03
        start = 4
        if afc & 0x02:
            af_len = p[4]
            if af_len > 0 and p[5] & 0x10 and af_len >= 7:      # PCR
                base = p[6] << 25 | p[7] << 17 | p[8] << 9 | p[9] << 1 | p[10] >> 7
                base = (base + self.delta) % WRAP
                p[6], p[7], p[8], p[9] = (base >> 25) & 0xFF, (base >> 17) & 0xFF, (base >> 9) & 0xFF, (base >> 1) & 0xFF
                p[10] = ((base & 1) << 7) | (p[10] & 0x7F)
            start = 5 + af_len
        if not (afc & 0x01) or start >= len(p):
            return bytes(p)
        if pusi(packet) and p[start:start + 3] == b"\x00\x00\x01" and len(p) >= start + 14:
            flags = p[start + 7] >> 6
            if flags & 0x02:
                pts = (_read_ts(p[start + 9:start + 14]) + self.delta) % WRAP
                if pid != self.video_pid:
                    # audio que caería antes del corte: fuera (y sus paquetes de continuación)
                    behind = (self.cut - pts) % WRAP
                    self.drop[pid] = 0 < behind < WRAP // 2
                    if self.drop[pid]:
                        return None
                p[start + 9:start + 14] = _write_ts(p[start + 9], pts)
                if flags == 0x03 and len(p) >= start + 19:
                    dts = _read_ts(p[start + 14:start + 19]) + self.delta
                    p[start + 14:start + 19] = _write_ts(p[start + 14], dts)
        elif self.drop.get(pid):
            return None
        return bytes(p)

    def feed(self, data: bytes) -> bytes:
        data = self._carry + data
        whole = len(data) - len(data) % PACKET
        self._carry = data[whole:]
        if self.delta is None:
            self.pending += data[:whole]
            for i in range(0, len(self.pending) - PACKET + 1, PACKET):
                packet = self.pending[i:i + PACKET]
                if pid_of(packet) == self.video_pid and pusi(packet):
                    payload_ = payload(bytes(packet))
                    if len(payload_) >= 14 and payload_[0:3] == b"\x00\x00\x01" and payload_[7] & 0x80:
                        dts = _read_ts(payload_[14:19]) if (payload_[7] >> 6) == 0x03 else _read_ts(payload_[9:14])
                        self.delta = self.cut - (_read_ts(payload_[9:14]) if self.by_pts else dts)
                        break
            if self.delta is None:
                return b""
            data, self.pending = bytes(self.pending), bytearray()
            whole = len(data)
        out = bytearray()
        for i in range(0, whole, PACKET):
            packet = data[i:i + PACKET]
            if packet[0] != 0x47:
                continue
            shifted = self._shift_packet(packet)
            if shifted is not None:
                out += shifted
        return bytes(out)
