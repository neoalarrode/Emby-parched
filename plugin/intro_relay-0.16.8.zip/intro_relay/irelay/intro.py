"""Prepara la intro: un clip MPEG-TS corto con el formato fijo (vídeo H.264 + audio SPA/QAA/ADS) que el
relevo repite en bucle mientras arranca el canal."""
from __future__ import annotations

import hashlib
import json
import logging
import subprocess
import tempfile
from dataclasses import asdict, dataclass, replace
from pathlib import Path

from . import h264
from .slots import SLOTS, pids

log = logging.getLogger("intro_relay")

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}


@dataclass(frozen=True)
class IntroOptions:
    width: int = 1920
    height: int = 1080
    fps: int = 25
    # Dispatcharr no entrega nada hasta acumular ~1 MB: a tasa fija alta ese mega llega enseguida
    video_kbps: int = 8000
    audio_kbps: int = 128
    image_seconds: int = 10
    # Mismo perfil H.264 que los canales: si el cliente copia el vídeo sin transcodificar, su decodificador se
    # configura con la intro y algunos se quedan en negro si el perfil cambia a mitad (High -> Main)
    profile: str = "main"
    level: str = "4.0"
    # Formato de la imagen: "progressive", o "tt"/"bb" (entrelazado, campo superior/inferior primero) para los
    # canales de TDT; el navegador que copia el vídeo se queda en negro si la intro y el canal no coinciden
    field_order: str = "progressive"
    sar: str = "1:1"
    # Imágenes de referencia y fotogramas B como el canal: el decodificador por hardware (QuickSync) se reinicia
    # en el empalme si cambia lo que tiene que reservar, y la conversión de Emby falla
    # Cadencia exacta del canal (p. ej. "30000/1001" = 29,97): redondeada a 30 no coincide con la del canal
    rate: str = ""
    refs: int = 0                   # 0 = lo que decida el codificador
    bframes: int = 0
    # Píxeles que la versión de la intro para un canal es más estrecha que él (ver options_for); 0 = misma resolución
    narrower: int = 16
    # Cabeceras de vídeo exactas del canal (SPS/PPS en hexadecimal): la intro se prepara con ellas (ver h264.py)
    params: tuple = ()
    # Idioma de cada pista de audio (la disposición fija, ver slots.py): la intro lleva las mismas que el canal
    audio: tuple = SLOTS


def frame_rate(options: IntroOptions) -> float:
    if options.rate:
        num, den = options.rate.split("/")
        return int(num) / int(den)
    return float(options.fps)


def options_for(video: dict, base: IntroOptions) -> IntroOptions | None:
    """Opciones de intro con el mismo formato que el vídeo de un canal (solo H.264; None si no aplica)."""
    if video.get("codec_name") != "h264":
        return None
    profile = (video.get("profile") or "").lower()
    profile = "high" if "high" in profile else "main" if "main" in profile else "baseline" if "baseline" in profile else None
    level = video.get("level")
    width, height = int(video.get("width") or 0), int(video.get("height") or 0)
    if not profile or not level or width < 64 or height < 64:
        return None
    field = video.get("field_order") or "progressive"
    field = field if field in ("tt", "bb", "tb", "bt") else "progressive"
    if field != "progressive" and profile == "baseline":
        profile = "main"            # el perfil Baseline no admite entrelazado
    rate = ""
    try:
        num, den = (video.get("r_frame_rate") or "25/1").split("/")
        fps = max(1, round(int(num) / max(1, int(den))))
        if int(num) % max(1, int(den)):
            rate = f"{int(num)}/{int(den)}"
    except ValueError:
        fps = base.fps
    sar = video.get("sample_aspect_ratio") or "1:1"
    sar = sar if sar not in ("0:1", "N/A") else "1:1"
    refs = max(0, min(16, int(video.get("refs") or 0)))
    bframes = max(0, min(3, int(video.get("has_b_frames") or 0))) if profile != "baseline" else 0
    # La intro, `narrower` píxeles (16 por defecto) más estrecha que el canal: los reproductores de navegador (hls.js, el de Emby web)
    # solo cogen el SPS/PPS nuevo del vídeo si cambia la resolución o la forma del píxel; con la misma, siguen
    # decodificando el canal con las cabeceras de la intro y la imagen se para tras el empalme. Más estrecha y no
    # más ancha, para no superar nunca el límite de resolución de un cliente cuando Emby decide con la intro.
    # Con las cabeceras del canal (params) no hace falta: para el decodificador no cambia nada en el empalme.
    params = tuple(video.get("params") or ())
    narrower = 0 if params else max(0, int(base.narrower))
    width = width - narrower if width - narrower >= 64 else width
    return replace(base, width=width, height=height, fps=fps, profile=profile, level=f"{int(level) / 10:.1f}",
                   field_order=field, sar=sar, refs=refs, bframes=bframes, rate=rate, params=params)


def _key(media: Path, options: IntroOptions) -> str:
    stat = media.stat()
    fields = asdict(options)
    if tuple(fields["audio"]) == SLOTS:
        del fields["audio"]           # las de siempre: mismo nombre de archivo que en versiones anteriores
    raw = json.dumps([str(media), stat.st_size, int(stat.st_mtime), fields])
    return hashlib.sha1(raw.encode()).hexdigest()[:12]


def has_audio(media: Path) -> bool:
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index",
                          "-of", "csv=p=0", str(media)], capture_output=True, text=True).stdout
    return bool(out.strip())


def target(media: Path, cache_dir: Path, options: IntroOptions) -> Path:
    return cache_dir / f"intro-{_key(media, options)}.ts"


def build(media: Path, cache_dir: Path, options: IntroOptions) -> Path:
    """Devuelve el clip de intro, generándolo si no existe para esa imagen/vídeo y esas opciones."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    target = cache_dir / f"intro-{_key(media, options)}.ts"
    if target.is_file() and target.stat().st_size > 0:
        return target
    if options.params:
        try:
            _build_cloned(media, target, options)
            return target
        except Exception as e:
            # No se puede con las cabeceras del canal: la intro de siempre con su formato (mismo archivo)
            log.warning("intro sin las cabeceras del canal (%s): %s", target.name, e)
            Path(str(target) + ".tmp").unlink(missing_ok=True)
    _build_plain(media, target, replace(options, params=()))
    return target


def _inputs(media: Path, o: IntroOptions) -> tuple[list[str], str]:
    """Entradas de ffmpeg (imagen o vídeo, y silencio si no trae audio) y de dónde sale el audio."""
    is_image = media.suffix.lower() in IMAGE_EXT
    cmd = ["-loop", "1", "-t", str(o.image_seconds), "-i", str(media)] if is_image else ["-i", str(media)]
    audio_from_media = not is_image and has_audio(media)
    if not audio_from_media:
        cmd += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000"]
    return cmd, "0:a:0" if audio_from_media else "1:a:0"


def _audio_args(o: IntroOptions) -> list[str]:
    args = ["-c:a", "aac", "-b:a", f"{o.audio_kbps}k", "-ar", "48000", "-ac", "2"]
    for n, lang in enumerate(o.audio):
        args += [f"-metadata:s:a:{n}", f"language={lang}"]
    return args


def _build_cloned(media: Path, target: Path, o: IntroOptions) -> None:
    """La intro con las cabeceras exactas del canal: x264 la codifica de forma compatible (misma codificación
    entrópica, transformada 8x8, entrelazado, desplazamiento de croma; sin fotogramas B ni predicción
    ponderada) y después se le ponen el SPS/PPS del canal y se reescribe la cabecera de cada porción."""
    plan = h264.clone_plan([bytes.fromhex(p) for p in o.params])
    sps, pps = plan["sps"], plan["pps"]
    interlaced = o.field_order != "progressive"
    top_first = o.field_order in ("tt", "tb")
    if interlaced == bool(sps["frame_mbs_only"]):
        raise h264.Unsupported("el entrelazado no coincide con el SPS")
    # La imagen va dentro del recorte que declara el SPS del canal; x264 codifica el tamaño completo
    crop_l, crop_r, crop_t, crop_b = sps["crop"]
    unit_y = 2 * (2 - sps["frame_mbs_only"])
    shown_w = plan["width"] - 2 * (crop_l + crop_r)
    shown_h = plan["height"] - unit_y * (crop_t + crop_b)
    sar_num, sar_den = (int(x) for x in o.sar.split(":"))
    shown = round(shown_w * sar_num / sar_den)
    keyint = 1 if plan["intra_only"] else round(frame_rate(o)) or o.fps
    x264 = (f"cabac={pps['cabac']}:8x8dct={pps['transform_8x8']}:chroma-qp-offset={pps['chroma_qp_offset']}"
            f":constrained-intra={pps['constrained_intra']}:psy=0:weightp=0:ref=1:bframes=0:deblock=0,0"
            f":keyint={keyint}:min-keyint={keyint}:scenecut=0:nal-hrd=cbr:filler=1")
    if interlaced:
        x264 += (":interlaced=1" if sps["mbaff"] else ":fake-interlaced=1") + (":tff=1" if top_first else ":bff=1")
    field_filter = (",setfield=" + ("tff" if top_first else "bff")) if interlaced else ""
    inputs, _audio = _inputs(media, o)
    with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
        raw, cloned = Path(tmp) / "x264.h264", Path(tmp) / "clone.h264"
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *inputs, "-map", "0:v:0", "-vf",
                        f"scale={shown}:{shown_h}:force_original_aspect_ratio=decrease,"
                        f"pad={shown}:{shown_h}:(ow-iw)/2:(oh-ih)/2,scale={shown_w}:{shown_h},"
                        f"pad={plan['width']}:{plan['height']}:{2 * crop_l}:{unit_y * crop_t},"
                        f"setsar={sar_num}/{sar_den}{field_filter},format=yuv420p",
                        "-r", o.rate or str(o.fps), "-c:v", "libx264", "-preset", "veryfast", "-profile:v", "high",
                        "-level", o.level, "-b:v", f"{o.video_kbps}k", "-minrate", f"{o.video_kbps}k",
                        "-maxrate", f"{o.video_kbps}k", "-bufsize", f"{o.video_kbps * 2}k",
                        *(["-flags", "+ildct+ilme"] if interlaced else []), "-x264-params", x264,
                        "-f", "h264", str(raw)], check=True, capture_output=True)
        cloned.write_bytes(h264.rewrite_stream(raw.read_bytes(), plan, o.field_order))
        # Se comprueba que se decodifica sin un solo error antes de darla por buena
        check = subprocess.run(["ffmpeg", "-hide_banner", "-v", "error", "-f", "h264", "-i", str(cloned),
                                "-f", "null", "-"], capture_output=True, text=True)
        if check.returncode or check.stderr.strip():
            raise h264.Unsupported(f"la intro reescrita no se decodifica limpia: {check.stderr.strip()[:200]}")
        inputs, audio = _inputs(media, o)
        # el vídeo ya está hecho: entra como 2.ª fuente; el audio sale de la imagen/vídeo original o del silencio
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *inputs,
               "-framerate", o.rate or str(o.fps), "-f", "h264", "-i", str(cloned)]
        video_input = len([a for a in inputs if a == "-i"])
        # Con las cabeceras del canal (que anuncian reordenación) ffmpeg no sabe poner las marcas de tiempo al
        # leer el vídeo en bruto; la intro no tiene fotogramas B: la imagen N va en N / cadencia
        num, den = (o.rate or f"{o.fps}/1").split("/")
        stamp = f"N*{den}/({num}*TB)"
        cmd += ["-map", f"{video_input}:v:0", *[a for _ in o.audio for a in ("-map", audio)], "-shortest",
                "-c:v", "copy", "-bsf:v", f"setts=pts={stamp}:dts={stamp}", *_audio_args(o),
                "-f", "mpegts", *pids(len(o.audio)), str(target) + ".tmp"]
        subprocess.run(cmd, check=True, capture_output=True)
    Path(str(target) + ".tmp").rename(target)


def _build_plain(media: Path, target: Path, options: IntroOptions) -> None:
    o = options
    inputs, audio = _inputs(media, o)
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *inputs]
    cmd += ["-map", "0:v:0", *[a for _ in o.audio for a in ("-map", audio)], "-shortest"]
    # Con píxeles no cuadrados (p. ej. 1440x1080 a 16:9) se escala a la imagen que se verá y luego al tamaño real
    sar_num, sar_den = (int(x) for x in o.sar.split(":"))
    shown = round(o.width * sar_num / sar_den)
    interlaced = o.field_order != "progressive"
    top_first = o.field_order in ("tt", "tb")
    x264 = "nal-hrd=cbr:filler=1" + (":interlaced=1:" + ("tff=1" if top_first else "bff=1") if interlaced else "")
    if o.refs:
        x264 += f":ref={o.refs}"
    # las imágenes de la intro se marcan con el orden de campos del canal (si no, el codificador pone el suyo)
    field_filter = (",setfield=" + ("tff" if top_first else "bff")) if interlaced else ""
    cmd += ["-vf", f"scale={shown}:{o.height}:force_original_aspect_ratio=decrease,"
                   f"pad={shown}:{o.height}:(ow-iw)/2:(oh-ih)/2,scale={o.width}:{o.height},"
                   f"setsar={sar_num}/{sar_den}{field_filter},format=yuv420p",
            "-r", o.rate or str(o.fps), "-g", str(o.fps), "-keyint_min", str(o.fps), "-sc_threshold", "0",
            "-c:v", "libx264", "-preset", "veryfast", "-profile:v", o.profile, "-level", o.level, "-bf", str(o.bframes),
            "-b:v", f"{o.video_kbps}k", "-minrate", f"{o.video_kbps}k", "-maxrate", f"{o.video_kbps}k",
            "-bufsize", f"{o.video_kbps * 2}k", "-x264-params", x264,
            *(["-flags", "+ildct+ilme", "-field_order", o.field_order] if interlaced else []),
            *_audio_args(o), "-f", "mpegts", *pids(len(o.audio)), str(target) + ".tmp"]
    subprocess.run(cmd, check=True, capture_output=True)
    Path(str(target) + ".tmp").rename(target)


def cleanup(cache_dir: Path, keep: set[Path]) -> None:
    """Borra los clips anteriores (después de arrancar el relevo con los nuevos)."""
    for old in cache_dir.glob("intro-*.ts*"):
        if old not in keep:
            old.unlink(missing_ok=True)
