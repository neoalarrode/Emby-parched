"""Final de cada frase según los subtítulos WebVTT de la fuente.

Las fuentes DRM traen sus subtítulos como pistas WebVTT de su lista maestra HLS. Al pasar por Dispatcharr llegan al
relevo como texto con solo su instante de inicio (un PES por frase, y la misma frase otra vez al empezar cada
segmento si sigue en pantalla). El final está en el WebVTT de la fuente, que además va por delante del TS (de 2 a 14
segundos medidos). Así que, mientras se ve un canal, se lee su lista de subtítulos (como haría un reproductor: la
lista cada pocos segundos y solo los segmentos nuevos, de unos cientos de bytes) y se guarda cada frase con su
inicio y su final en el reloj de la fuente. Las frases del TS se emparejan por su texto; el desfase entre los dos
relojes sale de ahí mismo (el que más se repite), así que no importa cómo los haya cambiado el camino."""
from __future__ import annotations

import collections
import logging
import re
import threading
import time
import urllib.parse
import urllib.request

log = logging.getLogger("intro_relay")

WRAP = 1 << 33
CLOCK = 90000
POLL = 2.0                     # cada cuánto se mira la lista de subtítulos de la fuente (s)
KEEP = 300 * CLOCK             # frases que se recuerdan (las de los últimos 5 minutos de la fuente)
CUE = re.compile(r"(?:^|\n)([\d:.]+)\s+-->\s+([\d:.]+)[^\n]*\n(.*?)(?=\n\s*\n|\Z)", re.S)
TAG = re.compile(r"<[^>]*>|\{[^}]*\}")


def norm(text: str) -> str:
    """Texto comparable: sin etiquetas, sin guiones de diálogo al principio ni espacios de más."""
    text = TAG.sub("", text or "").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    return " ".join(text.split()).strip().lower()


def _seconds(stamp: str) -> float:
    parts = stamp.split(":")
    return sum(float(p) * 60 ** k for k, p in enumerate(reversed(parts)))


def parse_segment(data: str) -> list[tuple[int, int, str]]:
    """(inicio, fin, texto) de cada frase de un segmento WebVTT, en el reloj MPEG-TS (90 kHz) de la fuente."""
    base = 0
    m = re.search(r"X-TIMESTAMP-MAP=([^\n]*)", data)
    if m:
        fields = dict(f.split(":", 1) for f in m.group(1).replace(" ", "").split(",") if ":" in f)
        try:
            base = int(fields.get("MPEGTS", "0")) - int(round(_seconds(fields.get("LOCAL", "0")) * CLOCK))
        except ValueError:
            base = 0
    out = []
    for a, b, text in CUE.findall(data.replace("\r", "")):
        t = norm(text)
        if t:
            out.append(((base + int(round(_seconds(a) * CLOCK))) % WRAP,
                        (base + int(round(_seconds(b) * CLOCK))) % WRAP, t))
    return out


def _diff(a: int, b: int) -> int:
    """a - b en relojes de 33 bits que dan la vuelta (con signo)."""
    d = (a - b) % WRAP
    return d - WRAP if d >= WRAP // 2 else d


class Track:
    """Frases de una pista: trozos tal cual llegan (un trozo por segmento) y frases enteras (trozos seguidos
    del mismo texto unidos)."""

    def __init__(self):
        self.pieces: list[tuple[int, int, str]] = []
        self.cues: list[list] = []                   # [inicio, fin, texto]

    def add(self, start: int, end: int, text: str) -> None:
        if (start, end, text) in self.pieces:
            return
        self.pieces.append((start, end, text))
        for cue in reversed(self.cues[-20:]):
            if cue[2] == text and -CLOCK // 2 <= _diff(start, cue[1]) <= CLOCK // 10 and _diff(start, cue[0]) >= 0:
                if _diff(end, cue[1]) > 0:
                    cue[1] = end
                return
        self.cues.append([start, end, text])

    def trim(self, newest: int) -> None:
        self.pieces = [p for p in self.pieces if _diff(newest, p[1]) < KEEP]
        self.cues = [c for c in self.cues if _diff(newest, c[1]) < KEEP]


class Watcher:
    """Lee las pistas de subtítulos de la fuente mientras dura la sesión y da el final de cada frase."""

    def __init__(self, master_url: str, agent: str, indices: list[int], tag: str):
        self.master_url, self.agent, self.indices, self.tag = master_url, agent, indices, tag
        self.tracks = {k: Track() for k in indices}
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.offset: int | None = None               # PTS de la salida - reloj de la fuente
        self.votes: collections.deque = collections.deque(maxlen=12)
        self.found = self.missed = 0
        self.thread = threading.Thread(target=self._run, name=f"vtt-{tag}", daemon=True)

    def start(self) -> "Watcher":
        self.thread.start()
        return self

    def stop(self) -> None:
        self.stop_event.set()

    def _get(self, url: str, limit: int = 512 * 1024) -> tuple[str, str]:
        req = urllib.request.Request(url, headers={"User-Agent": self.agent})
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.read(limit).decode("utf-8", "replace"), r.geturl()

    def _run(self) -> None:
        try:
            master, base = self._get(self.master_url)
        except Exception as e:
            log.info("[%s] subtítulos: no pude leer la lista de la fuente (%s); duración estimada", self.tag, e)
            return
        uris = [urllib.parse.urljoin(base, m.group(1)) for m in
                re.finditer(r'#EXT-X-MEDIA:[^\n]*TYPE=SUBTITLES[^\n]*?URI="([^"]*)"', master)]
        wanted = {k: uris[k] for k in self.indices if k < len(uris)}
        if not wanted:
            log.info("[%s] subtítulos: la lista de la fuente no trae pistas WebVTT; duración estimada", self.tag)
            return
        log.info("[%s] subtítulos: leyendo el final de cada frase de la lista de la fuente (%d pista%s)",
                 self.tag, len(wanted), "" if len(wanted) == 1 else "s")
        seen: dict[int, collections.deque] = {k: collections.deque(maxlen=200) for k in wanted}
        errors = 0
        while not self.stop_event.is_set():
            for k, uri in wanted.items():
                try:
                    playlist, pbase = self._get(uri, 256 * 1024)
                    for line in playlist.splitlines():
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        key = line.split("?")[0]
                        if key in seen[k]:
                            continue
                        seen[k].append(key)
                        body, _ = self._get(urllib.parse.urljoin(pbase, line), 256 * 1024)
                        cues = parse_segment(body)
                        with self.lock:
                            track = self.tracks[k]
                            for start, end, text in cues:
                                track.add(start, end, text)
                            if cues:
                                track.trim(cues[-1][1])
                    errors = 0
                except Exception as e:
                    errors += 1
                    if errors in (1, 10):
                        log.info("[%s] subtítulos: fallo leyendo la lista de la fuente: %s", self.tag, e)
            self.stop_event.wait(POLL)

    def end_for(self, index: int, text: str, pts: int) -> int | None:
        """PTS (salida) en que acaba la frase que empieza (o sigue) en `pts`; None si la fuente no la tiene."""
        t = norm(text)
        with self.lock:
            track = self.tracks.get(index)
            if track is None or not t:
                return None
            pieces = [p for p in track.pieces if p[2] == t]
            if not pieces:
                self.missed += 1
                return None
            # desfase entre relojes: el que más se repite entre los emparejamientos recientes
            exact = {round(_diff(pts, p[0]) / (CLOCK // 10)): _diff(pts, p[0]) for p in pieces}
            self.votes.append(set(exact))
            counts = collections.Counter(c for v in self.votes for c in v)
            if self.offset is None or round(self.offset / (CLOCK // 10)) not in exact:
                best, n = counts.most_common(1)[0]
                if best in exact and (n >= 2 or len(pieces) == 1):
                    self.offset = exact[best]           # el valor exacto de este emparejamiento
            if self.offset is None:
                return None
            src = (pts - self.offset) % WRAP
            for start, end, ct in track.cues:
                if ct == t and -CLOCK // 2 <= _diff(src, start) and _diff(end, src) > 0:
                    self.found += 1
                    return (end + self.offset) % WRAP
            self.missed += 1
            return None
