"""Qué canales llevan intro y cómo se les pone (o se les quita) la fuente del relevo, siempre la primera."""
from __future__ import annotations

from .relay import INTRO_STREAM_NAME


def parse_lines(raw: object) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for line in str(raw or "").splitlines():
        item = line.strip()
        if item and item.casefold() not in seen:
            seen.add(item.casefold())
            out.append(item)
    return out


def target_channel_ids(channels: object, groups: object) -> list[int]:
    """Lista de inclusión: si no se indica ningún canal ni grupo, son todos."""
    from apps.channels.models import Channel
    from django.db.models import Q

    wanted_channels = parse_lines(channels)
    wanted_groups = parse_lines(groups)
    queryset = Channel.objects.all()
    if wanted_channels or wanted_groups:
        selector = Q()
        for entry in wanted_channels:
            try:
                selector |= Q(channel_number=float(entry.replace(",", ".")))
            except ValueError:
                pass
            selector |= Q(name__iexact=entry)
        for group in wanted_groups:
            selector |= Q(channel_group__name__iexact=group)
        queryset = queryset.filter(selector)
    return list(queryset.values_list("id", flat=True))


def _intro_streams():
    from apps.channels.models import Stream

    return Stream.objects.filter(name=INTRO_STREAM_NAME, is_custom=True)


def relay_url(base: str, channel_uuid: object) -> str:
    return f"{base.rstrip('/')}/r/{channel_uuid}"


def sync(base_url: str, channel_ids: list[int], proxy_profile_id: int | None) -> dict[str, int]:
    """Deja la fuente del relevo como primera en los canales elegidos y la quita del resto.
    Cada canal tiene su propia fuente (su URL lleva el uuid del canal)."""
    from apps.channels.models import Channel, ChannelStream, Stream
    from django.db import transaction

    wanted = set(channel_ids)
    added = removed = moved = 0
    with transaction.atomic():
        links = {cs.channel_id: cs for cs in ChannelStream.objects.filter(stream__in=_intro_streams()).select_related("stream")}
        # Quitar de los canales que ya no están en la lista
        for channel_id, link in list(links.items()):
            if channel_id not in wanted:
                stream = link.stream
                link.delete()
                stream.delete()
                removed += 1
                links.pop(channel_id)
        for channel in Channel.objects.filter(id__in=wanted).only("id", "uuid"):
            url = relay_url(base_url, channel.uuid)
            link = links.get(channel.id)
            if link is None:
                stream = Stream.objects.create(name=INTRO_STREAM_NAME, url=url, stream_profile_id=proxy_profile_id)
                link = ChannelStream.objects.create(channel_id=channel.id, stream=stream, order=0)
                added += 1
            elif link.stream.url != url:
                Stream.objects.filter(id=link.stream_id).update(url=url)
            # La del relevo, la primera; el resto conserva su orden detrás
            others = list(ChannelStream.objects.filter(channel_id=channel.id).exclude(id=link.id).order_by("order", "id"))
            needs_move = link.order != 0 or any(o.order == 0 for o in others) or any(
                o.order != i + 1 for i, o in enumerate(others))
            if needs_move:
                for i, other in enumerate(others):
                    if other.order != i + 1:
                        ChannelStream.objects.filter(id=other.id).update(order=i + 1)
                if link.order != 0:
                    ChannelStream.objects.filter(id=link.id).update(order=0)
                moved += 1
    return {"añadidos": added, "quitados": removed, "reordenados": moved}


def remove_all() -> int:
    deleted = 0
    for stream in _intro_streams():
        stream.delete()
        deleted += 1
    return deleted


def covered_count() -> int:
    from apps.channels.models import ChannelStream

    return ChannelStream.objects.filter(stream__in=_intro_streams()).count()
