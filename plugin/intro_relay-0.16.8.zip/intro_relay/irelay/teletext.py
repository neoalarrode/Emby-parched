"""Subtítulos de texto como teletexto DVB (EN 300 472 / EN 300 706), página 888.

Las fuentes DRM traen sus subtítulos como texto plano (una frase por PES, con su instante). Emby no lee subtítulos
de texto en una lista HLS ni en otro formato dentro del TS, pero su ffmpeg sí lee teletexto (libzvbi) y lo entrega
como texto a los clientes, sin recodificar el vídeo. Cada frase se convierte en una página de subtítulos de
teletexto (cabecera + hasta 2 filas abajo); una página vacía borra la anterior."""
from __future__ import annotations

import re
import unicodedata

PAGE = 0x88                 # página 888 (magacín 8)
MAGAZINE = 0                # el magacín 8 se codifica como 0
NATIONAL = 5                # bits C12-C14: juego latino con la variante española (comprobado con libzvbi)
ROWS = (22, 23)
WIDTH = 36                  # caracteres de texto por fila (40 menos los códigos de caja y color)

_HAMMING = [0x15, 0x02, 0x49, 0x5E, 0x64, 0x73, 0x38, 0x2F, 0xD0, 0xC7, 0x8C, 0x9B, 0xA1, 0xB6, 0xFD, 0xEA]
# Juego latino con la variante nacional española/portuguesa: en esas posiciones van estas letras
SPANISH = {"ç": 0x23, "$": 0x24, "¡": 0x40, "á": 0x5B, "é": 0x5C, "í": 0x5D, "ó": 0x5E, "ú": 0x5F, "¿": 0x60,
           "ü": 0x7B, "ñ": 0x7C, "è": 0x7D, "à": 0x7E}
_FREE = {0x23, 0x24, 0x40, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F, 0x60, 0x7B, 0x7C, 0x7D, 0x7E}


def _rev(b: int) -> int:
    return int(f"{b:08b}"[::-1], 2)


def _ham(n: int) -> int:
    return _HAMMING[n & 0x0F]


def _parity(c: int) -> int:
    c &= 0x7F
    return c | (0x80 if bin(c).count("1") % 2 == 0 else 0)


# Acentos del juego G2 para las letras que no están en el español básico (Ñ, Á, É...): la letra base va en la
# fila y el acento se pone encima con un paquete X/26 (teletexto nivel 1.5)
DIACRITICS = {"\u0300": 1, "\u0301": 2, "\u0302": 3, "\u0303": 4, "\u0304": 5, "\u0306": 6, "\u0307": 7,
              "\u0308": 8, "\u030a": 10, "\u0327": 11, "\u030b": 13, "\u0328": 14, "\u030c": 15}


G2 = {"«": (0x22, 0x2B), "»": (0x22, 0x3B), "¨": (0x20, 0x48), "·": (0x2E, 0x37), "€": (0x45, 0x24)}


def _char(ch: str) -> tuple[int, int]:
    """(código en la fila, acento a poner encima con X/26 o 0; negativo: carácter G2 que va en su lugar)."""
    if ch in G2:
        return G2[ch][0], -G2[ch][1]
    if ch in SPANISH:
        return SPANISH[ch], 0
    code = ord(ch)
    if 0x20 <= code < 0x7F and code not in _FREE:
        return code, 0
    parts = unicodedata.normalize("NFD", ch)
    base, marks = parts[0], [c for c in parts[1:] if unicodedata.combining(c)]
    if len(base) == 1 and base.isascii() and base.isalpha() and marks and marks[0] in DIACRITICS:
        return ord(base), DIACRITICS[marks[0]]
    plain = "".join(c for c in unicodedata.normalize("NFKD", ch) if not unicodedata.combining(c))
    if len(plain) == 1 and 0x20 <= ord(plain) < 0x7F and ord(plain) not in _FREE:
        return ord(plain), 0
    return {"“": 0x22, "”": 0x22, "‘": 0x27, "’": 0x27, "…": 0x2E, "–": 0x2D,
            "—": 0x2D}.get(ch, 0x20), 0


def _ham24(value: int) -> bytes:
    """Hamming 24/18 (EN 300 706, 8.3) de 18 bits de datos: 3 bytes, el primer bit transmitido en el bit 0."""
    bits = [0] * 25                                    # posiciones 1..24
    data_pos = [p for p in range(1, 24) if p not in (1, 2, 4, 8, 16)]
    for n, pos in enumerate(data_pos):
        bits[pos] = (value >> n) & 1
    for k in range(5):                                 # P1..P5: paridad impar de las posiciones con ese bit
        p = 1 << k
        covered = sum(bits[i] for i in range(1, 24) if i & p and i != p)
        bits[p] = (covered + 1) % 2
    bits[24] = (sum(bits[1:24]) + 1) % 2               # P6: paridad impar de todo
    word = sum(bits[i] << (i - 1) for i in range(1, 25))
    return bytes([word & 0xFF, (word >> 8) & 0xFF, (word >> 16) & 0xFF])


def _triplet(address: int, mode: int, data: int) -> bytes:
    return _ham24(address | (mode << 6) | (data << 11))


def _enhancements(marks: list[tuple[int, int, int, int]]) -> list[bytes]:
    """Paquetes X/26 con los acentos (fila, columna, acento, letra base): 13 tripletes por paquete."""
    triplets: list[bytes] = []
    row = None
    for r, col, diacritic, base in marks:
        if r != row:
            triplets.append(_triplet(40 + r if r < 24 else 40, 0x04, 0))     # se coloca en la fila
            row = r
        if diacritic < 0:
            triplets.append(_triplet(col, 0x0F, -diacritic))                 # carácter G2 (« », €...)
        else:
            triplets.append(_triplet(col, 0x10 | diacritic, base))           # letra G0 con acento
    out = []
    for n in range(0, len(triplets), 13):
        chunk = triplets[n:n + 13]
        chunk += [_triplet(63, 0x1F, 0)] * (13 - len(chunk))                 # fin de la página
        out.append(bytes([_ham(n // 13)]) + b"".join(chunk))
    return out


def _unit(row: int, data: bytes, line: int) -> bytes:
    """Unidad de datos EN 300 472 (subtítulo) con una fila (0 = cabecera) del magacín 8; bits al revés."""
    mrag = (_ham(MAGAZINE | ((row & 1) << 3)), _ham(row >> 1))
    body = bytes([0xC0 | 0x20 | line, 0xE4]) + bytes(_rev(b) for b in (*mrag, *data))
    return bytes([0x03, 0x2C]) + body


def _header(erase: bool, page: int = PAGE) -> bytes:
    units, tens = page & 0x0F, page >> 4
    control = [_ham(units), _ham(tens),
               _ham(0), _ham(0x08 if erase else 0), _ham(0), _ham(0x08),    # S1, S2+C4 borrar, S3, S4+C6 subtítulo
               _ham(0x01 | 0x02),                                           # C7 sin cabecera, C8 actualización
               _ham((NATIONAL & 0x07) << 1)]                                # C11 y C12-C14: juego de caracteres
    return bytes(control) + bytes(_parity(0x20) for _ in range(32))


def _row(text: str, row: int, marks: list) -> bytes:
    """Fila de subtítulo centrada: blanco, inicio de caja (2 veces), texto, fin de caja (2 veces). Las letras con
    acento que no están en el juego básico se apuntan en `marks` para el paquete X/26."""
    chars = [_char(c) for c in text[:WIDTH]]
    inner = [0x07, 0x0B, 0x0B, *(code for code, _ in chars), 0x0A, 0x0A]
    pad = max(0, (40 - len(inner)) // 2)
    for n, (code, diacritic) in enumerate(chars):
        if diacritic:
            marks.append((row, pad + 3 + n, diacritic, code))
    line = [0x20] * pad + inner
    line += [0x20] * (40 - len(line))
    return bytes(_parity(c) for c in line[:40])


def clean(text: str) -> str:
    """Texto de una frase de la fuente: sin etiquetas (<i>, {\\an8}...) ni espacios sobrantes."""
    text = re.sub(r"<[^>]*>|\{[^}]*\}", "", text.replace("\r", ""))
    return "\n".join(" ".join(part.split()) for part in text.split("\n")).strip()


def wrap(text: str) -> list[str]:
    """Hasta 2 filas de WIDTH caracteres (las frases más largas se cortan por palabras)."""
    lines: list[str] = []
    for part in text.split("\n"):
        current = ""
        for word in part.split(" "):
            if current and len(current) + 1 + len(word) > WIDTH:
                lines.append(current)
                current = word
            else:
                current = f"{current} {word}" if current else word
        if current:
            lines.append(current)
    if len(lines) > len(ROWS):
        merged = " ".join(lines)
        lines = [merged[:WIDTH], merged[WIDTH:2 * WIDTH]]
    return lines


def _pts(value: int) -> bytes:
    return bytes([0x21 | ((value >> 29) & 0x0E), (value >> 22) & 0xFF, ((value >> 14) & 0xFE) | 1,
                  (value >> 7) & 0xFF, ((value << 1) & 0xFE) | 1])


def pes(pts: int, text: str) -> bytes:
    """PES de teletexto con la página para esa frase (texto vacío = página en blanco, que borra la anterior).
    Ocupa justo un número entero de paquetes TS (EN 300 472)."""
    units = [_unit(0, _header(True), 7)]
    lines = wrap(text)
    marks: list = []
    rows = [_row(line, ROWS[n + (len(ROWS) - len(lines))], marks) for n, line in enumerate(lines)]
    for n, enhancement in enumerate(_enhancements(marks)):
        units.append(_unit(26, enhancement, 8 + n))
    for n, data in enumerate(rows):
        units.append(_unit(ROWS[n + (len(ROWS) - len(lines))], data, 8 + len(units) + n))
    # El decodificador da la página por terminada cuando llega otra cabecera del mismo magacín: la de la página
    # 8FF (de relleno, no existe) la cierra ya, y la frase sale en su momento y no al llegar la siguiente
    units.append(_unit(0, _header(False, 0xFF), 8 + len(lines)))
    while (len(units) + 1) % 4:
        units.append(bytes([0xFF, 0x2C]) + b"\xff" * 44)              # relleno hasta múltiplo de 184 bytes
    payload = b"\x10" + b"".join(units)
    header_len = 0x24
    body = bytes([0x84, 0x80, header_len]) + _pts(pts) + b"\xff" * (header_len - 5) + payload
    return b"\x00\x00\x01\xbd" + len(body).to_bytes(2, "big") + body


def packets(pid: int, data: bytes, cc: int) -> tuple[bytes, int]:
    """Parte el PES en paquetes TS (ya mide un múltiplo exacto de 184). Devuelve (paquetes, contador siguiente)."""
    out = bytearray()
    for n, i in enumerate(range(0, len(data), 184)):
        chunk = data[i:i + 184]
        out += bytes([0x47, (0x40 if n == 0 else 0) | (pid >> 8), pid & 0xFF, 0x10 | cc]) + chunk.ljust(184, b"\xff")
        cc = (cc + 1) & 0x0F
    return bytes(out), cc


def descriptor(lang: str) -> bytes:
    """Descriptor de teletexto de la PMT: idioma y página de subtítulos 888."""
    return b"\x56\x05" + lang.encode()[:3].ljust(3, b" ") + bytes([(0x02 << 3) | MAGAZINE, PAGE])


def duration(text: str) -> float:
    """Cuánto se deja en pantalla una frase si la fuente no la borra antes (s)."""
    return min(8.0, max(3.5, 1.5 + len(text) / 12))
