"""Arranca y para el proceso del relevo, que vive fuera de los workers de Dispatcharr."""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
# Fuera de la carpeta del plugin (que se sustituye entera al importar otra versión del zip): si no, al
# reinstalar se borraba el clip de la intro con el relevo aún en marcha y dejaba de salir la intro
RUNTIME = Path("/data/intro_relay") if Path("/data").is_dir() else BASE / ".runtime"
STATE = RUNTIME / "state.json"
LOG = RUNTIME / "relay.log"


def _python() -> str:
    exe = Path(sys.executable or "")
    if exe.name.startswith("uwsgi") or not exe.name:
        for candidate in (os.environ.get("VIRTUAL_ENV", "") + "/bin/python", "/dispatcharrpy/bin/python"):
            if candidate and Path(candidate).is_file():
                return candidate
        return shutil.which("python3") or "python3"
    return str(exe)


def _load() -> dict:
    try:
        return json.loads(STATE.read_text())
    except Exception:
        return {}


def _health_pid(port: int) -> int | None:
    """PID del relevo que responde en ese puerto (None si no responde ninguno)."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=10) as r:
            parts = r.read().decode(errors="replace").split()
            return int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else -1
    except Exception:
        return None


def healthy(port: int) -> bool:
    return _health_pid(port) is not None


SESSIONS = RUNTIME / "sesiones"


def _session_pids() -> set[int]:
    """Procesos de sesión del relevo (uno por espectador); se borran las marcas de los que ya terminaron."""
    pids = set()
    if not SESSIONS.is_dir():
        return pids
    for marker in SESSIONS.iterdir():
        if not marker.name.isdigit():
            continue
        pid = int(marker.name)
        try:
            cmd = Path(f"/proc/{pid}/cmdline").read_bytes()
        except OSError:
            cmd = b""
        if b"irelay.relay" in cmd:
            pids.add(pid)
        else:
            marker.unlink(missing_ok=True)
    return pids


def _relay_pids(sessions: bool = False) -> list[int]:
    """Todos los procesos del relevo, también los de una versión anterior del plugin (el número guardado
    se pierde al reinstalar el plugin, porque se sustituye su carpeta)."""
    pids = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            cmd = (entry / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
        except OSError:
            continue
        if "-m irelay.relay" in cmd or "-m intro_relay.relay" in cmd:
            pids.append(int(entry.name))
    if not sessions:
        # Solo el proceso principal: las sesiones en curso siguen con el suyo hasta que el espectador termina
        skip = _session_pids()
        pids = [pid for pid in pids if pid not in skip]
    return pids


def _kill(pid: int) -> None:
    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(30):
            time.sleep(0.1)
            os.kill(pid, 0)
        os.kill(pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError, ValueError):
        pass


def stop(sessions: bool = False) -> bool:
    """Para el proceso principal del relevo (las sesiones en curso siguen); con sessions=True, también todas."""
    pids = set(_relay_pids(sessions))
    saved = _load().get("pid")
    if saved and int(saved) not in _session_pids():
        pids.add(int(saved))
    for pid in pids:
        _kill(pid)
    STATE.unlink(missing_ok=True)
    return bool(pids)


def start(args: list[str], port: int) -> int:
    """Arranca el relevo (parando antes el anterior) y espera a que responda."""
    stop()
    RUNTIME.mkdir(parents=True, exist_ok=True)
    if LOG.is_file() and LOG.stat().st_size > 5 * 1024 * 1024:
        LOG.replace(LOG.with_suffix(".log.1"))   # las sesiones en curso siguen escribiendo en el anterior
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(BASE), "/app", env.get("PYTHONPATH", "")])
    env.setdefault("DJANGO_SETTINGS_MODULE", "dispatcharr.settings")
    proc = subprocess.Popen([_python(), "-m", "irelay.relay", "--port", str(port), "--log", str(LOG), *args],
                            cwd=str(BASE), env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                            stderr=open(RUNTIME / "relay.stderr", "ab"), start_new_session=True)
    STATE.write_text(json.dumps({"pid": proc.pid, "port": port, "args": args, "code": code_version()}))
    for _ in range(100):
        if _health_pid(port) == proc.pid:  # que responda el relevo nuevo, no otro que siga ocupando el puerto
            return proc.pid
        if proc.poll() is not None:
            raise RuntimeError("el relevo se cerró al arrancar; mira .runtime/relay.stderr")
        time.sleep(0.2)
    raise RuntimeError("el relevo no responde")


def clips_missing() -> bool:
    """True si el relevo apunta a algún clip que ya no existe (o nunca se aplicó)."""
    args = _load().get("args") or []
    if not args:
        return True
    for flag in ("--intro", "--reconnect"):
        if flag in args:
            i = args.index(flag) + 1
            if i < len(args) and args[i] and not Path(args[i]).is_file():
                return True
    return False


def code_version() -> str:
    """Huella del código del relevo: si se instala otra versión del plugin, el relevo en marcha es viejo."""
    import hashlib

    h = hashlib.sha1()
    for path in sorted((BASE / "irelay").glob("*.py")):
        h.update(path.read_bytes())
    return h.hexdigest()[:12]


def alive() -> bool:
    """True si hay algún proceso del relevo en marcha (aunque esté ocupado y tarde en contestar)."""
    return bool(_relay_pids())


def needs_apply(port: int) -> bool:
    """Al arrancar Dispatcharr o cargar una versión nueva del plugin: renovar el relevo si su código es viejo,
    si falta algún clip o si no hay relevo. Un relevo vivo con el mismo código no se toca aunque tarde en
    contestar (va cargado con canales en emisión: reiniciarlo cortaría a todos los espectadores)."""
    if not alive():
        return True
    return clips_missing() or _load().get("code") != code_version()


def needs_start() -> bool:
    """Al abrir un canal: solo si no hay ningún relevo en marcha. Nunca se reinicia uno vivo desde aquí."""
    return not alive()


def ensure_on_boot(plugin_key: str, apply) -> None:
    """Al arrancar Dispatcharr (o al cargar una versión nueva del plugin), levanta o renueva el relevo antes de que nadie pida un canal (si no, el primer canal
    se abre sin intro: Dispatcharr no encuentra el relevo y salta a la fuente original). Solo en los workers
    web, en segundo plano y con un cerrojo para que entre los varios workers lo arranque uno solo."""
    try:
        import uwsgi  # noqa: F401  (solo existe dentro de los workers de uWSGI)
    except ImportError:
        return
    import threading

    def run() -> None:
        import fcntl

        time.sleep(3)
        try:
            from apps.plugins.models import PluginConfig

            cfg = PluginConfig.objects.filter(key=plugin_key, enabled=True).first()
            if cfg is None:
                return
            port = int((cfg.settings or {}).get("port") or 9722)
            RUNTIME.mkdir(parents=True, exist_ok=True)
            with open(RUNTIME / "boot.lock", "w") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX)
                if needs_apply(port):
                    apply(cfg.settings or {})
        except Exception:
            pass
        finally:
            from django.db import close_old_connections

            close_old_connections()

    threading.Thread(target=run, daemon=True, name="intro-relay-boot").start()

