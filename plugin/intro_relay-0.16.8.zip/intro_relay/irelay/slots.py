"""Normaliza el canal real al formato fijo de la intro (huecos SPA, QAA y ADS).

Formato fijo (el mismo que lleva la intro):
  PID 0x100 vídeo H.264
  PID 0x101 audio AAC "spa"  (español, o lo más parecido que haya)
  PID 0x102 audio AAC "qaa"  (versión original: qaa, vo, vos...; o si no, otra pista)
  PID 0x103 audio AAC "ads"  (audiodescripción)
Un hueco sin pista propia lleva una copia de la pista de SPA, para que ninguna se quede muda.

Detrás de esos tres van los demás huecos de la disposición fija (ajuste «Pistas de audio»; por defecto qcb, qcc,
qcd y qce), en PID 0x104, 0x105...: todos los canales y todas las intros llevan siempre las mismas pistas, así la
tabla de pistas no cambia nunca (ni en el empalme ni cuando el canal añade o quita pistas). Cada hueco lleva la
pista del canal con ese idioma si la tiene en ese momento; si no, una copia de la de SPA.
"""
from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass

SPANISH = {"spa", "esp", "es", "cas", "castellano", "spanish", "español", "espanol", "castilian"}
AUDIO_DESC = {"ads", "qad"}
ORIGINAL = {"qaa", "vo", "vos", "ov", "original", "mul"}
SLOTS = ("spa", "qaa", "ads")
DEFAULT_LAYOUT = ("spa", "qaa", "ads", "qcb", "qcc", "qcd", "qce")
MAX_AUDIO = 12        # con más, la tabla de pistas fija no cabe en un paquete
SUB_PID = 0x120       # subtítulos DVB del canal (español para sordos)
TEXT_PID = 0x121      # subtítulos de texto del canal (fuentes DRM), dibujados como DVB: 0x121, 0x122...


def parse_layout(raw: object) -> list[str]:
    """Lista de idiomas del ajuste «Pistas de audio»: siempre empieza por spa, qaa, ads; sin repetidos; hasta 12.
    Vacío (ajuste sin rellenar) = la lista por defecto."""
    if not str(raw or "").strip():
        raw = ",".join(DEFAULT_LAYOUT)
    out = list(SLOTS)
    for item in str(raw or "").replace(";", ",").replace("\n", ",").split(","):
        lang = "".join(c for c in item.strip().lower() if c.isalnum())[:8]
        if lang and lang not in out:
            out.append(lang)
    return out[:MAX_AUDIO]


def pids(audio_count: int = 3, extra: list[int] | None = None) -> list[str]:
    """PIDs fijos: vídeo 0x100, cada pista de audio a continuación (0x101, 0x102...) y después las de
    subtítulos que se indiquen (0x120 los DVB, 0x121... los de texto)."""
    args = ["-mpegts_pmt_start_pid", "0x1000", "-streamid", "0:0x100"]
    for n in range(audio_count):
        args += ["-streamid", f"{n + 1}:{0x101 + n:#x}"]
    for n, pid in enumerate(extra or []):
        args += ["-streamid", f"{audio_count + 1 + n}:{pid:#x}"]
    return args


def audio_pids(audio_count: int) -> set[int]:
    return {0x101 + n for n in range(audio_count)}


PIDS = pids(3)


@dataclass(frozen=True)
class Track:
    index: int          # índice entre las pistas de audio del canal (0:a:N)
    lang: str           # idioma en minúsculas, "" si no viene
    codec: str
    title: str = ""
    sample_rate: int = 0
    channels: int = 0
    profile: str = ""

    @property
    def needs_transcode(self) -> bool:
        """El audio de la intro es AAC LC estéreo a 48 kHz: si el canal trae otra cosa (AC3, AAC a 44,1 kHz,
        mono, HE-AAC...), esa pista se convierte. Un cambio de frecuencia o de canales en el empalme deja al
        reproductor del navegador sin audio y parado en negro."""
        return (self.codec != "aac" or (self.sample_rate and self.sample_rate != 48000)
                or (self.channels and self.channels != 2) or "he" in self.profile.lower())

    @property
    def is_spanish(self) -> bool:
        return self.lang in SPANISH

    @property
    def is_original(self) -> bool:
        return self.lang in ORIGINAL

    @property
    def is_ad(self) -> bool:
        t = self.title.lower()
        return self.lang in AUDIO_DESC or "audiodescrip" in t or "audio descrip" in t


def probe_subtitles(ffprobe: list[str], path: str) -> list[dict]:
    """Pistas de subtítulos del canal: [{"index": n.º entre los subtítulos, "pid", "codec", "lang"}]."""
    out = subprocess.run(ffprobe + ["-v", "error", "-select_streams", "s", "-show_entries",
                                    "stream=id,codec_name:stream_tags=language", "-of", "json", path],
                         capture_output=True, text=True).stdout
    try:
        streams = json.loads(out).get("streams", [])
    except ValueError:
        return []
    return [{"index": n, "pid": int(str(s.get("id") or "0"), 0), "codec": s.get("codec_name", ""),
             "lang": (s.get("tags", {}).get("language") or "").lower()} for n, s in enumerate(streams)]


def probe_data(ffprobe: list[str], path: str) -> list[dict]:
    """Pistas de datos del canal (las fuentes DRM llevan así sus subtítulos de texto): [{"index", "pid"}]."""
    out = subprocess.run(ffprobe + ["-v", "error", "-select_streams", "d", "-show_entries", "stream=id",
                                    "-of", "json", path], capture_output=True, text=True).stdout
    try:
        streams = json.loads(out).get("streams", [])
    except ValueError:
        return []
    return [{"index": n, "pid": int(str(s.get("id") or "0"), 0)} for n, s in enumerate(streams)]


def probe_audio(ffprobe: list[str], path: str) -> list[Track]:
    out = subprocess.run(ffprobe + ["-v", "error", "-select_streams", "a", "-show_entries",
                                    "stream=codec_name,sample_rate,channels,profile:stream_tags=language,title", "-of", "json", path],
                         check=True, capture_output=True, text=True).stdout
    tracks = []
    for i, s in enumerate(json.loads(out).get("streams", [])):
        tags = s.get("tags", {})
        lang = (tags.get("language") or "").strip().lower()
        if lang in ("und", "unk", "unknown"):
            lang = ""
        tracks.append(Track(i, lang, s.get("codec_name", ""), tags.get("title", ""),
                            int(s.get("sample_rate") or 0), int(s.get("channels") or 0), s.get("profile") or ""))
    return tracks


def probe_video(ffprobe: list[str], path: str) -> dict:
    """Formato del vídeo del canal (códec, perfil, nivel, tamaño, entrelazado...)."""
    out = subprocess.run(ffprobe + ["-v", "error", "-select_streams", "v:0", "-show_entries",
                                    "stream=codec_name,profile,level,width,height,field_order,r_frame_rate,"
                                    "sample_aspect_ratio,refs,has_b_frames", "-of", "json", path],
                         capture_output=True, text=True).stdout
    try:
        streams = json.loads(out).get("streams", [])
    except ValueError:
        return {}
    return streams[0] if streams else {}


def parse_overrides(raw: object) -> dict[str, list[str]]:
    """Ajuste «Idiomas de pistas a mano»: una línea por fuente, «Nombre de la fuente = idioma, idioma, ...», con
    el idioma de cada pista de audio en el orden en que llegan (vacío o «?» = la deja como venga)."""
    out: dict[str, list[str]] = {}
    for line in str(raw or "").splitlines():
        if "=" not in line:
            continue
        name, langs = line.split("=", 1)
        codes = ["".join(c for c in x.strip().lower() if c.isalnum())[:8] for x in langs.split(",")]
        if name.strip() and any(codes):
            out[name.strip().casefold()] = codes
    return out


TWO_LETTER = {"sp": "spa", "es": "spa", "qa": "qaa", "ad": "ads", "en": "eng", "ca": "cat", "eu": "eus",
              "gl": "glg", "fr": "fra", "de": "deu", "it": "ita", "pt": "por"}


def rendition_languages(playlist: str, kind: str = "AUDIO") -> list[str]:
    """Idioma de cada pista (en orden) que declara una lista maestra HLS en sus #EXT-X-MEDIA. Hay fuentes (las DRM)
    que solo lo dicen ahí y lo pierden al convertirse en TS: NAME="spa (mp4a...)" o LANGUAGE="sp"."""
    import re

    out = []
    for line in playlist.splitlines():
        if not line.startswith("#EXT-X-MEDIA:"):
            continue
        attrs = dict(re.findall(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', line[len("#EXT-X-MEDIA:"):]))
        attrs = {k: v.strip('"') for k, v in attrs.items()}
        if attrs.get("TYPE") != kind:
            continue
        name = (attrs.get("NAME") or "").split()
        lang = (attrs.get("LANGUAGE") or "").strip().lower()
        if name and len(name[0]) == 3 and name[0].isalpha():
            out.append(name[0].lower())
        elif len(lang) == 3 and lang.isalpha():
            out.append(lang)
        else:
            out.append(TWO_LETTER.get(lang.split("-")[0], lang))
    return out


def apply_overrides(tracks: list[Track], langs: list[str]) -> list[Track]:
    """Pone a mano el idioma de cada pista (en su orden) a las que se indique."""
    from dataclasses import replace

    return [replace(t, lang=langs[n]) if n < len(langs) and langs[n] else t for n, t in enumerate(tracks)]


def code(t: Track) -> str:
    """Idioma con el que sale una pista (los de español, versión original y audiodescripción, unificados)."""
    if t.is_ad:
        return "ads"
    if t.is_spanish:
        return "spa"
    if t.is_original:
        return "qaa"
    lang = "".join(c for c in t.lang if c.isalnum())[:8]
    return lang or "und"


def _base(tracks: list[Track], strict: bool) -> tuple[dict[str, Track | None], set[int]]:
    """Pistas de los tres huecos (None = copia de SPA) y las que han usado. Con strict, QAA solo lleva la versión
    original: las demás pistas van detrás con su propio idioma en vez de hacerse pasar por ella."""
    if not tracks:
        raise ValueError("el canal no trae audio")
    used: set[int] = set()

    def first(pred) -> Track | None:
        for t in tracks:
            if t.index not in used and pred(t):
                used.add(t.index)
                return t
        return None

    spa = (first(lambda t: t.is_spanish) or first(lambda t: not t.lang) or
           first(lambda t: not t.is_ad and not t.is_original) or first(lambda t: not t.is_ad) or first(lambda t: True))
    ads = first(lambda t: t.is_ad)
    qaa = first(lambda t: t.is_original) or (None if strict else first(lambda t: not t.is_ad))
    return {"spa": spa, "qaa": qaa, "ads": ads}, used


def arrange(tracks: list[Track], layout: list[str]) -> list[Track]:
    """Qué pista del canal va en cada hueco de la disposición: la de ese idioma si la hay, y si no, la de SPA."""
    extra = set(layout[len(SLOTS):])
    # QAA, si no hay versión original marcada: otra pista que no tenga hueco propio (como siempre); las que lo
    # tienen (p. ej. qcb) van al suyo y no se hacen pasar por la versión original
    base, used = _base([t for t in tracks if code(t) not in extra] or tracks, strict=False)
    spa = base["spa"]
    out = [base[name] or spa for name in SLOTS]
    for name in layout[len(SLOTS):]:
        match = next((t for t in tracks if t.index not in used and code(t) == name), None)
        if match is not None:
            used.add(match.index)
        out.append(match or spa)
    return out


def assign(tracks: list[Track]) -> dict[str, Track]:
    """Decide qué pista del canal va a cada hueco. Siempre devuelve los 3 huecos."""
    if not tracks:
        raise ValueError("el canal no trae audio")
    used: set[int] = set()

    def first(pred) -> Track | None:
        for t in tracks:
            if t.index not in used and pred(t):
                used.add(t.index)
                return t
        return None

    # SPA: la española; si no hay, una sin idioma; luego cualquiera que no sea versión original ni AD;
    # luego la versión original; si solo hay AD, esa
    spa = (first(lambda t: t.is_spanish) or first(lambda t: not t.lang) or
           first(lambda t: not t.is_ad and not t.is_original) or first(lambda t: not t.is_ad) or first(lambda t: True))
    # ADS: la primera audiodescripción que quede
    ads = first(lambda t: t.is_ad)
    # QAA: la versión original (qaa, vo, vos...); si no hay, la primera que quede que no sea AD
    qaa = first(lambda t: t.is_original) or first(lambda t: not t.is_ad)
    return {"spa": spa, "qaa": qaa or spa, "ads": ads or spa}


def build_args(tracks: list[Track], ts_offset: float, layout: list[str] | None = None,
               extras: list[tuple[str, int]] | None = None) -> list[str]:
    """Argumentos de ffmpeg (tras -i) para remultiplexar el canal a esa disposición de pistas, y sus pistas de
    subtítulos copiadas tal cual: extras = [(pista de entrada, p. ej. "0:s:0" o "0:d:1", PID de salida)]."""
    layout = list(layout or SLOTS)
    chosen = arrange(tracks, layout)
    args = ["-map", "0:v:0"]
    for t in chosen:
        args += ["-map", f"0:a:{t.index}"]
    for spec, _pid in extras or []:
        args += ["-map", spec]
    if extras:
        args += ["-c:s", "copy", "-c:d", "copy"]
    # Cabecera de vídeo (SPS/PPS) delante de cada fotograma clave: el decodificador del cliente la recibe justo
    # antes de la primera imagen del canal aunque el proveedor la envíe poco
    args += ["-c:v", "copy", "-bsf:v", "dump_extra=freq=keyframe"]
    # El codificador AAC adelanta su primer paquete 1024 muestras (priming); si se convierte alguna pista,
    # el canal se retrasa eso para que su audio no se solape con el final de la intro
    if any(t.needs_transcode for t in chosen):
        ts_offset += 1024 / 48000 + 0.005
    for n, (name, t) in enumerate(zip(layout, chosen)):
        if not t.needs_transcode:
            args += [f"-c:a:{n}", "copy"]
        else:  # otro códec (AC3, E-AC3, MP2...): se convierte solo esa pista
            args += [f"-c:a:{n}", "aac", f"-b:a:{n}", "192k", f"-ac:a:{n}", "2", f"-ar:a:{n}", "48000"]
        args += [f"-metadata:s:a:{n}", f"language={name}"]
    # initial_discontinuity: marca el salto del contador de continuidad en el empalme con la intro
    args += ["-muxdelay", "0", "-muxpreload", "0", "-f", "mpegts", "-mpegts_flags", "+initial_discontinuity",
             *pids(len(layout), [pid for _spec, pid in extras or []]), "-output_ts_offset", f"{ts_offset:.6f}"]
    return args
