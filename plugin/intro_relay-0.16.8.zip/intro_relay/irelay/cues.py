"""Frases de subtítulos de texto dentro del TS, de camino del relevo a la salida HLS de Dispatcharr.

Cada frase va en un PES (stream_id 0xBD) con su inicio como PTS y, en los datos, la marca "IRCU", su duración
(90 kHz, 4 bytes) y el texto en UTF-8. La pista se declara en la PMT con un descriptor de registro "IRCU" y el idioma
(descriptor 0x0A). La salida HLS (hlslang) la quita de la imagen y la sirve como pista WebVTT de la lista maestra,
que Emby da a sus apps como subtítulos de texto."""
from __future__ import annotations

MARK = b"IRCU"
CLOCK = 90000
WRAP = 1 << 33


def descriptor(lang: str) -> bytes:
    return b"\x05\x04" + MARK + b"\x0a\x04" + lang.encode()[:3].ljust(3, b" ") + b"\x00"


def _pts(value: int) -> bytes:
    return bytes([0x21 | ((value >> 29) & 0x0E), (value >> 22) & 0xFF, ((value >> 14) & 0xFE) | 1,
                  (value >> 7) & 0xFF, ((value << 1) & 0xFE) | 1])


def pes(start: int, duration: int, text: str) -> bytes:
    body = bytes([0x84, 0x80, 5]) + _pts(start % WRAP) + MARK + max(0, duration).to_bytes(4, "big") + text.encode()
    return b"\x00\x00\x01\xbd" + len(body).to_bytes(2, "big") + body


def parse(pes_data: bytes) -> tuple[int, int, str] | None:
    """(inicio, duración, texto) de un PES de frase, o None si no lo es."""
    if len(pes_data) < 14 or pes_data[:4] != b"\x00\x00\x01\xbd" or not pes_data[7] & 0x80:
        return None
    b = pes_data[9:14]
    start = ((b[0] >> 1) & 7) << 30 | b[1] << 22 | (b[2] >> 1) << 15 | b[3] << 7 | b[4] >> 1
    data = pes_data[9 + pes_data[8]:]
    size = 6 + ((pes_data[4] << 8) | pes_data[5])
    if size > 6:
        data = pes_data[9 + pes_data[8]:size]
    if data[:4] != MARK or len(data) < 8:
        return None
    return start, int.from_bytes(data[4:8], "big"), data[8:].decode("utf-8", "replace")


def _stamp(ticks: int) -> str:
    ms = ticks * 1000 // CLOCK
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d}.{ms % 1000:03d}"


def webvtt(base: int, items: list[tuple[int, int, str]]) -> str:
    """Segmento WebVTT con esas frases; `base` es el PTS que corresponde a 00:00:00.000 (el del segmento)."""
    out = ["WEBVTT", f"X-TIMESTAMP-MAP=MPEGTS:{base % WRAP},LOCAL:00:00:00.000", ""]
    for start, duration, text in items:
        rel = (start - base) % WRAP
        if rel >= WRAP // 2:                 # empieza antes del segmento (no debería): desde su principio
            duration = max(0, duration - (WRAP - rel))
            rel = 0
        if duration <= 0 or not text.strip():
            continue
        out += [f"{_stamp(rel)} --> {_stamp(rel + duration)}", text.replace("\r", "").strip(), ""]
    return "\n".join(out) + "\n"
