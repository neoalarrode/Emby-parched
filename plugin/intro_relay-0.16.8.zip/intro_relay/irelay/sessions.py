"""Sesiones independientes en Dispatcharr: cada cliente que abre un canal (o una fuente) recibe su propio
worker, con su buffer, su conexión al proveedor y, si el canal lleva la intro, su propio relevo.

Dispatcharr identifica cada worker por el id que llega en /proxy/ts/stream/<id> (el uuid del canal o el
hash de la fuente) y por eso dos clientes del mismo canal comparten worker. Aquí cada petición se renombra
a «<id>.s<n>». Todo lo que va por ese id (buffer, clientes, estado en Redis) queda separado sin más; lo que
falta es lo que Dispatcharr guarda por id numérico del canal o de la fuente:

  * las búsquedas por uuid/hash en la base de datos aceptan el id de sesión y marcan el objeto devuelto;
  * las reservas de conexión (channel_stream:<pk>, stream_profile:<pk>) y los metadatos que el modelo lee
    por uuid se reescriben por sesión mientras se trabaja con un objeto o un id de sesión, de modo que cada
    sesión reserva y libera su propia plaza en el proveedor.

Dispatcharr importa los plugins en cada proceso (uWSGI, Daphne, Celery) precisamente para permitir estos
parches; nada se escribe en los archivos del contenedor. Si algo de lo que se parchea no está donde se
espera (otra versión de Dispatcharr), no se instala nada y se deja constancia en el log."""
from __future__ import annotations

import contextvars
import functools
import inspect
import itertools
import logging
import os
import re
import threading
import time

log = logging.getLogger("plugins.intro_relay.sessions")

SESSION_RE = re.compile(r"^([0-9A-Za-z-]+)\.s(\d{1,24})$")
MARK = "_irelay_orig"
SID_ATTR = "_irelay_sid"
SETTING = "independent_sessions"

_scope: contextvars.ContextVar = contextvars.ContextVar("irelay_session_scope", default=None)
_counter = itertools.count(1)
_plugin_key: str | None = None
_enabled_cache = [0.0, False]
_scope_cache: dict[str, tuple] = {}
_lock = threading.Lock()


def split(worker_id) -> tuple[str, str] | None:
    """«<base>.s<n>» -> (base, n); cualquier otra cosa -> None."""
    if not isinstance(worker_id, str):
        return None
    m = SESSION_RE.match(worker_id)
    return (m.group(1), m.group(2)) if m else None


def base_id(worker_id):
    parts = split(worker_id)
    return parts[0] if parts else worker_id


def new_session_id(base: str) -> str:
    return f"{base}.s{int(time.time() * 1000) % 10**10}{next(_counter) % 1000:03d}"


# --------------------------------------------------------------------------------------------- ámbito
class Scope:
    """Reescritura de claves de Redis para una sesión: (pk del canal/fuente, uuid/hash, id de sesión)."""

    __slots__ = ("pk", "base", "sid", "tag", "live_from", "live_to")

    def __init__(self, pk: int, base: str, sid: str):
        self.pk, self.base, self.sid = str(pk), base, sid
        self.tag = ":s" + split(sid)[1]
        self.live_from = f"live:channel:{base}:"
        self.live_to = f"live:channel:{sid}:"

    def key(self, key):
        if not isinstance(key, str):
            return key
        if key.startswith("channel_stream:"):
            return key + self.tag if key[15:] == self.pk else key
        if key.startswith("stream_profile:"):
            return key + self.tag if key[15:].isdigit() else key
        if key.startswith(self.live_from):
            return self.live_to + key[len(self.live_from):]
        return key


_ONE_KEY = {"get", "set", "setex", "setnx", "getset", "getdel", "hget", "hset", "hgetall", "hdel", "hmget",
            "hexists", "hincrby", "expire", "pexpire", "ttl", "pttl", "incr", "decr", "incrby", "decrby",
            "type", "persist", "hkeys", "hvals", "hlen"}
_ALL_KEYS = {"delete", "exists", "unlink", "mget"}


class ScopedRedis:
    """Envuelve un cliente (o pipeline) de Redis y reescribe las claves si hay una sesión activa."""

    def __init__(self, raw, fixed: Scope | None = None):
        object.__setattr__(self, "_raw", raw)
        object.__setattr__(self, "_fixed", fixed)

    def __getattr__(self, name):
        attr = getattr(self._raw, name)
        if name == "pipeline":
            @functools.wraps(attr)
            def pipeline(*a, **k):
                return ScopedRedis(attr(*a, **k), self._fixed or _scope.get())
            return pipeline
        if name not in _ONE_KEY and name not in _ALL_KEYS:
            return attr
        scope = self._fixed or _scope.get()
        if scope is None:
            return attr
        if name in _ONE_KEY:
            def one(key, *a, **k):
                return attr(scope.key(key), *a, **k)
            return one

        def many(*keys, **k):
            if len(keys) == 1 and isinstance(keys[0], (list, tuple)):
                return attr([scope.key(x) for x in keys[0]], **k)
            return attr(*[scope.key(x) for x in keys], **k)
        return many

    def __setattr__(self, name, value):
        setattr(self._raw, name, value)

    def __enter__(self):
        self._raw.__enter__()
        return self

    def __exit__(self, *exc):
        return self._raw.__exit__(*exc)

    def __len__(self):
        return len(self._raw)

    def __bool__(self):
        return True


def _scope_for_object(obj) -> Scope | None:
    sid = getattr(obj, "__dict__", {}).get(SID_ATTR)
    if not sid:
        return None
    from apps.channels.models import Channel

    base = str(obj.uuid) if isinstance(obj, Channel) else obj.stream_hash
    return Scope(obj.pk, base, sid)


def _scope_for_id(worker_id) -> Scope | None:
    parts = split(worker_id)
    if not parts:
        return None
    cached = _scope_cache.get(worker_id)
    if cached:
        return Scope(*cached)
    from apps.channels.models import Channel, Stream

    base = parts[0]
    pk = None
    if len(base) == 36 and base.count("-") == 4:
        pk = Channel.objects.filter(uuid=base).values_list("id", flat=True).first()
    if pk is None:
        pk = Stream.objects.filter(stream_hash=base).values_list("id", flat=True).first()
    if pk is None:
        return None
    if len(_scope_cache) > 2000:
        _scope_cache.clear()
    _scope_cache[worker_id] = (pk, base, worker_id)
    return Scope(pk, base, worker_id)


def _run_in(scope: Scope | None, fn, *a, **k):
    if scope is None or (_scope.get() is not None and _scope.get().sid == scope.sid):
        return fn(*a, **k)
    token = _scope.set(scope)
    try:
        return fn(*a, **k)
    finally:
        _scope.reset(token)


# -------------------------------------------------------------------------------------------- envoltorios
def _orig(fn):
    while hasattr(fn, MARK):
        fn = getattr(fn, MARK)
    return fn


def _mark(wrapper, original):
    setattr(wrapper, MARK, original)
    return wrapper


def _method_by_object(original):
    @functools.wraps(original)
    def wrapper(self, *a, **k):
        return _run_in(_scope_for_object(self), original, self, *a, **k)
    return _mark(wrapper, original)


def _function_by_id(original, position: int, name: str = "channel_id"):
    @functools.wraps(original)
    def wrapper(*a, **k):
        worker_id = k.get(name) if name in k else (a[position] if len(a) > position else None)
        if not split(worker_id):
            return original(*a, **k)
        return _run_in(_scope_for_id(worker_id), original, *a, **k)
    return _mark(wrapper, original)


def _enabled() -> bool:
    now = time.monotonic()
    if now - _enabled_cache[0] < 10:
        return _enabled_cache[1]
    value = False
    try:
        from apps.plugins.models import PluginConfig

        row = PluginConfig.objects.filter(key=_plugin_key).values_list("enabled", "settings").first()
        if row:
            enabled, settings = row
            value = bool(enabled) and _truthy((settings or {}).get(SETTING, True))
    except Exception as e:  # la base de datos no responde: mejor compartir que romper la petición
        log.debug("no puedo leer los ajustes del plugin: %s", e)
        value = _enabled_cache[1]
    _enabled_cache[0], _enabled_cache[1] = now, value
    return value


def _truthy(value) -> bool:
    if isinstance(value, str):
        return value.strip().lower() not in ("", "0", "false", "no", "off")
    return bool(value)


def _make_stream_ts(original):
    @functools.wraps(original)
    def stream_ts(request, channel_id, *a, **k):
        if (isinstance(channel_id, str) and not split(channel_id) and ".p" not in channel_id
                and _enabled()):
            channel_id = new_session_id(channel_id)
        if not split(channel_id):
            return original(request, channel_id, *a, **k)
        return _run_in(_scope_for_id(channel_id), original, request, channel_id, *a, **k)
    return _mark(stream_ts, original)


def _make_release_worker_stream(original):
    @functools.wraps(original)
    def release_worker_stream(worker_id):
        parts = split(worker_id)
        if not parts:
            return original(worker_id)
        from apps.channels.models import Channel, Stream

        try:
            if len(parts[0]) == 36 and parts[0].count("-") == 4:
                channel = Channel.objects.filter(uuid=worker_id).first()
                if channel is not None:
                    return channel.release_stream()
            stream = Stream.objects.filter(stream_hash=worker_id).first()
            if stream is None:
                return False
            released = stream.release_stream()
            from core.utils import RedisClient

            client = RedisClient.get_client()
            if client is not None:  # Stream.release_stream no borra su channel_stream: con sesiones se acumularía
                client.delete(f"channel_stream:{stream.pk}:s{parts[1]}")
            return released
        except Exception as e:
            log.debug("liberar la sesión %s falló: %s", worker_id, e)
            return False
    return _mark(release_worker_stream, original)


def _make_dispatch_event(original):
    @functools.wraps(original)
    def dispatch_event_system(event_type, channel_id=None, channel_name=None, **details):
        parts = split(channel_id) if isinstance(channel_id, str) else None
        if not parts:
            return original(event_type, channel_id=channel_id, channel_name=channel_name, **details)
        details.setdefault("session_id", channel_id)
        return _run_in(_scope_for_id(channel_id), original, event_type, channel_id=parts[0],
                       channel_name=channel_name, **details)
    return _mark(dispatch_event_system, original)


def _make_log_event(original):
    """Los eventos del sistema guardan el uuid del canal: se pasa el del canal y el id de sesión aparte."""
    @functools.wraps(original)
    def log_system_event(event_type, channel_id=None, channel_name=None, **details):
        parts = split(channel_id) if isinstance(channel_id, str) else None
        if not parts:
            return original(event_type, channel_id=channel_id, channel_name=channel_name, **details)
        details.setdefault("session_id", channel_id)
        if "stream_id" not in details:
            try:
                from core.utils import RedisClient

                scope = _scope_for_id(channel_id)
                value = RedisClient.get_client().get(f"channel_stream:{scope.pk}{scope.tag}") if scope else None
                if value:
                    details["stream_id"] = int(value)
            except Exception:
                pass
        return original(event_type, channel_id=parts[0], channel_name=channel_name, **details)
    return _mark(log_system_event, original)


def _make_get_client(original):
    def get_client(cls, *a, **k):
        client = original(cls, *a, **k)
        if client is not None and _scope.get() is not None and not isinstance(client, ScopedRedis):
            return ScopedRedis(client)
        return client
    return classmethod(_mark(get_client, original))


def _proxy_redis_property():
    def getter(self):
        raw = self.__dict__.get("redis_client")
        if raw is None:
            return None
        cached = self.__dict__.get("_irelay_redis")
        if cached is None or cached._raw is not raw:
            cached = ScopedRedis(raw)
            self.__dict__["_irelay_redis"] = cached
        return cached

    def setter(self, value):
        self.__dict__["redis_client"] = value._raw if isinstance(value, ScopedRedis) else value

    prop = property(getter, setter)
    prop.fget._irelay = True
    return prop


# ----------------------------------------------------------------------------------------- base de datos
def _patch_queryset():
    from django.db.models.query import QuerySet
    from apps.channels.models import Channel, Stream

    fields = {Channel: "uuid", Stream: "stream_hash"}
    filter_orig = _orig(QuerySet._filter_or_exclude)
    clone_orig = _orig(QuerySet._clone)
    fetch_orig = _orig(QuerySet._fetch_all)

    def _filter_or_exclude(self, negate, args, kwargs):
        field = fields.get(self.model)
        if field and not negate:
            value = kwargs.get(field)
            parts = split(value) if isinstance(value, str) else None
            if parts:
                kwargs = dict(kwargs)
                kwargs[field] = parts[0]
                clone = filter_orig(self, negate, args, kwargs)
                clone.__dict__[SID_ATTR] = value
                return clone
        return filter_orig(self, negate, args, kwargs)

    def _clone(self):
        c = clone_orig(self)
        sid = self.__dict__.get(SID_ATTR)
        if sid:
            c.__dict__[SID_ATTR] = sid
        return c

    def _fetch_all(self):
        fetch_orig(self)
        sid = self.__dict__.get(SID_ATTR)
        if sid and self._result_cache:
            for obj in self._result_cache:
                if isinstance(obj, (Channel, Stream)):
                    obj.__dict__[SID_ATTR] = sid

    QuerySet._filter_or_exclude = _mark(_filter_or_exclude, filter_orig)
    QuerySet._clone = _mark(_clone, clone_orig)
    QuerySet._fetch_all = _mark(_fetch_all, fetch_orig)


# --------------------------------------------------------------------------------------------- instalar
def _replace_everywhere(module, name: str, make):
    """Sustituye module.<name> y cualquier copia importada por nombre en módulos ya cargados."""
    import sys

    current = getattr(module, name)
    original = _orig(current)
    new = make(original)
    for mod in list(sys.modules.values()):
        d = getattr(mod, "__dict__", None)
        if not d or not str(getattr(mod, "__name__", "")).startswith(("apps.", "core.", "dispatcharr.")):
            continue
        for attr, value in list(d.items()):
            if value is current or value is original:
                d[attr] = new
    setattr(module, name, new)


def _wrap_method(cls, name: str, make):
    current = cls.__dict__[name]
    if isinstance(current, staticmethod):
        setattr(cls, name, staticmethod(make(_orig(current.__func__))))
    else:
        setattr(cls, name, make(_orig(current)))


REQUIRED = [
    ("apps.proxy.live_proxy.views", "stream_ts"),
    ("apps.proxy.live_proxy.url_utils", "get_stream_object"),
    ("apps.proxy.live_proxy.url_utils", "release_worker_stream"),
    ("apps.proxy.live_proxy.url_utils", "generate_stream_url"),
    ("apps.proxy.live_proxy.url_utils", "get_stream_info_for_switch"),
    ("apps.proxy.live_proxy.url_utils", "get_alternate_streams"),
    ("apps.proxy.live_proxy.url_utils", "parse_preview_worker_id"),
    ("apps.proxy.live_proxy.services.channel_service", "ChannelService"),
    ("apps.proxy.live_proxy.server", "ProxyServer"),
    ("apps.channels.models", "Channel"),
    ("apps.channels.models", "Stream"),
    ("core.utils", "RedisClient"),
    ("core.utils", "dispatch_event_system"),
    ("core.utils", "log_system_event"),
]
CHANNEL_METHODS = ["get_stream", "release_stream", "update_stream_profile", "_stream_assignment_is_reusable",
                   "_release_stale_stream_assignment", "_channel_proxy_is_active"]
STREAM_METHODS = ["get_stream", "release_stream"]
SERVER_METHODS = ["_release_stream_resources", "_release_profile_slot_from_redis_metadata"]


def install(plugin_key: str) -> bool:
    """Instala (o reinstala tras recargar el plugin) los parches. Devuelve False si no se pudo."""
    global _plugin_key
    _plugin_key = plugin_key
    import importlib

    with _lock:
        try:
            mods = {}
            for module_name, attr in REQUIRED:
                mod = mods.get(module_name) or importlib.import_module(module_name)
                mods[module_name] = mod
                if not hasattr(mod, attr):
                    raise LookupError(f"{module_name}.{attr}")
            from apps.channels.models import Channel, Stream
            from apps.proxy.live_proxy.server import ProxyServer
            from apps.proxy.live_proxy.services.channel_service import ChannelService
            from core.utils import RedisClient

            for name in CHANNEL_METHODS:
                if name not in Channel.__dict__:
                    raise LookupError(f"Channel.{name}")
            for name in STREAM_METHODS:
                if name not in Stream.__dict__:
                    raise LookupError(f"Stream.{name}")
            for name in SERVER_METHODS:
                if name not in ProxyServer.__dict__:
                    raise LookupError(f"ProxyServer.{name}")
            if "redis_client =" not in inspect.getsource(ProxyServer.__init__):
                raise LookupError("ProxyServer.redis_client")
        except Exception as e:
            log.warning("Sesiones independientes NO instaladas (esta versión de Dispatcharr no encaja: %s)", e)
            return False

        views = mods["apps.proxy.live_proxy.views"]
        url_utils = mods["apps.proxy.live_proxy.url_utils"]
        core_utils = mods["core.utils"]

        _patch_queryset()
        for name in CHANNEL_METHODS:
            _wrap_method(Channel, name, _method_by_object)
        for name in STREAM_METHODS:
            _wrap_method(Stream, name, _method_by_object)
        for name in SERVER_METHODS:
            _wrap_method(ProxyServer, name, lambda f: _function_by_id(f, 1))
        if not getattr(getattr(ProxyServer.__dict__.get("redis_client"), "fget", None), "_irelay", False):
            ProxyServer.redis_client = _proxy_redis_property()
        for name, value in list(ChannelService.__dict__.items()):
            if isinstance(value, staticmethod):
                params = list(inspect.signature(_orig(value.__func__)).parameters)
                if params and params[0] == "channel_id":
                    _wrap_method(ChannelService, name, lambda f: _function_by_id(f, 0))
        RedisClient.get_client = _make_get_client(_orig(RedisClient.__dict__["get_client"].__func__))
        _replace_everywhere(url_utils, "release_worker_stream", _make_release_worker_stream)
        for name in ("generate_stream_url", "get_stream_info_for_switch", "get_alternate_streams"):
            _replace_everywhere(url_utils, name, lambda f: _function_by_id(f, 0))
        _replace_everywhere(core_utils, "dispatch_event_system", _make_dispatch_event)
        _replace_everywhere(core_utils, "log_system_event", _make_log_event)
        _replace_everywhere(views, "stream_ts", _make_stream_ts)
        _patch_urlconf(views)
        log.info("Sesiones independientes instaladas (pid %s)", os.getpid())
        return True


def _patch_urlconf(views):
    """Si las rutas ya se cargaron, apuntan a la función vieja: se cambian también."""
    import sys

    urls = sys.modules.get("apps.proxy.live_proxy.urls")
    if not urls:
        return
    for pattern in getattr(urls, "urlpatterns", []):
        callback = getattr(pattern, "callback", None)
        if callback is not None and _orig(callback) is _orig(views.stream_ts) and callback is not views.stream_ts:
            pattern.callback = views.stream_ts
