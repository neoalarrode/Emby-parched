"""Frases de texto (fuentes DRM) dibujadas como subtítulos DVB (EN 300 743).

Emby no lee subtítulos de texto dentro del TS de una lista HLS, pero los DVB los pasa a texto con su OCR. Así que
cada frase se dibuja limpia (letra blanca con borde negro, como los de la TDT) en una imagen DVB, una sola región por
frase, y el OCR de Emby la lee entera, con eñes y tildes. Una página sin regiones borra la frase."""
from __future__ import annotations

import struct
import unicodedata
from functools import lru_cache
from pathlib import Path

from . import dvbsub

WIDTH, HEIGHT = 1920, 1080
MAX_LINE = 1700                 # ancho máximo de una línea (píxeles)
BOTTOM = 1010                   # línea base de la última fila
OUTLINE = 3                     # grosor del borde negro


def lang_page(lang: str) -> int:
    """Página DVB que lleva el idioma (el ffmpeg de Emby pierde el idioma de los subtítulos en HLS, pero no la página;
    el parche dvb-subtitle-language de emby-parched lo lee de aquí): 0x8000 | letra1 << 10 | letra2 << 5 | letra3,
    a = 1 ... z = 26. Un código que no son 3 letras a-z va a la página 1."""
    code = (lang or "").strip().lower()
    if len(code) != 3 or not all("a" <= ch <= "z" for ch in code):
        return 1
    a, b, c = (ord(ch) - 0x60 for ch in code)
    return 0x8000 | (a << 10) | (b << 5) | c
# Paleta de 4 bits: 0 transparente, 1 borde negro, 2-4 blanco con suavizado (sobre el borde negro)
CLUT = [(0, 128, 128, 0xFF), (16, 128, 128, 0), (90, 128, 128, 0), (165, 128, 128, 0), (235, 128, 128, 0)]


@lru_cache(maxsize=1)
def _font() -> tuple[int, int, dict[str, tuple]]:
    data = (Path(__file__).with_name("fuente.bin")).read_bytes()
    if data[:4] != b"IRF1":
        raise ValueError("fuente.bin no válida")
    _size, ascent, line, count = struct.unpack_from("<hhhh", data, 4)
    pos, glyphs = 12, {}
    for _ in range(count):
        code, adv, x, y, w, h = struct.unpack_from("<Ihhhhh", data, pos)
        pos += 14
        n = (w * h + 3) // 4
        packed = data[pos:pos + n]
        pos += n
        levels = [(packed[i >> 2] >> (6 - 2 * (i & 3))) & 3 for i in range(w * h)]
        glyphs[chr(code)] = (adv, x, y, w, h, levels)
    return ascent, line, glyphs


def _glyph(ch: str):
    glyphs = _font()[2]
    if ch in glyphs:
        return glyphs[ch]
    plain = "".join(c for c in unicodedata.normalize("NFKD", ch) if not unicodedata.combining(c))
    return glyphs.get(plain[:1]) or glyphs.get({" ": " "}.get(ch, "?"))


def _width(text: str) -> int:
    return sum(_glyph(c)[0] for c in text)


def wrap(text: str) -> list[str]:
    """Filas que caben en MAX_LINE (las de la fuente se respetan; las largas se cortan por palabras)."""
    lines: list[str] = []
    for part in text.split("\n"):
        current = ""
        for word in part.split(" "):
            candidate = f"{current} {word}" if current else word
            if current and _width(candidate) > MAX_LINE:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)
    return lines[-4:]


def render(text: str) -> tuple[int, int, list[list[int]]] | None:
    """(x, y, píxeles con códigos de la paleta) de la frase centrada abajo; None si no hay nada que dibujar."""
    lines = wrap(text)
    if not lines:
        return None
    ascent, step, _ = _font()
    fill: dict[tuple[int, int], int] = {}
    for n, line in enumerate(lines):
        base = BOTTOM - (len(lines) - 1 - n) * step
        x = (WIDTH - _width(line)) // 2
        for ch in line:
            adv, gx, gy, w, h, levels = _glyph(ch)
            for j in range(h):
                for i in range(w):
                    v = levels[j * w + i]
                    if v:
                        key = (x + gx + i, base + gy + j)
                        fill[key] = max(fill.get(key, 0), v)
            x += adv
    if not fill:
        return None
    dots = {k: 1 + v for k, v in fill.items()}               # 2..4: blanco según cuánto cubre la letra
    r = OUTLINE
    disk = [(dx, dy) for dx in range(-r, r + 1) for dy in range(-r, r + 1) if dx * dx + dy * dy <= r * r + 1]
    for (x, y), v in fill.items():
        if v >= 2:
            for dx, dy in disk:
                dots.setdefault((x + dx, y + dy), 1)
    x0, x1 = min(x for x, _ in dots), max(x for x, _ in dots) + 1
    y0, y1 = min(y for _, y in dots), max(y for _, y in dots) + 1
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(WIDTH, x1), min(HEIGHT, y1)
    if (y1 - y0) % 2:
        y1 = min(HEIGHT, y1 + 1) if y1 < HEIGHT else y1 - 1
    pixels = [[dots.get((x, y), 0) for x in range(x0, x1)] for y in range(y0, y1)]
    return x0, y0, pixels


def _clut_body(version: int) -> bytes:
    body = bytearray([0, (version << 4) | 0x0F])
    for n, (y, cr, cb, t) in enumerate(CLUT):
        body += bytes([n, 0x40 | 0x01, y, cr, cb, t])         # paleta de 4 bits, valores completos
    return bytes(body)


def display_set(text: str, version: int, timeout: int = 10, page: int = 1) -> bytes:
    """Datos del PES (desde data_identifier) con la frase, o con la página vacía si no hay texto."""
    v = version & 0x0F
    seg = dvbsub._segment
    dds = bytes([(v << 4) | 0x07]) + (WIDTH - 1).to_bytes(2, "big") + (HEIGHT - 1).to_bytes(2, "big")
    out = bytearray(seg(dvbsub.DISPLAY_DEFINITION, page, dds))
    drawn = render(text) if text else None
    if drawn is None:
        out += seg(dvbsub.PAGE_COMPOSITION, page, bytes([timeout, (v << 4) | (2 << 2) | 0x03]))
    else:
        x0, y0, pixels = drawn
        w, h = len(pixels[0]), len(pixels)
        out += seg(dvbsub.PAGE_COMPOSITION, page, bytes([timeout, (v << 4) | (2 << 2) | 0x03, 0, 0xFF])
                   + x0.to_bytes(2, "big") + y0.to_bytes(2, "big"))
        region = bytes([0, (v << 4) | 0x08 | 0x07]) + w.to_bytes(2, "big") + h.to_bytes(2, "big")
        region += bytes([(2 << 5) | (2 << 2) | 0x03, 0, 0, 0x03]) + bytes(6)
        out += seg(dvbsub.REGION_COMPOSITION, page, region)
        out += seg(dvbsub.CLUT_DEFINITION, page, _clut_body(v))
        top, bottom = dvbsub.encode_object(pixels)
        obj = (0).to_bytes(2, "big") + bytes([(v << 4) | 0x01]) + len(top).to_bytes(2, "big")
        obj += len(bottom).to_bytes(2, "big") + top + bottom
        if len(obj) % 2:
            obj += b"\x00"
        if len(obj) > dvbsub.MAX_SEGMENT:
            return display_set("", version, timeout, page)
        out += seg(dvbsub.OBJECT_DATA, page, obj)
    out += seg(dvbsub.END_OF_DISPLAY_SET, page, b"")
    return bytes([0x20, 0x00]) + bytes(out) + b"\xff"


def _pts(value: int) -> bytes:
    return bytes([0x21 | ((value >> 29) & 0x0E), (value >> 22) & 0xFF, ((value >> 14) & 0xFE) | 1,
                  (value >> 7) & 0xFF, ((value << 1) & 0xFE) | 1])


def pes(pts: int, text: str, version: int, timeout: int = 10, page: int = 1) -> bytes:
    body = bytes([0x84, 0x80, 5]) + _pts(pts) + display_set(text, version, timeout, page)
    return b"\x00\x00\x01\xbd" + len(body).to_bytes(2, "big") + body


def packets(pid: int, data: bytes) -> bytes:
    """El PES en paquetes TS (el último relleno con el campo de adaptación); el contador lo pone quien los suelta."""
    out = bytearray()
    for n, i in enumerate(range(0, len(data), 184)):
        chunk = data[i:i + 184]
        start = 0x40 if n == 0 else 0
        if len(chunk) < 184:
            pad = 184 - len(chunk)
            adapt = bytes([pad - 1]) + (b"\x00" + b"\xff" * (pad - 2) if pad > 1 else b"")
            out += bytes([0x47, start | (pid >> 8), pid & 0xFF, 0x30]) + adapt + chunk
        else:
            out += bytes([0x47, start | (pid >> 8), pid & 0xFF, 0x10]) + chunk
    return bytes(out)


def descriptor(lang: str, kind: int = 0x14) -> bytes:
    """Descriptor de subtítulos DVB de la PMT: idioma, tipo (0x14 normales para HD, 0x20-0x24 para sordos) y la
    página con el idioma."""
    page = lang_page(lang)
    return b"\x59\x08" + lang.encode()[:3].ljust(3, b" ") + bytes([kind]) + page.to_bytes(2, "big") * 2
