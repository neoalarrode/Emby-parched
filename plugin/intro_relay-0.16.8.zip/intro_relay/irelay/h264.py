"""La intro con las cabeceras de vídeo del propio canal.

Al pasar de la intro al canal, el decodificador del cliente sigue con lo que tenía configurado. Si la intro trae
otras cabeceras (SPS/PPS: tamaño, entrelazado, contadores, color...), en el empalme tiene que reconfigurarse a
mitad del stream, y ahí es donde unos reproductores aguantan y otros se quedan en negro o fallan. Aquí la intro se
codifica con x264 de forma compatible con el canal y después se le ponen las cabeceras exactas del canal (los
mismos bytes) y se reescribe la cabecera de cada porción de imagen para que case con ellas: para el decodificador
la intro y el canal son la misma secuencia de vídeo y no hay nada que reconfigurar.

Solo H.264 de 8 bits 4:2:0 sin matrices de cuantificación propias ni grupos de porciones (lo de la TV en España);
con cualquier otra cosa `clone_plan` devuelve None y se usa la intro de siempre."""
from __future__ import annotations

import re

AUD, SEI, SPS, PPS, FILLER = 9, 6, 7, 8, 12
HIGH_PROFILES = {100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135}
_EPB = re.compile(b"\x00\x00\x03")
_NEED_EPB = re.compile(b"\x00\x00(?=[\x00-\x03])")


class Unsupported(Exception):
    """El canal usa algo que la reescritura no cubre: se usa la intro de siempre."""


# --- bytes y bits ---
def split_annexb(data: bytes) -> list[bytes]:
    """Unidades NAL (con su byte de cabecera, sin el prefijo de inicio) de un flujo Annex B."""
    out, starts = [], [m.end() for m in re.finditer(b"\x00\x00\x01", data)]
    for n, start in enumerate(starts):
        end = starts[n + 1] - 3 if n + 1 < len(starts) else len(data)
        nal = data[start:end].rstrip(b"\x00") if n + 1 < len(starts) else data[start:end]
        if nal:
            out.append(nal)
    return out


def unescape(nal: bytes) -> bytes:
    return _EPB.sub(b"\x00\x00", nal)


def escape(rbsp: bytes) -> bytes:
    return _NEED_EPB.sub(b"\x00\x00\x03", rbsp)


class BitReader:
    def __init__(self, data: bytes, pos: int = 0):
        self.value = int.from_bytes(data, "big")
        self.size = len(data) * 8
        self.pos = pos

    def u(self, n: int) -> int:
        if n == 0:
            return 0
        if self.pos + n > self.size:
            raise Unsupported("cabecera cortada")
        v = (self.value >> (self.size - self.pos - n)) & ((1 << n) - 1)
        self.pos += n
        return v

    def ue(self) -> int:
        zeros = 0
        while self.u(1) == 0:
            zeros += 1
            if zeros > 31:
                raise Unsupported("código exp-Golomb no válido")
        return (1 << zeros) - 1 + self.u(zeros)

    def se(self) -> int:
        k = self.ue()
        return (k + 1) // 2 if k % 2 else -(k // 2)

    def more_rbsp_data(self) -> bool:
        tail = self.value & ((1 << (self.size - self.pos)) - 1) if self.size > self.pos else 0
        return tail != 0 and (tail & (tail - 1)) != 0   # queda algo más que el bit de parada


class BitWriter:
    def __init__(self):
        self.value = 0
        self.size = 0

    def u(self, n: int, v: int) -> None:
        self.value = (self.value << n) | (v & ((1 << n) - 1))
        self.size += n

    def ue(self, v: int) -> None:
        v += 1
        n = v.bit_length()
        self.u(2 * n - 1, v)

    def se(self, v: int) -> None:
        self.ue(2 * v - 1 if v > 0 else -2 * v)

    def align(self, bit: int) -> None:
        while self.size % 8:
            self.u(1, bit)

    def trailing(self) -> bytes:
        self.u(1, 1)
        self.align(0)
        return self.value.to_bytes(self.size // 8, "big")


# --- conjuntos de parámetros ---
def _skip_scaling_list(r: BitReader, size: int) -> None:
    last = nxt = 8
    for _ in range(size):
        if nxt:
            nxt = (last + r.se() + 256) % 256
        last = nxt or last


def _hrd(r: BitReader) -> dict:
    cpb = r.ue() + 1
    r.u(4), r.u(4)
    for _ in range(cpb):
        r.ue(), r.ue(), r.u(1)
    return {"cpb_cnt": cpb, "initial_len": r.u(5) + 1, "removal_len": r.u(5) + 1, "output_len": r.u(5) + 1,
            "time_offset_len": r.u(5)}


def parse_sps(nal: bytes) -> dict:
    r = BitReader(unescape(nal), 8)
    s = {"profile_idc": r.u(8)}
    r.u(8)
    s["level_idc"] = r.u(8)
    s["id"] = r.ue()
    s["chroma_format_idc"], s["bit_depth"], s["scaling"] = 1, 8, False
    if s["profile_idc"] in HIGH_PROFILES:
        s["chroma_format_idc"] = r.ue()
        if s["chroma_format_idc"] == 3:
            r.u(1)
        s["bit_depth"] = 8 + r.ue()
        if r.ue() or r.u(1):
            raise Unsupported("más de 8 bits o sin transformada")
        if r.u(1):
            s["scaling"] = True
            for i in range(8 if s["chroma_format_idc"] != 3 else 12):
                if r.u(1):
                    _skip_scaling_list(r, 16 if i < 6 else 64)
    s["log2_max_frame_num"] = r.ue() + 4
    s["poc_type"] = r.ue()
    if s["poc_type"] == 0:
        s["log2_max_poc_lsb"] = r.ue() + 4
    elif s["poc_type"] == 1:
        s["delta_pic_order_always_zero"] = r.u(1)
        r.se(), r.se()
        for _ in range(r.ue()):
            r.se()
    s["max_num_ref_frames"] = r.ue()
    r.u(1)
    s["width_mbs"] = r.ue() + 1
    map_units = r.ue() + 1
    s["frame_mbs_only"] = r.u(1)
    s["mbaff"] = r.u(1) if not s["frame_mbs_only"] else 0
    s["height_mbs"] = map_units * (2 - s["frame_mbs_only"])
    r.u(1)
    s["crop"] = (r.ue(), r.ue(), r.ue(), r.ue()) if r.u(1) else (0, 0, 0, 0)
    s["pic_struct_present"], s["nal_hrd"], s["vcl_hrd"] = 0, None, None
    if r.u(1):                                     # VUI
        if r.u(1) and r.u(8) == 255:
            r.u(16), r.u(16)
        if r.u(1):
            r.u(1)
        if r.u(1):
            r.u(3), r.u(1)
            if r.u(1):
                r.u(8), r.u(8), r.u(8)
        if r.u(1):
            r.ue(), r.ue()
        if r.u(1):
            r.u(32), r.u(32), r.u(1)
        s["nal_hrd"] = _hrd(r) if r.u(1) else None
        s["vcl_hrd"] = _hrd(r) if r.u(1) else None
        if s["nal_hrd"] or s["vcl_hrd"]:
            r.u(1)
        s["pic_struct_present"] = r.u(1)
    return s


def parse_pps(nal: bytes) -> dict:
    r = BitReader(unescape(nal), 8)
    p = {"id": r.ue(), "sps_id": r.ue(), "cabac": r.u(1), "bottom_poc_present": r.u(1)}
    p["slice_groups"] = r.ue() + 1
    if p["slice_groups"] > 1:
        raise Unsupported("grupos de porciones")
    p["ref_l0"], p["ref_l1"] = r.ue() + 1, r.ue() + 1
    p["weighted_pred"], p["weighted_bipred"] = r.u(1), r.u(2)
    p["init_qp"] = 26 + r.se()
    r.se()
    p["chroma_qp_offset"] = r.se()
    p["deblocking_present"], p["constrained_intra"], p["redundant_present"] = r.u(1), r.u(1), r.u(1)
    p["transform_8x8"], p["scaling"], p["second_chroma_qp_offset"] = 0, False, p["chroma_qp_offset"]
    if r.more_rbsp_data():
        p["transform_8x8"] = r.u(1)
        p["scaling"] = bool(r.u(1))
        if not p["scaling"]:
            p["second_chroma_qp_offset"] = r.se()
    return p


def parameter_sets(es: bytes) -> list[bytes]:
    """SPS y PPS de un trozo de vídeo, la primera versión de cada uno (por tipo e identificador), en orden."""
    seen, out = set(), []
    for nal in split_annexb(es):
        kind = nal[0] & 0x1F
        if kind not in (SPS, PPS):
            continue
        try:
            key = (kind, parse_sps(nal)["id"] if kind == SPS else parse_pps(nal)["id"])
        except Exception:
            continue
        if key not in seen:
            seen.add(key)
            out.append(bytes(nal))
    return out


def clone_plan(params: list[bytes]) -> dict:
    """Qué SPS y PPS usará la intro y cómo tiene que codificarla x264 para que su contenido case con ellos."""
    spss = {parse_sps(n)["id"]: n for n in params if n[0] & 0x1F == SPS}
    ppss = [n for n in params if n[0] & 0x1F == PPS]
    if not spss or not ppss:
        raise Unsupported("el canal no trae SPS y PPS")
    candidates = []
    for nal in ppss:
        pps = parse_pps(nal)
        if pps["sps_id"] not in spss:
            continue
        sps = parse_sps(spss[pps["sps_id"]])
        if sps["scaling"] or pps["scaling"]:
            raise Unsupported("matrices de cuantificación propias")
        if sps["chroma_format_idc"] != 1 or sps["bit_depth"] != 8:
            raise Unsupported("no es 4:2:0 de 8 bits")
        candidates.append((pps["weighted_pred"], pps["chroma_qp_offset"] != pps["second_chroma_qp_offset"],
                           pps, sps))
    if not candidates:
        raise Unsupported("ningún PPS con su SPS")
    _, _, pps, sps = min(candidates, key=lambda c: (c[0], c[1], c[2]["id"]))
    return {"sps": sps, "pps": pps, "params": params,
            "width": sps["width_mbs"] * 16, "height": sps["height_mbs"] * 16,
            "intra_only": sps["max_num_ref_frames"] == 0}


# --- porciones de imagen ---
def _read_slice_header(r: BitReader, nal_type: int, ref_idc: int, sps: dict, pps: dict) -> dict:
    h = {"first_mb": r.ue(), "slice_type": r.ue(), "pps_id": r.ue()}
    kind = h["slice_type"] % 5
    r.u(sps["log2_max_frame_num"])
    field = 0
    if not sps["frame_mbs_only"]:
        field = r.u(1)
        if field:
            r.u(1)
    if field:
        raise Unsupported("x264 ha codificado campos sueltos")
    if nal_type == 5:
        r.ue()
    if sps["poc_type"] == 0:
        r.u(sps["log2_max_poc_lsb"])
        if pps["bottom_poc_present"]:
            r.se()
    elif sps["poc_type"] == 1 and not sps["delta_pic_order_always_zero"]:
        r.se()
        if pps["bottom_poc_present"]:
            r.se()
    if pps["redundant_present"]:
        r.ue()
    if kind == 1:
        raise Unsupported("x264 ha codificado fotogramas B")
    refs = pps["ref_l0"]
    if kind in (0, 3):
        if r.u(1):
            refs = r.ue() + 1
        if r.u(1):                                  # reordenación de la lista de referencias
            while True:
                idc = r.ue()
                if idc == 3:
                    break
                r.ue()
            raise Unsupported("x264 ha reordenado las referencias")
    h["refs"] = refs
    if pps["weighted_pred"] and kind in (0, 3):
        raise Unsupported("x264 ha usado predicción ponderada")
    if ref_idc:
        if nal_type == 5:
            r.u(1), r.u(1)
        elif r.u(1):
            raise Unsupported("x264 ha usado marcas de referencia")
    h["cabac_init_idc"] = r.ue() if pps["cabac"] and kind not in (2, 4) else None
    h["qp"] = pps["init_qp"] + r.se()
    if pps["deblocking_present"]:
        h["deblock"] = r.ue()
        h["alpha"], h["beta"] = (r.se(), r.se()) if h["deblock"] != 1 else (0, 0)
    else:
        h["deblock"], h["alpha"], h["beta"] = 0, 0, 0
    return h


def _write_slice_header(w: BitWriter, h: dict, nal_type: int, ref_idc: int, sps: dict, pps: dict,
                        frame_num: int, poc_lsb: int, idr_id: int, bottom_delta: int) -> None:
    kind = h["slice_type"] % 5
    w.ue(h["first_mb"])
    w.ue(h["slice_type"])
    w.ue(pps["id"])
    w.u(sps["log2_max_frame_num"], frame_num)
    if not sps["frame_mbs_only"]:
        w.u(1, 0)                                    # imagen completa (no un campo suelto)
    if nal_type == 5:
        w.ue(idr_id)
    if sps["poc_type"] == 0:
        w.u(sps["log2_max_poc_lsb"], poc_lsb)
        if pps["bottom_poc_present"]:
            w.se(bottom_delta)
    elif sps["poc_type"] == 1 and not sps["delta_pic_order_always_zero"]:
        w.se(0)
        if pps["bottom_poc_present"]:
            w.se(0)
    if pps["redundant_present"]:
        w.ue(0)
    if kind in (0, 3):
        if h["refs"] != pps["ref_l0"]:
            w.u(1, 1)
            w.ue(h["refs"] - 1)
        else:
            w.u(1, 0)
        w.u(1, 0)                                    # sin reordenar la lista de referencias
        if pps["weighted_pred"]:
            # tabla de pesos con los pesos por defecto (equivale a no ponderar)
            w.ue(0)
            w.ue(0)
            for _ in range(h["refs"]):
                w.u(1, 0)
                w.u(1, 0)
    if ref_idc:
        if nal_type == 5:
            w.u(1, 0)
            w.u(1, 0)
        else:
            w.u(1, 0)                                # ventana deslizante
    if pps["cabac"] and kind not in (2, 4):
        w.ue(h["cabac_init_idc"])
    w.se(h["qp"] - pps["init_qp"])
    if pps["deblocking_present"]:
        w.ue(h["deblock"])
        if h["deblock"] != 1:
            w.se(h["alpha"])
            w.se(h["beta"])
    elif h["deblock"] != 0 or h["alpha"] or h["beta"]:
        raise Unsupported("el canal no deja ajustar el filtro de bloques")


def _sei(payload_type: int, w: BitWriter) -> bytes:
    if w.size % 8:
        w.u(1, 1)
        w.align(0)
    body = w.value.to_bytes(w.size // 8, "big")
    out = bytearray([SEI])
    for v in (payload_type, len(body)):
        while v >= 255:
            out.append(255)
            v -= 255
        out.append(v)
    return bytes(out) + body + b"\x80"


class Rewriter:
    """Pasa el vídeo que ha codificado x264 a las cabeceras del canal, imagen a imagen."""

    def __init__(self, plan: dict, field_order: str):
        self.sps, self.pps, self.params = plan["sps"], plan["pps"], plan["params"]
        self.src_sps: dict | None = None
        self.src_pps: dict[int, dict] = {}
        self.frame_num = self.poc = self.idr_id = self.since_idr = 0
        self.max_frame_num = 1 << self.sps["log2_max_frame_num"]
        self.max_poc = 1 << self.sps.get("log2_max_poc_lsb", 4)
        interlaced = field_order != "progressive"
        self.bottom_delta = 0 if not interlaced else (1 if field_order in ("tt", "tb") else -1)
        self.pic_struct = 0 if not interlaced else (3 if field_order in ("tt", "tb") else 4)

    def _timing_sei(self, idr: bool) -> list[bytes]:
        hrd = [h for h in (self.sps["nal_hrd"], self.sps["vcl_hrd"]) if h]
        out = []
        if idr and hrd:
            w = BitWriter()
            w.ue(self.sps["id"])
            for h in hrd:
                for _ in range(h["cpb_cnt"]):
                    w.u(h["initial_len"], min(45000, (1 << h["initial_len"]) - 1))
                    w.u(h["initial_len"], 0)
            out.append(_sei(0, w))
        if hrd or self.sps["pic_struct_present"]:
            w = BitWriter()
            if hrd:
                w.u(hrd[0]["removal_len"], (2 * self.since_idr) % (1 << hrd[0]["removal_len"]))
                w.u(hrd[0]["output_len"], 0)
            if self.sps["pic_struct_present"]:
                w.u(4, self.pic_struct)
                for _ in range(1 if self.pic_struct == 0 else 2):
                    w.u(1, 0)
            out.append(_sei(1, w))
        return out

    def access_unit(self, nals: list[bytes]) -> list[bytes]:
        """Las NAL de una imagen de x264 -> las de la misma imagen con las cabeceras del canal."""
        slices, fillers = [], []
        for nal in nals:
            kind = nal[0] & 0x1F
            if kind == SPS:
                self.src_sps = parse_sps(nal)
            elif kind == PPS:
                pps = parse_pps(nal)
                self.src_pps[pps["id"]] = pps
            elif kind in (1, 5):
                slices.append(nal)
            elif kind == FILLER:
                fillers.append(nal)      # relleno de tasa fija: se conserva (Dispatcharr necesita caudal)
        if not slices:
            return []
        idr = slices[0][0] & 0x1F == 5
        if idr:
            self.frame_num = self.poc = self.since_idr = 0
        out = [bytes([AUD, 0x10 if idr else 0x30])]          # delimitador: I / I+P
        if idr:
            out += self.params
        out += self._timing_sei(idr)
        for nal in slices:
            out.append(self._slice(nal))
        out += fillers
        ref = any(n[0] & 0x60 for n in slices)
        if idr:
            self.idr_id ^= 1
        self.frame_num = (self.frame_num + (1 if ref else 0)) % self.max_frame_num
        self.poc = (self.poc + 2) % self.max_poc
        self.since_idr += 1
        return out

    def _slice(self, nal: bytes) -> bytes:
        if self.src_sps is None or not self.src_pps:
            raise Unsupported("x264 no ha dado sus cabeceras")
        nal_type, ref_idc = nal[0] & 0x1F, (nal[0] >> 5) & 3
        rbsp = unescape(nal)
        r = BitReader(rbsp, 8)
        first = BitReader(rbsp, 8)
        first.ue(), first.ue()
        src_pps = self.src_pps[first.ue()]
        h = _read_slice_header(r, nal_type, ref_idc, self.src_sps, src_pps)
        w = BitWriter()
        w.u(8, nal[0])
        _write_slice_header(w, h, nal_type, ref_idc, self.sps, self.pps, self.frame_num,
                            self.poc, self.idr_id, self.bottom_delta)
        if self.pps["cabac"]:
            # CABAC: los datos empiezan alineados a byte tras unos bits de relleno a 1; se copian tal cual
            w.align(1)
            body = rbsp[(r.pos + 7) // 8:]
            return escape(w.value.to_bytes(w.size // 8, "big") + body)
        # CAVLC: los datos siguen bit a bit tras la cabecera; se copian hasta el bit de parada
        rest = len(rbsp) * 8 - r.pos
        tail = int.from_bytes(rbsp, "big") & ((1 << rest) - 1)
        stop = (tail & -tail).bit_length() - 1            # posición del bit de parada, contada desde el final
        data_bits = rest - stop - 1
        w.u(data_bits, tail >> (stop + 1))
        return escape(w.trailing())


def rewrite_stream(es: bytes, plan: dict, field_order: str) -> bytes:
    """Flujo Annex B de x264 -> el mismo vídeo con las cabeceras exactas del canal."""
    rw = Rewriter(plan, field_order)
    out = bytearray()
    unit: list[bytes] = []

    def flush():
        for nal in rw.access_unit(unit):
            out.extend(b"\x00\x00\x00\x01" + nal)
        unit.clear()

    for nal in split_annexb(es):
        kind = nal[0] & 0x1F
        if kind in (1, 5) and any(n[0] & 0x1F in (1, 5) for n in unit):
            first_mb = BitReader(unescape(nal[:8]), 8).ue()
            if first_mb == 0:
                flush()                              # empieza otra imagen
        elif kind in (AUD, SPS, PPS, SEI) and any(n[0] & 0x1F in (1, 5) for n in unit):
            flush()
        if kind in (SEI, AUD):
            continue                                 # las de x264 no sirven: se ponen las del canal
        unit.append(nal)
    flush()
    return bytes(out)
