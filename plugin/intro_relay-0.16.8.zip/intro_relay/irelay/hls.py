"""Salida HLS para Emby: el mismo canal que sale por /r/<uuid> (intro, empalme, reconexiones), troceado en
segmentos HLS sin convertir el vídeo (ffmpeg -c copy).

  /h/lista.m3u                 la lista M3U de Dispatcharr con cada canal apuntando a su HLS en el relevo
  /h/<uuid>/index.m3u8         abre una sesión nueva (un proceso propio) y devuelve una lista maestra que apunta
                               a ella: los reproductores solo vuelven a pedir la lista de la sesión, no esta
  /h/<uuid>/<sesión>/<archivo> la lista de la sesión y sus segmentos

Cada apertura es una sesión independiente, con su proceso, su conexión con Dispatcharr y su carpeta. Una sesión
que nadie pide en IDLE_SECONDS se cierra. Las sesiones sobreviven a un reinicio del proceso principal: su carpeta
guarda el número de proceso y el principal nuevo las sigue sirviendo."""
from __future__ import annotations

import json
import logging
import os
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
import urllib.request
from pathlib import Path

log = logging.getLogger("intro_relay")

SEGMENT_SECONDS = 2
LIST_SIZE = 10
IDLE_SECONDS = 25.0     # sin peticiones de su lista ni segmentos durante esto, la sesión se cierra (s)
READY_WAIT = 25.0       # espera máxima al primer segmento antes de responder la lista maestra (s)
SID_RE = re.compile(r"^[0-9a-f]{16}$")
FILE_RE = re.compile(r"^(live\.m3u8|s\d{6}\.ts)$")
STREAM_URL_RE = re.compile(r"https?://[^\s\"']+/proxy/ts/stream/([0-9a-fA-F-]{36})[^\s\"']*")


class FfmpegSink:
    """El «cliente» de una sesión HLS: lo que sale del relevo entra en ffmpeg, que lo trocea."""

    def __init__(self, folder: Path):
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "mpegts", "-i", "pipe:0", "-map", "0",
               "-c", "copy", "-f", "hls", "-hls_time", str(SEGMENT_SECONDS), "-hls_list_size", str(LIST_SIZE),
               "-hls_flags", "delete_segments+omit_endlist+independent_segments",
               "-hls_segment_filename", str(folder / "s%06d.ts"), str(folder / "live.m3u8")]
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                     stderr=open(folder / "ffmpeg.log", "ab"))

    def write(self, data: bytes) -> None:
        if self.proc.poll() is not None:
            raise BrokenPipeError("ffmpeg terminó")
        self.proc.stdin.write(data)

    def flush(self) -> None:
        self.proc.stdin.flush()

    def close(self) -> None:
        try:
            self.proc.stdin.close()
        except OSError:
            pass
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.proc.kill()


class HlsSessions:
    def __init__(self, server):
        self.server = server
        self.root = (server.runtime or Path("/tmp")) / "hls"
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        self.sessions: dict[str, dict] = {}
        # Sesiones que dejó en marcha un proceso principal anterior (Aplicar, versión nueva del plugin)
        for folder in self.root.iterdir():
            try:
                meta = json.loads((folder / "meta.json").read_text())
                if _alive(int(meta["pid"])):
                    self.sessions[folder.name] = {"pid": int(meta["pid"]), "uuid": meta["uuid"],
                                                  "dir": folder, "last": time.monotonic()}
                    continue
            except (OSError, ValueError, KeyError):
                pass
            shutil.rmtree(folder, ignore_errors=True)
        threading.Thread(target=self._reaper, daemon=True).start()

    # --- peticiones ---
    def handle(self, handler) -> None:
        path = handler.path.split("?")[0]
        parts = [p for p in path.split("/") if p][1:]   # sin la «h»
        if parts == ["lista.m3u"]:
            return self._playlist(handler)
        if len(parts) == 2 and parts[1] == "index.m3u8" and _is_uuid(parts[0]):
            return self._open(handler, parts[0])
        if len(parts) == 3 and _is_uuid(parts[0]) and SID_RE.match(parts[1]) and FILE_RE.match(parts[2]):
            return self._file(handler, parts[1], parts[2])
        handler.send_error(404)

    def _playlist(self, handler) -> None:
        query = handler.path.split("?", 1)[1] if "?" in handler.path else ""
        url = f"{self.server.dispatcharr_url}/output/m3u" + (f"?{query}" if query else "")
        try:
            with urllib.request.urlopen(url, timeout=30) as r:
                text = r.read().decode("utf-8", errors="replace")
        except Exception as e:
            log.warning("no pude leer la lista M3U de Dispatcharr (%s): %s", url, e)
            handler.send_error(502)
            return
        host = handler.headers.get("Host") or f"127.0.0.1:{self.server.server_address[1]}"
        text = STREAM_URL_RE.sub(lambda m: f"http://{host}/h/{m.group(1)}/index.m3u8", text)
        _reply(handler, text.encode(), "audio/x-mpegurl")

    def _open(self, handler, uuid: str) -> None:
        sid = secrets.token_hex(8)
        folder = self.root / sid
        folder.mkdir(parents=True)
        pid = self.server.fork_session(lambda: self._run(uuid, folder))
        if pid is None:
            shutil.rmtree(folder, ignore_errors=True)
            handler.send_error(503)
            return
        (folder / "meta.json").write_text(json.dumps({"pid": pid, "uuid": uuid}))
        with self.lock:
            self.sessions[sid] = {"pid": pid, "uuid": uuid, "dir": folder, "last": time.monotonic()}
        log.info("[%s] sesión HLS %s abierta (proceso %d)", uuid[:8], sid, pid)
        # La intro llega al momento: se responde cuando ya hay algo que reproducir
        deadline = time.monotonic() + READY_WAIT
        while time.monotonic() < deadline and _alive(pid):
            if any(folder.glob("s*.ts")) and (folder / "live.m3u8").is_file():
                break
            time.sleep(0.2)
        with self.lock:
            if sid in self.sessions:
                self.sessions[sid]["last"] = time.monotonic()
        master = ("#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-INDEPENDENT-SEGMENTS\n"
                  f"#EXT-X-STREAM-INF:BANDWIDTH=10000000\n{sid}/live.m3u8\n")
        _reply(handler, master.encode(), "application/vnd.apple.mpegurl")

    def _file(self, handler, sid: str, name: str) -> None:
        with self.lock:
            session = self.sessions.get(sid)
            if session:
                session["last"] = time.monotonic()
        path = (self.root / sid / name)
        if session is None or not path.is_file():
            handler.send_error(404)
            return
        try:
            data = path.read_bytes()
        except OSError:
            handler.send_error(404)
            return
        kind = "application/vnd.apple.mpegurl" if name.endswith(".m3u8") else "video/mp2t"
        _reply(handler, data, kind)

    # --- proceso de la sesión ---
    def _run(self, uuid: str, folder: Path) -> None:
        from .relay import Session

        sink = FfmpegSink(folder)
        session = Session(self.server, uuid, sink)
        try:
            session.run()
        except (BrokenPipeError, ConnectionResetError, OSError):
            log.info("[%s] sesión HLS cerrada", session.tag)
        except Exception:
            log.exception("[%s] error en la sesión HLS", session.tag)
        finally:
            session.close()
            sink.close()

    # --- limpieza ---
    def _reaper(self) -> None:
        while True:
            time.sleep(5)
            now = time.monotonic()
            with self.lock:
                done = [(sid, s) for sid, s in self.sessions.items()
                        if now - s["last"] > IDLE_SECONDS or not _alive(s["pid"])]
                for sid, _ in done:
                    del self.sessions[sid]
            for sid, s in done:
                _stop(s["pid"])
                shutil.rmtree(s["dir"], ignore_errors=True)
                log.info("[%s] sesión HLS %s cerrada (sin peticiones)", s["uuid"][:8], sid)


def _is_uuid(text: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-fA-F-]{36}", text))


def _alive(pid: int) -> bool:
    try:
        os.waitpid(pid, os.WNOHANG)   # recoge al hijo si ya terminó (si es hijo de este proceso)
    except ChildProcessError:
        pass
    try:
        state = Path(f"/proc/{pid}/stat").read_text().split(")")[-1].split()[0]
    except OSError:
        return False
    return state != "Z"


def _stop(pid: int) -> None:
    """Para la sesión y su ffmpeg (todo el grupo) y espera a que terminen: ffmpeg escribe un último segmento
    al cerrarse, y la carpeta se borra después."""
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(pid, sig)
        except (ProcessLookupError, PermissionError):
            return
        for _ in range(50):
            _alive(pid)    # recoge al proceso de la sesión si es hijo de este
            try:
                os.killpg(pid, 0)
            except (ProcessLookupError, PermissionError):
                return
            if not any(_alive(int(p.name)) for p in Path("/proc").iterdir() if p.name.isdigit()
                       and _pgid(int(p.name)) == pid):
                return
            time.sleep(0.1)


def _pgid(pid: int) -> int | None:
    try:
        return int(Path(f"/proc/{pid}/stat").read_text().split(")")[-1].split()[2])
    except (OSError, ValueError, IndexError):
        return None


def _reply(handler, data: bytes, kind: str) -> None:
    handler.send_response(200)
    handler.send_header("Content-Type", kind)
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache")
    handler.end_headers()
    handler.wfile.write(data)
