"""El relevo: un pequeño servidor HTTP dentro del contenedor de Dispatcharr.

Dispatcharr pide /r/<uuid del canal> (es la fuente «Intro» de cada canal). El relevo:
  1. pide a Dispatcharr la primera fuente original del canal (/proxy/ts/stream/<stream_hash>);
  2. si llega enseguida, la reenvía ya normalizada (huecos SPA/QAA/ADS) sin intro;
  3. si tarda, envía la intro en bucle y, cuando el canal está listo, la corta en un punto limpio y
     empalma el canal con los mismos PIDs, todas las pistas y los tiempos a continuación;
  4. si una fuente falla antes de arrancar, prueba la siguiente del canal sin cortar la intro.
"""
from __future__ import annotations
import collections
import fcntl
import itertools
import json

import argparse
import logging
import os
import queue
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import socket
import socketserver
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from . import cues, dvbsub, dvbtext, h264, hlslang, intro, slots, teletext, ts, vttsrc
from .intro import IntroOptions

log = logging.getLogger("intro_relay")

INTRO_STREAM_NAME = "Intro (relevo)"
READ = ts.PACKET * 348          # ~64 KB
READY_SETTLE = 1.5              # tiempo que el canal debe seguir avanzando tras el primer fotograma clave
PROGRESS_FRESH = 0.8            # «sigue avanzando»: la marca de tiempo de vídeo subió hace menos de esto
CLOCK = 90000


BURST_MARGIN = 2.5   # el corte se da por bueno si el silencio supera 2,5 veces el hueco normal de la fuente
INTRO_LEAD = 10.0    # ventaja de la intro sobre el tiempo real: salen 10 s de golpe al empezar, para que Dispatcharr
                     # publique su lista HLS y Emby analice y saque su primer segmento sin esperar a tiempo real
IDR_WAIT = 8.0           # sin imágenes IDR en este tiempo, se arranca en cualquier fotograma clave (s)
MIN_STALL = 10.0     # por debajo, el primer hueco entre ráfagas (aún sin medir) parecería un corte
MAX_STALL = 30.0
STALL_CUSHION = 4.0  # una fuente callada no se da por perdida mientras el colchón cubra más que esto (s)
KEEPALIVE = (b"\x47\x1f\xff\x10" + b"\xff" * 184) * 7   # paquetes nulos MPEG-TS (relleno que se descarta)
KEEPALIVE_EVERY = 1.0
_SESSION_NUMBERS = itertools.count(1)   # numera cada cliente en el log


def with_params(video: dict, up: "Upstream") -> dict:
    """Formato del vídeo + las cabeceras exactas (SPS/PPS) con las que arranca el canal (para su intro)."""
    if not video or video.get("codec_name") != "h264" or up.video_pid is None:
        return video
    try:
        params = h264.parameter_sets(ts.es_of(bytes(up.initial), up.video_pid))
    except Exception as e:
        log.debug("no pude leer las cabeceras del vídeo: %s", e)
        params = []
    return {**video, "params": [p.hex() for p in params]} if params else video


def audio_signature(pat_pmt: bytes) -> tuple | None:
    """Pistas de audio que anuncia una PMT (PID, tipo e idioma de cada una), para notar cuándo cambian."""
    try:
        parsed = hlslang.parse_pmt(pat_pmt)
    except Exception:
        return None
    if parsed is None:
        return None
    return tuple((pid, stype, lang) for stype, pid, _desc, kind, lang in parsed[2] if kind == "audio")


def dvb_pages(data: bytes, pid: int) -> tuple[int, int] | None:
    """Páginas (composición, auxiliar) que declara la PMT del canal para su pista de subtítulos DVB."""
    try:
        parsed = hlslang.parse_pmt(data)
    except Exception:
        return None
    for _stype, es_pid, desc, _kind, _lang in (parsed[2] if parsed else []):
        if es_pid != pid:
            continue
        k = 0
        while k + 2 <= len(desc):
            tag, length = desc[k], desc[k + 1]
            if tag == 0x59 and length >= 8:
                d = desc[k + 2:k + 2 + length]
                return (d[4] << 8) | d[5], (d[6] << 8) | d[7]
            k += 2 + length
    return None


class OutputFixer:
    """Lo que sale hacia Dispatcharr lleva siempre la misma tabla de pistas (PMT): vídeo, las pistas de audio de la
    disposición fija y los subtítulos DVB (español para sordos, PID 0x120), traiga lo que traiga cada canal, y
    también durante la intro. Así nada cambia en el empalme ni al cambiar de canal o de fuente. Los subtítulos de
    cada canal (cada fuente usa sus páginas: La 1 la 1, Antena 3 la 0) se pasan a la página que declara esa tabla,
    que lleva el idioma (dvbtext.lang_page): si no coinciden, el reproductor no los pinta. Cada frase sale en una sola
    imagen (dvbsub.Merger) para que el OCR de Emby la lea entera. Los subtítulos de texto (fuentes DRM) van como
    frases con su inicio, su final y su texto (cues), que la salida HLS sirve como pistas WebVTT."""

    PMT_PID = 0x1000

    def __init__(self, layout: list[str], subs: dict | None = None):
        subs = subs or {}
        streams = [(0x1B, 0x100, b"")]
        for n, lang in enumerate(layout):
            streams.append((0x0F, 0x101 + n, b"\x0a\x04" + lang.encode()[:3].ljust(3, b" ") + b"\x00"))
        # la página lleva el idioma (Emby lo pierde en HLS y el parche dvb-subtitle-language lo recupera de ahí)
        self.page = dvbtext.lang_page("spa")
        if subs.get("dvb"):
            streams.append((0x06, slots.SUB_PID, dvbtext.descriptor("spa", 0x20)))   # tipo 0x20: para sordos
        self.text_pids = {slots.TEXT_PID + n for n in range(len(subs.get("text") or []))}
        for n, lang in enumerate(subs.get("text") or []):
            streams.append((0x06, slots.TEXT_PID + n, cues.descriptor(lang)))
        body = bytearray(b"\x00\x01\xc1\x00\x00")              # programa 1, versión 0, sección 0 de 0
        body += bytes([0xE1, 0x00, 0xF0, 0x00])                # PCR en el vídeo (0x100), sin descriptores
        for stype, pid, desc in streams:
            body += bytes([stype, 0xE0 | (pid >> 8), pid & 0xFF, 0xF0 | (len(desc) >> 8), len(desc) & 0xFF]) + desc
        section = bytes([0x02, 0xB0 | ((len(body) + 4) >> 8), (len(body) + 4) & 0xFF]) + bytes(body)
        section += hlslang._crc32(section).to_bytes(4, "big")
        self.pmt = b"\x00" + section                            # puntero de sección + sección
        if len(self.pmt) > 184:
            raise ValueError("demasiadas pistas para la tabla fija")
        self.pages: tuple[int, int] | None = None
        self._sub: list[bytearray] = []
        self._carry = b""
        self._text: dict[int, bytearray] = {}           # PES de texto a medias, por PID
        self._cc: dict[int, int] = {}
        self._live: dict[int, list[tuple[str, int]]] = {}   # PID -> frases en pantalla: (texto, fin)
        self._merger = dvbsub.Merger()                   # subtítulos DVB en una sola imagen por frase (OCR de Emby)
        self._merge_ok = True
        self.vtt = None                                  # vttsrc.Watcher de la fuente (final real de cada frase)
        self.vtt_index: dict[int, int] = {}              # PID de texto -> pista de subtítulos de la fuente

    def reset(self, pages: tuple[int, int] | None = None) -> None:
        """Nuevo tramo (intro, canal, reconexión): subtítulos a medias fuera, y las páginas del canal nuevo."""
        self._sub = []
        self.pages = pages
        self._text = {}
        self._live = {}
        self._merger.reset()

    def set_vtt(self, watcher, index: dict[int, int]) -> None:
        """De dónde sacar el final de cada frase de texto (la lista WebVTT de la fuente), por PID."""
        self.vtt, self.vtt_index = watcher, dict(index)

    def feed(self, data: bytes) -> bytes:
        data = self._carry + data
        whole = len(data) - len(data) % ts.PACKET
        self._carry = data[whole:]
        out = bytearray()
        for i in range(0, whole, ts.PACKET):
            packet = data[i:i + ts.PACKET]
            pid = ts.pid_of(packet)
            if pid == self.PMT_PID:
                if ts.pusi(packet):
                    out += bytes([0x47, 0x40 | (self.PMT_PID >> 8), self.PMT_PID & 0xFF, 0x10 | (packet[3] & 0x0F)])
                    out += self.pmt.ljust(184, b"\xff")
                continue                                       # continuación de una PMT larga: sobra
            if pid == slots.SUB_PID:
                out += self._subtitle(packet)
                continue
            if pid in self.text_pids:
                out += self._text_cue(pid, packet)
                continue
            out += packet
        return bytes(out)

    def _text_cue(self, pid: int, packet: bytes) -> bytes:
        """Frase de texto de la fuente (un PES con su instante) -> frase con su final (cues). El final sale de la
        lista WebVTT de la fuente; si no está, se estima por lo larga que es. La fuente reenvía la frase en pantalla
        al empezar cada segmento: mientras sigue en pantalla no se repite."""
        off = 4 + (1 + packet[4] if packet[3] & 0x20 else 0)
        if ts.pusi(packet):
            self._text[pid] = bytearray(packet[off:])
        elif pid in self._text:
            self._text[pid] += packet[off:]
        else:
            return b""
        pes = self._text[pid]
        if len(pes) < 9 or pes[:3] != b"\x00\x00\x01":
            self._text.pop(pid, None)
            return b""
        size = 6 + ((pes[4] << 8) | pes[5])
        if size > 6 and len(pes) < size:
            return b""                                   # falta el resto del PES
        del self._text[pid]
        if size > 6:
            pes = pes[:size]
        pts = ts._read_ts(bytes(pes[9:14])) if pes[7] & 0x80 and len(pes) >= 14 else None
        if pts is None:
            return b""
        text = teletext.clean(bytes(pes[9 + pes[8]:]).rstrip(b"\xff\x00").decode("utf-8", "replace"))
        if not text:
            return b""                                   # las frases ya llevan su final
        key = vttsrc.norm(text)
        # frases en pantalla (y las que acaban de terminar: un reenvío justo en su final no es una frase nueva)
        grace = 45000
        live = [(k, e) for k, e in self._live.get(pid, []) if (e + grace - pts) % ts.WRAP < ts.WRAP // 2]
        self._live[pid] = live
        end = None
        if self.vtt is not None and pid in self.vtt_index:
            try:
                end = self.vtt.end_for(self.vtt_index[pid], text, pts)
            except Exception as e:
                log.debug("subtítulos: %s", e)
        for i, (k, e) in enumerate(live):
            if k != key:
                continue
            # La misma frase reenviada (la fuente la repite al empezar cada segmento si sigue en pantalla). Si su lista
            # dice ahora que dura más de lo ya enviado (la fuente parte en dos las frases que cruzan el borde de su
            # segmento, y al enviarla solo se conocía el primer trozo), se manda la continuación, pegada a lo anterior.
            if end is not None and 0 < (end - e) % ts.WRAP < 30 * 90000 and (end - e) % ts.WRAP > 9000:
                live[i] = (key, end)
                return self._renumber(pid, dvbtext.packets(pid, cues.pes(e, (end - e) % ts.WRAP, text)))
            return b""                                   # la misma frase, reenviada, aún en pantalla
        duration = (end - pts) % ts.WRAP if end is not None else 0
        if not 0 < duration < 30 * 90000:
            duration = int(teletext.duration(text) * 90000)
        live.append((key, (pts + duration) % ts.WRAP))
        return self._renumber(pid, dvbtext.packets(pid, cues.pes(pts, duration, text)))

    def _subtitle(self, packet: bytes) -> bytes:
        """Junta el PES de subtítulos (su longitud viene en la cabecera), cambia sus páginas, junta sus regiones en
        una sola imagen y lo suelta entero, con su propio contador de continuidad."""
        return self._renumber(slots.SUB_PID, self._subtitle_pes(packet))

    def _renumber(self, pid: int, data: bytes) -> bytes:
        out = bytearray(data)
        cc = self._cc.get(pid, 0)
        for i in range(0, len(out), ts.PACKET):
            if out[i + 3] & 0x10:                              # lleva carga útil: cuenta
                out[i + 3] = (out[i + 3] & 0xF0) | cc
                cc = (cc + 1) & 0x0F
        self._cc[pid] = cc
        return bytes(out)

    def _subtitle_pes(self, packet: bytes) -> bytes:
        if ts.pusi(packet):
            self._sub = [bytearray(packet)]
        elif self._sub:
            self._sub.append(bytearray(packet))
        else:
            return b""                                         # continuación de uno empezado antes del corte
        offsets = [4 + (1 + p[4] if p[3] & 0x20 else 0) for p in self._sub]
        payload = bytearray().join(p[o:] for p, o in zip(self._sub, offsets))
        if len(payload) < 6:
            return b""
        size = 6 + ((payload[4] << 8) | payload[5])
        if size == 6:                                          # sin longitud: no se puede saber dónde acaba
            out, self._sub = b"".join(bytes(p) for p in self._sub), []
            return out
        if len(payload) < size:
            return b""
        self._rewrite(payload, size)
        merged = self._merge(bytes(payload[:size]))
        if merged is not None:
            self._sub = []
            return merged
        # se vuelve a repartir en los mismos paquetes (mismo tamaño: solo cambian bytes)
        out, pos = bytearray(), 0
        for p, o in zip(self._sub, offsets):
            n = len(p) - o
            p[o:] = payload[pos:pos + n]
            pos += n
            out += p
        self._sub = []
        return bytes(out)

    def _merge(self, pes: bytes) -> bytes | None:
        """El PES con la página en una sola región, ya en paquetes TS; None si se deja como viene."""
        if not self._merge_ok or pes[:4] != b"\x00\x00\x01\xbd" or len(pes) < 9:
            return None
        head = 9 + pes[8]
        try:
            data = self._merger.process(pes[head:])
        except Exception as e:                                 # algo que no se sabe rehacer: tal cual, como antes
            log.warning("subtítulos DVB: se dejan como vienen (%s)", e)
            self._merge_ok = False
            return None
        if data is None:
            return None
        body = pes[6:head] + data
        if len(body) > 0xFFFF:
            return None
        pes = pes[:4] + len(body).to_bytes(2, "big") + body
        out = bytearray()
        for n, i in enumerate(range(0, len(pes), 184)):
            chunk = pes[i:i + 184]
            start = 0x40 if n == 0 else 0
            pid = slots.SUB_PID
            if len(chunk) < 184:                               # el último se rellena con el campo de adaptación
                pad = 184 - len(chunk)
                adapt = bytes([pad - 1]) + (b"\x00" + b"\xff" * (pad - 2) if pad > 1 else b"")
                out += bytes([0x47, start | (pid >> 8), pid & 0xFF, 0x30]) + adapt + chunk
            else:
                out += bytes([0x47, start | (pid >> 8), pid & 0xFF, 0x10]) + chunk
        return bytes(out)

    def _rewrite(self, payload: bytearray, size: int) -> None:
        if not self.pages or payload[:3] != b"\x00\x00\x01":
            return
        j = 9 + payload[8] + 2                                 # tras la cabecera PES: data_identifier, stream_id
        while j + 6 <= size and payload[j] == 0x0F:
            page = (payload[j + 2] << 8) | payload[j + 3]
            if page in self.pages:
                payload[j + 2:j + 4] = self.page.to_bytes(2, "big")
            j += 6 + ((payload[j + 4] << 8) | payload[j + 5])


# Las consultas a la base de datos de Dispatcharr, de una en una: varias sesiones del mismo canal que arrancan a la
# vez consultaban a la vez y alguna fallaba («IndexError» dentro de Django) y esa sesión moría con «error en el relevo»
DB_LOCK = threading.Lock()


def lookup_sources(channel_uuid: str) -> list[tuple[str, str]]:
    with DB_LOCK:
        return _lookup_sources(channel_uuid)


def _lookup_sources(channel_uuid: str) -> list[tuple[str, str]]:
    """Fuentes originales del canal, en el orden que tienen en ESTE canal: [(stream_hash, nombre)], sin la del
    relevo. Se leen de la tabla que une canal y fuente (channel.streams.order_by("channelstream__order") puede
    ordenar por la posición de la fuente en otro canal si está en varios). Se salta las mismas que Dispatcharr al
    elegir fuente: sin lista M3U, con la lista desactivada o sin su perfil por defecto activo."""
    from apps.channels.models import Channel, ChannelStream
    from django.db import close_old_connections

    try:
        channel = Channel.objects.filter(uuid=channel_uuid).first()
        if channel is None:
            return []
        out = []
        links = ChannelStream.objects.filter(channel_id=channel.id).select_related("stream__m3u_account").order_by("order", "id")
        for link in links:
            s = link.stream
            if not s.stream_hash or (s.is_custom and s.name == INTRO_STREAM_NAME):
                continue
            account = s.m3u_account
            if account is None or account.is_active is False:
                continue
            if not account.profiles.filter(is_active=True, is_default=True).exists():
                continue
            out.append((s.stream_hash, s.name))
        return out
    finally:
        close_old_connections()


JUMP_REPORT = 0.5    # saltos del reloj de vídeo de la fuente que se anotan en el log (s)
GAP_REPORT = 8.0     # huecos sin datos de la fuente que se anotan uno a uno (s); los cortos solo se cuentan
                     # (hay fuentes que llegan a ráfagas cada 2-6 s: es su forma de enviar, no un fallo)
SEND_REPORT = 1.0    # esperas del cliente al recoger que se anotan (s)
LOW_CUSHION = 2.0    # por debajo de este margen se avisa de colchón bajo (s)
LIVE_LIMIT = 64 * 1024 * 1024   # lo recibido que espera a salir: cabe el colchón de un canal de bitrate alto


class ByteQueue:
    """Cola limitada por bytes (las lecturas de la fuente llegan en trozos de cualquier tamaño)."""

    def __init__(self, limit: int):
        self.limit = limit
        self.size = 0
        self._items: collections.deque = collections.deque()
        self._cond = threading.Condition()

    def put_nowait(self, data: bytes | None) -> None:
        with self._cond:
            if data is not None and self.size + len(data) > self.limit and self._items:
                raise queue.Full
            self._push(data)

    def put(self, data: bytes | None) -> None:
        with self._cond:
            while data is not None and self.size + len(data) > self.limit and self._items:
                self._cond.wait()
            self._push(data)

    def _push(self, data: bytes | None) -> None:
        self._items.append(data)
        self.size += len(data) if data else 0
        self._cond.notify_all()

    def get(self) -> bytes | None:
        with self._cond:
            while not self._items:
                self._cond.wait()
            data = self._items.popleft()
            self.size -= len(data) if data else 0
            self._cond.notify_all()
            return data


class Upstream(threading.Thread):
    """Lee una fuente de Dispatcharr y avisa cuando el canal está listo: cuando ha llegado el primer
    fotograma clave de vídeo (y un poco más para analizar las pistas). Algunas fuentes envían tablas, audio
    o relleno mucho antes que la imagen; eso no cuenta como «listo». Lo anterior al fotograma clave se descarta
    (salvo la PAT y la PMT), para que tras la intro no haya un trozo sin imagen."""

    def __init__(self, url: str, min_pts: float | None = None):
        super().__init__(daemon=True)
        self.url = url
        # Al reconectar con la misma fuente: no volver a dar por bueno lo ya emitido (Dispatcharr reenvía sus
        # últimos segundos guardados). Si la fuente reinicia su reloj desde atrás, se acepta como nuevo.
        self.min_pts = min_pts
        self.max_video_pts: float | None = None
        self.last_progress_at = time.monotonic()
        # True mientras la lectura espera porque el cliente (Emby) va más lento: eso no es perder la fuente
        self.held_back = False
        # Hueco más largo visto entre llegadas de datos: hay fuentes que llegan a ráfagas (segmentos HLS
        # cada 6-10 s) y ese hueco es normal, no una pérdida
        self.max_gap = 0.0
        # Para el log de incidencias durante la emisión (micro cortes): solo con el canal en emisión
        self.tag = ""
        self.playing = False
        self.last_data_at = time.monotonic()
        self.short_gaps = 0       # huecos cortos (ráfagas) desde el último informe de estado
        self.keyframe_seen = False
        self.ready = threading.Event()
        self.finished = threading.Event()
        self.failed_reason = ""
        self.initial = bytearray()
        self.live = ByteQueue(LIVE_LIMIT)
        self._response = None
        self._stop = threading.Event()
        self._keyframe_at = 0.0
        self.keyframe_pts: float | None = None
        self.gate_pts: float | None = None
        # Audio (y demás pistas) anterior al fotograma clave de arranque: hay fuentes con el audio retrasado
        # respecto al vídeo en el flujo, y ese audio hacía que el canal empalmara con un hueco de imagen
        self._gate_open: set[int] | None = set()
        self._gate_drop: dict[int, bool] = {}
        self._keyframe_offset = -1
        self._pmt_pids: set[int] = set()
        self._pat = b""
        self._pmt = b""
        self.video_pid: int | None = None
        self.video_type: int | None = None
        # Fotograma clave candidato a arranque: se guarda (con todo lo que llega mientras) hasta ver su primera
        # porción de imagen; solo vale si es una IDR (ver IDR_WAIT)
        self._cand: bytearray | None = None
        self._cand_es = bytearray()
        self._cand_pts: int | None = None
        self._cand_dts: int | None = None
        self._non_idr_since: float | None = None
        # Cambio de pistas de audio a mitad de emisión (p. ej. un partido que añade comentarios): se espera a la
        # siguiente imagen clave, se cierra ahí lo enviado y se vuelve a repartir desde ella (ver Session.follow)
        self.audio_sig: tuple | None = None
        self.remapping = False                # el canal en curso se ha cerrado en una imagen clave por el cambio
        self.remap_ready = threading.Event()  # y ya hay datos desde ella para volver a repartir las pistas
        self._remap_state: str | None = None  # None, "imagen" (esperando la imagen clave) o "datos"
        self._remap_at = 0.0
        self._new_pmt = b""

    def stop(self) -> None:
        self._stop.set()
        try:
            if self._response is not None:
                self._response.close()
        except Exception:
            pass

    def _progress(self, packet: bytes) -> float | None:
        """Marca de tiempo del PES de vídeo que empieza en este paquete; anota si el reloj del canal avanza."""
        pts = ts.pes_pts(packet)
        if pts is None:
            return None
        if self.max_video_pts is None or pts > self.max_video_pts or pts < self.max_video_pts - 10 * CLOCK:
            if self.playing and self.max_video_pts is not None:
                jump = (pts - self.max_video_pts) / CLOCK
                if jump > JUMP_REPORT or jump < -1.0:
                    log.warning("[%s] incidencia: salto de %+.2f s en el reloj del vídeo de la fuente",
                                self.tag, jump)
            self.max_video_pts = pts
            self.last_progress_at = time.monotonic()
        return pts

    def _gate(self, data: bytes) -> bytes:
        """Quita los PES de las pistas que no son de vídeo con marca de tiempo anterior al fotograma clave
        de arranque. Cada pista deja de filtrarse en cuanto llega a ese instante."""
        gate = self.gate_pts if self.gate_pts is not None else self.keyframe_pts
        if gate is None or self._gate_open is None:
            return data
        out = bytearray()
        for i in range(0, len(data) - ts.PACKET + 1, ts.PACKET):
            packet = data[i:i + ts.PACKET]
            pid = ts.pid_of(packet)
            if (pid in (0, ts.NULL_PID, self.video_pid) or pid in self._pmt_pids
                    or pid in self._gate_open):
                out += packet
                continue
            if ts.pusi(packet):
                pts = ts.pes_pts(packet)
                if pts is not None and pts >= gate:
                    self._gate_open.add(pid)
                    self._gate_drop.pop(pid, None)
                    out += packet
                    continue
                self._gate_drop[pid] = pts is not None
            if not self._gate_drop.get(pid, False):
                out += packet
        if self._gate_open and not any(self._gate_drop.values()):
            self._gate_open = None          # todas las pistas ya pasaron el instante de arranque
        return bytes(out)

    def buffered_seconds(self) -> float:
        """Segundos de canal recibidos desde el fotograma clave de arranque (lo que está esperando a salir)."""
        if self.keyframe_pts is None or self.max_video_pts is None:
            return 0.0
        return max(0.0, (self.max_video_pts - self.keyframe_pts) / CLOCK)

    def _stale(self, pts: float | None) -> bool:
        if self.min_pts is None or pts is None:
            return False
        return self.min_pts - 10 * CLOCK < pts <= self.min_pts

    def _end_candidate(self, idr: bool) -> None:
        cand, self._cand = self._cand, None
        now = time.monotonic()
        if not idr:
            if self._non_idr_since is None:
                self._non_idr_since = now
            if now - self._non_idr_since < IDR_WAIT:
                return
            log.warning("[%s] la fuente no envía imágenes IDR: se arranca en un fotograma clave sin IDR (algunos "
                        "clientes pueden quedarse en negro)", self.tag)
        self._keyframe_offset = len(self.initial)
        self._keyframe_at = now
        self.keyframe_pts = self._cand_pts
        # el audio se filtra desde el instante de decodificación del fotograma clave (en fuentes con
        # fotogramas B o entrelazadas va hasta 0,4 s antes que su imagen): así arranca en el corte
        self.gate_pts = self._cand_dts
        self.keyframe_seen = True
        self.initial += cand

    def _accept(self, data: bytes) -> None:
        if self.ready.is_set():
            # La pérdida se mide por bytes recibidos de la fuente (sin contar los paquetes nulos de relleno
            # que Dispatcharr manda para mantener viva la conexión). El reloj del vídeo solo se anota para no
            # repetir lo ya emitido al reconectar.
            real = False
            split = None
            for i in range(0, len(data) - ts.PACKET + 1, ts.PACKET):
                packet = data[i:i + ts.PACKET]
                pid = ts.pid_of(packet)
                if pid != ts.NULL_PID:
                    real = True
                    if pid == self.video_pid and ts.pusi(packet):
                        self._progress(packet)
                        if (self._remap_state == "imagen" and split is None and self._gate_open is None
                                and ts.is_keyframe_start(packet)):
                            split = i
                    elif pid in self._pmt_pids and ts.pusi(packet) and self._remap_state is None:
                        sig = audio_signature(self._pat + packet)
                        if sig is not None and self.audio_sig is not None and sig != self.audio_sig:
                            log.info("[%s] el canal cambia de pistas de audio (%s -> %s): se reparten de nuevo en la "
                                     "siguiente imagen clave", self.tag, [l or "?" for _, _, l in self.audio_sig],
                                     [l or "?" for _, _, l in sig])
                            self._remap_state, self._new_pmt, self.audio_sig = "imagen", packet, sig
            if real:
                now = time.monotonic()
                gap = now - self.last_data_at
                if self.playing and gap > GAP_REPORT:
                    log.warning("[%s] incidencia: la fuente estuvo %.1f s sin enviar datos", self.tag, gap)
                elif self.playing and gap > 1.0:
                    self.short_gaps += 1
                self.last_data_at = now
                self.max_gap = max(self.max_gap, now - self.last_progress_at)
                self.last_progress_at = now
            if self._gate_open is not None:
                data = self._gate(data)
            if split is not None:
                # Lo anterior a la imagen clave cierra el canal en curso; desde ella, uno nuevo con el nuevo reparto
                self._pass(data[:split])
                self.live.put(None)
                self.live = ByteQueue(LIVE_LIMIT)
                self.initial = bytearray(self._pat + self._new_pmt) + data[split:]
                self._remap_state, self._remap_at = "datos", time.monotonic()
                self.remapping = True
                return
            if self._remap_state == "datos":
                self.initial += data
                if time.monotonic() - self._remap_at >= READY_SETTLE:
                    self._remap_state = None
                    self.remap_ready.set()
                return
            self._pass(data)
            return
        self._accept_startup(data)

    def _pass(self, data: bytes) -> None:
        """Datos del canal en emisión hacia el remultiplexado (esperando si el cliente va más lento)."""
        if data:
            try:
                self.live.put_nowait(data)
            except queue.Full:
                self.held_back = True
                self.live.put(data)
                self.last_data_at = time.monotonic()
                # El tiempo de espera fue nuestro: la fuente sigue viva, el reloj de pérdida vuelve a empezar
                self.last_progress_at = time.monotonic()
                self.held_back = False

    def _accept_startup(self, data: bytes) -> None:
        """Antes de estar listo: se busca el fotograma clave de arranque y se guarda lo que llega desde él."""
        for i in range(0, len(data) - len(data) % ts.PACKET, ts.PACKET):
            packet = data[i:i + ts.PACKET]
            if packet[0] != 0x47:
                continue
            pid = ts.pid_of(packet)
            if pid == ts.NULL_PID:
                continue
            if pid == 0:
                pmts = ts.pmt_pids(packet)
                if pmts:
                    self._pmt_pids = pmts
                    self._pat = packet
            elif pid in self._pmt_pids and ts.pusi(packet):
                info = ts.pmt_video(packet)
                video = info if info is None or info == -1 else info[0]
                if info not in (None, -1):
                    self.video_type = info[1]
                if video == -1:  # canal sin vídeo (radio): no habrá fotograma clave; que lo sirva Dispatcharr
                    self.failed_reason = "el canal no tiene vídeo"
                    self._stop.set()
                    return
                if video is not None:
                    self.video_pid = video
                    self._pmt = packet
            elif pid == self.video_pid:
                # El canal arranca en una imagen IDR: muchas fuentes de difusión marcan como fotograma clave
                # imágenes I que no lo son (punto de recuperación), y su SPS/PPS no puede sustituir al de la intro
                # ahí; el cliente que copia el vídeo se queda con el de la intro y en negro
                if ts.pusi(packet):
                    pts = self._progress(packet)
                    if self._cand is not None:
                        self._end_candidate(False)      # acabó la imagen sin saber qué era: no sirve
                    if self._keyframe_offset < 0 and not self._stale(pts) and ts.is_keyframe_start(packet):
                        self._cand = bytearray()
                        self._cand_es = bytearray(ts.pes_es(packet))
                        self._cand_pts, self._cand_dts = pts, ts.pes_dts(packet)
                elif self._cand is not None:
                    self._cand_es += ts.payload(packet)
                if self._cand is not None:
                    self._cand += packet
                    kind = ts.video_access(bytes(self._cand_es), self.video_type)
                    if kind is not None or len(self._cand_es) > 256 * 1024:
                        self._end_candidate(kind == "idr")
                    continue
            if self._cand is not None:
                self._cand += packet
                continue
            if self._keyframe_offset < 0 and pid != 0 and pid not in self._pmt_pids:
                continue           # antes del fotograma clave solo interesan la PAT y la PMT
            self.initial += packet
        if self._keyframe_offset < 0:
            return
        now = time.monotonic()
        if now - self._keyframe_at >= READY_SETTLE and now - self.last_progress_at < PROGRESS_FRESH:
            self.initial = bytearray(self._pat + self._pmt) + self._gate(bytes(self.initial[self._keyframe_offset:]))
            self.audio_sig = audio_signature(self._pat + self._pmt)
            self.ready.set()

    def run(self) -> None:
        carry = b""
        try:
            req = urllib.request.Request(self.url, headers={"User-Agent": "intro-relay"})
            self._response = urllib.request.urlopen(req, timeout=90)
            while not self._stop.is_set():
                chunk = self._response.read1(READ) if hasattr(self._response, "read1") else self._response.read(READ)
                if not chunk:
                    break
                chunk = carry + chunk
                cut = len(chunk) - len(chunk) % ts.PACKET
                carry = chunk[cut:]
                self._accept(chunk[:cut])
            if not self.ready.is_set() and not self.failed_reason:
                self.failed_reason = ("la fuente terminó sin enviar imagen" if self.initial
                                      else "la fuente terminó sin enviar datos")
        except Exception as exc:  # error HTTP, conexión rechazada, tiempo agotado...
            if not self._stop.is_set():
                self.failed_reason = str(exc)
        finally:
            self.live.put(None)
            self.finished.set()


class Clip:
    """Una intro o el vídeo de reconexión en bucle, con los tiempos a continuación de lo ya enviado."""

    def __init__(self, path: Path, offset: float, audio_count: int = 3):
        self.proc = subprocess.Popen(
            # Sin -readrate: con varias pistas de audio ffmpeg 8 marca un ritmo de ~0,4x. El ritmo lo pone el
            # relevo según las marcas de tiempo; ffmpeg espera mientras no se le lee.
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-stream_loop", "-1", "-i", str(path),
             "-map", "0", "-c", "copy", "-muxdelay", "0", "-muxpreload", "0", "-output_ts_offset", f"{offset:.6f}",
             "-f", "mpegts", "-mpegts_flags", "+initial_discontinuity", *slots.pids(audio_count), "pipe:1"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.chunks: queue.Queue[bytes | None] = queue.Queue(maxsize=64)
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self) -> None:
        while True:
            data = self.proc.stdout.read(READ)
            self.chunks.put(data or None)
            if not data:
                return

    def stop(self) -> None:
        try:
            self.proc.kill()
        except Exception:
            pass


class Channel:
    """El canal real, remultiplexado al formato fijo, a partir de una fuente ya lista."""

    def __init__(self, up: Upstream, offset: float, tag: str, layout: list[str], langs: list[str] | None = None,
                 source_langs=None, subs_layout: dict | None = None, source_subs=None):
        with tempfile.NamedTemporaryFile(suffix=".ts") as probe_file:
            probe_file.write(up.initial)
            probe_file.flush()
            tracks = slots.probe_audio(["ffprobe"], probe_file.name)
            subs = slots.probe_subtitles(["ffprobe"], probe_file.name)
            data = slots.probe_data(["ffprobe"], probe_file.name)
            self.video = slots.probe_video(["ffprobe"], probe_file.name)
        if langs:
            # la fuente no trae (o trae mal) el idioma de sus pistas: el que se ha indicado a mano en el plugin
            tracks = slots.apply_overrides(tracks, langs)
            log.info("[%s] idiomas de las pistas puestos a mano: %s", tag, ", ".join(l or "?" for l in langs))
        elif source_langs is not None and any(not t.lang for t in tracks):
            # pistas sin idioma: el que declara la lista maestra de la fuente (lo que lee VLC)
            listed = source_langs()
            if listed:
                tracks = slots.apply_overrides(tracks, listed)
                log.info("[%s] idiomas de las pistas leídos de la lista de la fuente: %s%s", tag, ", ".join(listed),
                         "" if len(listed) == len(tracks) else
                         f" (la lista anuncia {len(listed)} pistas y llegan {len(tracks)})")
        # Subtítulos DVB: el primero que traiga el canal va a su hueco fijo (PID 0x120); se apunta qué páginas usa
        # para pasarlas a las de la tabla fija (ver OutputFixer)
        self.sub = next((s for s in subs if s["codec"] == "dvb_subtitle"), None)
        self.sub_pages = None
        if self.sub is not None:
            self.sub_pages = dvb_pages(bytes(up.initial), self.sub["pid"])
            log.info("[%s] subtítulos: DVB «%s» (páginas %s) -> spa para sordos", tag, self.sub["lang"] or "?",
                     "/".join(str(p) for p in self.sub_pages) if self.sub_pages else "?")
        # Subtítulos de texto (fuentes DRM): pistas de datos, con el idioma que declara la lista de la fuente
        listed = (source_subs() or []) if data and source_subs is not None else []
        text = [listed[k] if k < len(listed) else "und" for k in range(len(data))]
        if text:
            log.info("[%s] subtítulos de texto: %s -> WebVTT", tag, ", ".join(text))
        # Los de esta fuente, y los que lleva la sesión (los de la fuente con que empezó: la tabla no cambia)
        self.subs = {"dvb": self.sub is not None, "text": text}
        session = subs_layout if subs_layout is not None else self.subs
        self.extras: list[tuple[str, int]] = []
        if session.get("dvb") and self.sub is not None:
            self.extras.append((f"0:s:{self.sub['index']}", slots.SUB_PID))
        used: set[int] = set()
        self.text_map: dict[int, int] = {}      # PID de texto -> pista de subtítulos de la lista de la fuente
        for n, lang in enumerate(session.get("text") or []):
            k = next((k for k, l in enumerate(text) if l == lang and k not in used), None)
            if k is not None:
                used.add(k)
                self.extras.append((f"0:d:{data[k]['index']}", slots.TEXT_PID + n))
                self.text_map[slots.TEXT_PID + n] = k
        self.video = {**with_params(self.video, up), "subs": self.subs}
        v = self.video
        log.info("[%s] vídeo: %s %s %s %sx%s %s", tag, v.get("codec_name"), v.get("profile"), v.get("level"),
                 v.get("width"), v.get("height"), v.get("field_order") or "?")
        if not tracks:
            raise RuntimeError("el canal no trae audio")
        self.layout = list(layout)
        chosen = slots.arrange(tracks, self.layout)
        log.info("[%s] pistas %s -> %s", tag, [f"{t.index}:{t.lang or '?'}/{t.codec}" + (f"@{t.sample_rate}" if t.sample_rate not in (0, 48000) else "")
                       + (" (se convierte)" if t.needs_transcode else "") for t in tracks],
                 ", ".join(f"{name}={t.index}" for name, t in zip(self.layout, chosen)))
        self.up = up
        self.live = up.live          # su cola: si el canal cambia de pistas, la fuente sigue en otra cola nueva
        self.proc = subprocess.Popen(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-fflags", "+discardcorrupt",
             "-f", "mpegts", "-i", "pipe:0", *slots.build_args(tracks, offset, self.layout, self.extras), "pipe:1"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.chunks: queue.Queue[bytes | None] = queue.Queue(maxsize=64)
        threading.Thread(target=self._feed, daemon=True).start()
        threading.Thread(target=self._pump, daemon=True).start()

    def _feed(self) -> None:
        try:
            self.proc.stdin.write(bytes(self.up.initial))
            while True:
                data = self.live.get()
                if data is None:
                    break
                self.proc.stdin.write(data)
        except (BrokenPipeError, ValueError, OSError):
            pass
        finally:
            try:
                self.proc.stdin.close()
            except Exception:
                pass

    def _pump(self) -> None:
        while True:
            data = self.proc.stdout.read(READ)
            self.chunks.put(data or None)
            if not data:
                return

    def stop(self) -> None:
        self.up.stop()
        try:
            self.proc.kill()
        except Exception:
            pass


class Session:
    """Una petición de Dispatcharr: intro mientras arranca, el canal, y el vídeo de reconexión si se pierde la
    fuente mientras se reintenta (la misma y luego las demás del canal). Todo en un único stream MPEG-TS con los
    mismos PIDs y los tiempos siempre a continuación, cortando cada parte en un fotograma completo."""

    def __init__(self, server: "RelayServer", channel_uuid: str, wfile):
        self.s = server
        self.channel = channel_uuid
        # El número lo pone el proceso principal antes de crear el proceso de la sesión (cada proceso hijo
        # tiene su propia copia del contador)
        number = getattr(server, "session_number", None) or next(_SESSION_NUMBERS)
        self.tag = f"{channel_uuid[:8]}#{number}"
        # Cada intento pide la fuente con un id de sesión nuevo: si se repite el de un intento que Dispatcharr
        # aún está cerrando, responde 503 una y otra vez
        self.upstream_session = f"{os.getpid() % 100000}{number:06d}"
        self.attempts = itertools.count(1)
        self.wfile = wfile
        # La intro se elige en run(), cuando se sabe cuál es la fuente 1 del canal (cada fuente tiene su formato)
        self.intro_clip, self.reconnect_clip, fps = server.intro, server.reconnect, server.fps
        self.cutter = ts.PesCutter(0x100, {0x101, 0x102, 0x103}, fps)
        self.layout = list(server.layout)     # pistas de audio: la disposición fija (las mismas siempre)
        self.subs_layout: dict | None = None  # subtítulos de la sesión (los de la fuente con que empieza)
        self.fixer: OutputFixer | None = None
        self.sources: list[tuple[str, str]] = []
        self.started = time.monotonic()
        self.active: list = []          # partes en marcha (clip, canal, fuentes), para cerrarlas al final
        self.watchers: dict[str, vttsrc.Watcher] = {}   # lista WebVTT de cada fuente (final de las frases)
        self.last_pts: dict[int, float] = {}  # último instante emitido de cada fuente (para no repetirlo)
        self.clip_params: list | None = None  # cabeceras de vídeo con las que va la intro/reconexión en curso

    # --- salida y ritmo ---
    def send(self, data: bytes) -> None:
        out = self.cutter.feed(data)
        report = self.cutter.splice_report
        if report is not None:
            self.cutter.splice_report = None
            log.info("[%s] empalme: la imagen empieza %+.3f s (decodificación %+.3f s) y el audio %+.3f s "
                     "respecto al corte", self.tag, report["video"], report["video_dts"], report["audio"])
        out = self.fixer.feed(out) if out and self.fixer is not None else out
        if out:
            self.wfile.write(out)
            self.wfile.flush()

    def stall_limit(self, up: Upstream) -> float:
        """Silencio de la fuente a partir del cual se da por perdida (más largo si llega a ráfagas)."""
        return min(MAX_STALL, max(self.s.stall_seconds, MIN_STALL, BURST_MARGIN * up.max_gap))

    def pace(self, wake: threading.Event | None, lead: float | None = None) -> None:
        """Tiempo real con ventaja de unos segundos (la ráfaga): Dispatcharr abandona una fuente que va por
        debajo de 1x durante 15 s, y la ventaja cubre los segundos sin datos al perderse la fuente."""
        lead = max(self.s.burst_seconds, INTRO_LEAD) if lead is None else lead
        ahead = self.cutter.media_seconds() - (time.monotonic() - self.started) - lead
        if ahead > 0:
            if wake is not None:
                wake.wait(min(ahead, 0.5))
            else:
                time.sleep(min(ahead, 0.5))

    # --- fuentes ---
    def connect(self, sources: list[tuple[str, str]], index: int) -> Upstream:
        stream_hash, name = sources[index]
        min_pts = self.last_pts.get(index)
        up = Upstream(f"{self.s.dispatcharr_url}/proxy/ts/stream/{stream_hash}.s{self.upstream_session}{next(self.attempts) % 1000:03d}"
                      "?output_format=ts",   # el relevo lee la fuente en MPEG-TS; Emby recibe lo que Dispatcharr tenga configurado (HLS)

                      min_pts)
        up.start()
        self.active.append(up)
        log.info("[%s] pidiendo la fuente %d «%s»", self.tag, index + 1, name)
        return up

    def wait_for_source(self, sources, index: int, clip_path: Path, limit: float, first: bool,
                        up: "Upstream | None" = None):
        """Reintenta las fuentes (empezando por `index`, luego las siguientes, en ciclo) mientras envía el clip
        en bucle. Devuelve (fuente lista, índice) o (None, índice) si se agota el tiempo."""
        start = time.monotonic()
        up = up or self.connect(sources, index)
        if first and self.s.cushion <= 0 and not self.s.no_intro:
            # Con colchón siempre hay intro: es lo que cubre la espera mientras se acumula
            up.ready.wait(self.s.instant_seconds)
            if up.ready.is_set():
                log.info("[%s] canal listo al momento: sin intro", self.tag)
                return up, index
        if self.s.no_intro or clip_path is None:
            # Sin intro: mientras arranca o se reconecta solo se envía relleno (paquetes nulos, que todo reproductor
            # descarta) para que Dispatcharr no dé la fuente por muerta (salta a otra a los 8 s sin datos); el canal
            # sale en cuanto está listo
            clip = None
            log.info("[%s] %s", self.tag, "esperando a la fuente (sin intro)" if first else "reconectando (sin vídeo de reconexión)")
        else:
            clip = Clip(clip_path, self.cutter.cut() if not first else 0.0, len(self.layout))
            self.active.append(clip)
            log.info("[%s] %s", self.tag, "la fuente tarda: enviando la intro" if first else "enviando el vídeo de reconexión")
        attempts = 1
        attempt_started = clip_started = time.monotonic()
        last_keepalive = 0.0
        # La intro sale con INTRO_LEAD s de ventaja (de golpe al empezar) y luego a tiempo real, y dura un mínimo
        # Y además se alarga hasta acumular el colchón: al empalmar, ese trozo de canal sale de golpe y el
        # cliente queda con esos segundos de margen frente a ráfagas o cortes de la fuente
        while not up.ready.is_set() or (first and clip is not None and (time.monotonic() - clip_started < self.s.min_intro
                                                                     or up.buffered_seconds() < self.s.cushion)):
            abandoned = False
            if (not first and not up.keyframe_seen and not up.finished.is_set()
                    and time.monotonic() - attempt_started > self.s.attempt_timeout):
                # Dispatcharr a veces retiene la petición sin responder (p. ej. con su sesión anterior de esa
                # fuente en error): se abandona ese intento y se vuelve a probar
                up.failed_reason, abandoned = f"sin imagen en {self.s.attempt_timeout:g} s", True
            elif (up.keyframe_seen and not up.finished.is_set()
                    and time.monotonic() - up.last_progress_at > self.stall_limit(up)):
                up.failed_reason, abandoned = "llegó imagen pero se paró", True   # datos viejos reenviados y nada más
            if abandoned:
                up.stop()           # si sigue bloqueado conectando, el hilo terminará solo; no se le espera
            if up.finished.is_set() or abandoned:
                log.warning("[%s] la fuente %d falló (%s)", self.tag, index + 1, up.failed_reason)
                if not first and up.failed_reason == "el canal no tiene vídeo":
                    break
                index = (index + 1) % len(sources)
                # Al arrancar se siguen probando las fuentes (con la intro puesta) mientras quede tiempo de espera: un
                # proveedor que limita conexiones (DRM: una a la vez) retiene la petición sin datos mientras da por
                # ocupada la anterior, y el intento siguiente entra a los pocos segundos. Si la sesión se rindiera, el
                # reproductor (Apple TV) se quedaría con la intro en bucle en una sesión muerta.
                if first and attempts >= len(sources) and limit - (time.monotonic() - start) < 15:
                    break           # sin tiempo para otro intento: Dispatcharr sigue sin el relevo
                if not first or attempts >= len(sources):
                    time.sleep(1.0)  # pausa entre reintentos
                up = self.connect(sources, index)
                attempts += 1
                attempt_started = time.monotonic()
            if time.monotonic() - start > limit:
                break
            if clip is None:
                if time.monotonic() - last_keepalive >= KEEPALIVE_EVERY:
                    last_keepalive = time.monotonic()
                    self.wfile.write(KEEPALIVE)
                    self.wfile.flush()
                up.ready.wait(0.2)
                continue
            try:
                data = clip.chunks.get(timeout=0.2)
            except queue.Empty:
                continue
            if data is None:
                log.error("[%s] el clip se detuvo", self.tag)
                break
            self.send(data)
            if first:
                self.pace(None if up.ready.is_set() else up.ready, INTRO_LEAD)
            else:
                self.pace(up.ready)
        if clip is not None:
            clip.stop()
        if up.ready.is_set():
            return up, index
        log.warning("[%s] %s", self.tag, "ninguna fuente arrancó" if first else
                    f"no se pudo reconectar en {int(limit)} s")
        return None, index

    def follow(self, up: Upstream, index: int) -> None:
        """Envía el canal hasta que se pierde la fuente, volviendo a repartir las pistas cada vez que cambian."""
        remap = False
        while self.play_channel(up, index, remap) == "remap":
            remap = True
            if not up.remap_ready.wait(15.0) or up.finished.is_set():
                log.warning("[%s] se perdió la fuente al cambiar de pistas", self.tag)
                return

    def play_channel(self, up: Upstream, index: int, remap: bool = False) -> bool | str:
        """Envía el canal hasta que se pierde la fuente: True si se perdió (hay que reconectar), "remap" si el
        canal ha cambiado de pistas y se ha cerrado en una imagen clave para seguir desde ella con otro reparto."""
        if remap:
            up.remapping = False
            up.remap_ready.clear()
        offset = self.cutter.cut() if self.cutter.start_pts is not None else 0.0
        source_hash, source_name = self.sources[index]
        channel = Channel(up, offset, self.tag, self.layout, self.s.lang_overrides(source_name),
                          lambda: self.s.listed_languages(source_hash), self.subs_layout,
                          lambda: self.s.listed_subtitles(source_hash))
        if self.fixer is None:
            self.subs_layout = channel.subs
            self.fixer = OutputFixer(self.layout, self.subs_layout)
        self.fixer.reset(channel.sub_pages)
        self.fixer.set_vtt(self.vtt_watcher(source_hash, channel.text_map), channel.text_map)
        self.active.append(channel)
        retimer = ts.Retimer(self.cutter.video_pid, offset, by_pts=remap)
        if remap:
            log.info("[%s] pistas repartidas de nuevo; el canal sigue (empalme en %.3f s)", self.tag, offset)
            return self._stream(up, index, channel, retimer)
        self.s.remember_format(self.sources[index][0], channel.video)
        if channel.video.get("params") and self.clip_params is not None:
            if channel.video["params"] == self.clip_params:
                log.info("[%s] empalme limpio: el canal trae las mismas cabeceras de vídeo que la intro", self.tag)
            else:
                # el canal ha cambiado de cabeceras desde que se miró (o es otra fuente): esta vez el reproductor
                # se reconfigura; la próxima ya irá con las nuevas (se acaban de guardar)
                log.warning("[%s] incidencia: el canal trae cabeceras de vídeo distintas a las de la intro; "
                            "su intro se rehace con las nuevas para la próxima vez", self.tag)
        elif self.clip_params is None and self.cutter.start_pts is not None:
            log.warning("[%s] incidencia: la intro no llevaba las cabeceras del canal (aún no se conocían o no "
                        "son H.264): el reproductor se reconfigura en el empalme", self.tag)
        log.info("[%s] canal en emisión (empalme en %.3f s, colchón de %.1f s)", self.tag, offset,
                 up.buffered_seconds())
        up.tag, up.playing, up.last_data_at = self.tag, True, time.monotonic()
        return self._stream(up, index, channel, retimer)

    def _stream(self, up: Upstream, index: int, channel: "Channel", retimer: "ts.Retimer") -> bool | str:
        low_cushion = False
        next_check = time.monotonic() + 5.0
        next_status = time.monotonic() + 60.0
        while True:
            try:
                data = channel.chunks.get(timeout=0.5)
            except queue.Empty:
                data = b""
            if data is None:
                if up.remapping:
                    # el canal en curso terminó entero en la imagen clave: se suelta lo que quedaba y se sigue
                    channel.proc.kill()
                    out = self.cutter.flush()
                    out = self.fixer.feed(out) if self.fixer is not None else out
                    if out:
                        self.wfile.write(out)
                        self.wfile.flush()
                    return "remap"
                reason = "la fuente se cerró"
                break
            if data:
                sent_at = time.monotonic()
                self.send(retimer.feed(data))
                waited = time.monotonic() - sent_at
                if waited > SEND_REPORT:
                    log.warning("[%s] incidencia: el cliente tardó %.1f s en recoger datos", self.tag, waited)
            now = time.monotonic()
            if now >= next_check:
                next_check = now + 1.0
                cushion = self.cutter.media_seconds() - (now - self.started)
                if now >= next_status:
                    next_status = now + 60.0
                    log.info("[%s] estado: colchón %.1f s, mayor hueco de la fuente %.1f s, %d huecos cortos en "
                             "el último minuto", self.tag, cushion, up.max_gap, up.short_gaps)
                    up.short_gaps = 0
                if cushion < LOW_CUSHION and not low_cushion:
                    low_cushion = True
                    log.warning("[%s] incidencia: colchón bajo (%.1f s de margen)", self.tag, cushion)
                elif cushion > LOW_CUSHION + 2 and low_cushion:
                    low_cushion = False
                    log.info("[%s] colchón recuperado (%.1f s)", self.tag, cushion)
            # El espectador sigue viendo el canal mientras dura el colchón: un silencio de la fuente (las que llegan a
            # ráfagas tienen huecos de 10-12 s, y al empezar aún no se han medido) solo se da por pérdida cuando el
            # colchón está a punto de acabarse, o como mucho a los MAX_STALL s
            limit = self.stall_limit(up)
            silent = time.monotonic() - up.last_progress_at
            cushion = self.cutter.media_seconds() - (time.monotonic() - self.started)
            if not up.held_back and silent > limit and (cushion < STALL_CUSHION or silent > MAX_STALL):
                reason = (f"sin datos de la fuente desde hace {silent:.0f} s, con {max(cushion, 0):.1f} s de colchón "
                          f"(la fuente llega a ráfagas de hasta {up.max_gap:.1f} s)")
                break
        up.playing = False
        channel.stop()
        if up.max_video_pts is not None:
            self.last_pts[index] = up.max_video_pts
        log.warning("[%s] se perdió la fuente (%s)", self.tag, reason)
        return True

    def run(self) -> None:
        sources = lookup_sources(self.channel)
        if not sources:
            log.warning("[%s] el canal no tiene fuentes originales", self.tag)
            return
        self.sources = sources
        log.info("[%s] fuentes del canal, en orden: %s", self.tag, ", ".join(f"«{n}»" for _, n in sources))
        first_source = sources[0][0]
        self.s._reload_formats()
        if self.s.no_intro:
            self.intro_clip = self.reconnect_clip = None
            self.cutter = ts.PesCutter(0x100, slots.audio_pids(len(self.layout)), self.s.fps)
            up, index = self.wait_for_source(sources, 0, None, self.s.max_wait, first=True)
            if up is not None:
                log.info("[%s] canal listo tras %.1f s", self.tag, time.monotonic() - self.started)
            while up is not None:
                self.follow(up, index)
                up, index = self.wait_for_source(sources, index, None, self.s.reconnect_wait, first=False)
                if up is not None:
                    log.info("[%s] reconectado con la fuente %d", self.tag, index + 1)
            return
        # La intro sale siempre desde el primer momento. Si ya existe la versión hecha con las cabeceras exactas de
        # esta fuente, va esa (empalme sin que el reproductor se reconfigure); si no (primera vez, aún se está
        # haciendo, o no se puede hacer), la normal. Las cabeceras y los subtítulos del canal se aprenden igual al
        # llegar, y su intro queda lista para la próxima vez.
        video = self.s.formats.get(first_source)
        self.intro_clip, self.reconnect_clip, fps = self.s.clips_for(first_source)
        if self.intro_clip == self.s.intro:
            if video and video.get("params"):
                try:
                    self.s.ensure_variants(video)
                except Exception as e:
                    log.info("[%s] no pude preparar su intro: %s", self.tag, e)
            log.info("[%s] intro: la normal (%s)", self.tag,
                     "primera reproducción de esta fuente" if not video
                     else f"vídeo {video.get('codec_name')}: no puede llevar sus cabeceras"
                     if video.get("codec_name") != "h264" else "la de sus cabeceras aún no está hecha")
        else:
            log.info("[%s] intro: versión %s %s %sx%s %s con sus cabeceras de vídeo", self.tag, video.get("profile"),
                     video.get("level"), video.get("width"), video.get("height"), video.get("field_order"))
        self.clip_params = self.s.params_of(first_source) if self.intro_clip not in (None, self.s.intro) else None
        self.cutter = ts.PesCutter(0x100, slots.audio_pids(len(self.layout)), fps)
        if self.intro_clip is not None:
            # la tabla de pistas sale ya con la intro: con los subtítulos que se vieron en esta fuente
            self.subs_layout = (video or {}).get("subs") or {"dvb": False, "text": []}
            self.fixer = OutputFixer(self.layout, self.subs_layout)
        up, index = self.wait_for_source(sources, 0, self.intro_clip, self.s.max_wait, first=True)
        if up is not None:
            log.info("[%s] canal listo tras %.1f s", self.tag, time.monotonic() - self.started)
        while up is not None:
            self.follow(up, index)
            # Reconexión: primero la misma fuente, luego las demás del canal, con el vídeo de reconexión hecho con
            # las cabeceras de la fuente que se estaba viendo (se prepara durante su primera reproducción). Siempre
            # con vídeo: con salida HLS, una lista que no avanza en 45 s Dispatcharr la da por muerta
            source = self.sources[index][0]
            self.reconnect_clip = self.s.clips_for(source)[1]
            self.clip_params = (self.s.params_of(source)
                                if self.reconnect_clip not in (None, self.s.reconnect) else None)
            up, index = self.wait_for_source(sources, index, self.reconnect_clip, self.s.reconnect_wait, first=False)
            if up is not None:
                log.info("[%s] reconectado con la fuente %d", self.tag, index + 1)

    def vtt_watcher(self, source_hash: str, text_map: dict[int, int]):
        """El lector de la lista WebVTT de esa fuente (uno por fuente y sesión), o None si no hay texto."""
        if not text_map:
            return None
        wanted = sorted(set(text_map.values()))
        watcher = self.watchers.get(source_hash)
        if watcher is not None and set(wanted) <= set(watcher.indices):
            return watcher
        if watcher is not None:
            watcher.stop()
        url, agent = self.s.source_url(source_hash)
        if not url.startswith(("http://", "https://")):
            return None
        watcher = vttsrc.Watcher(url, agent or "VLC/3.0.21 LibVLC/3.0.21", wanted, self.tag).start()
        self.watchers[source_hash] = watcher
        return watcher

    def close(self) -> None:
        for watcher in self.watchers.values():
            watcher.stop()
        for part in self.active:
            try:
                part.stop()
            except Exception:
                pass


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    server: "RelayServer"

    def do_GET(self) -> None:  # noqa: N802
        match = re.fullmatch(r"/r/([0-9a-fA-F-]{32,36})", self.path.split("?")[0])
        if self.path == "/health":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(f"ok {os.getpid()}".encode())
            return
        if self.path.startswith("/h/"):
            if self.server.hls is None:
                self.send_error(404, "la salida HLS está desactivada")
            else:
                self.server.hls.handle(self)
            return
        if not match:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", "video/mp2t")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        session = Session(self.server, match.group(1), self.wfile)
        try:
            session.run()
        except (BrokenPipeError, ConnectionResetError):
            log.info("[%s] el cliente se desconectó", session.tag)
        except Exception:
            log.exception("[%s] error en el relevo", session.tag)
        finally:
            session.close()

    def log_message(self, fmt, *args) -> None:  # silencia el log por petición de http.server
        pass


class RelayServer(socketserver.ForkingMixIn, HTTPServer):
    """Un proceso por sesión: el proceso principal solo recibe las peticiones y contesta /health; cada cliente
    que abre un canal se atiende en un proceso propio. Si una sesión se cuelga o se cae, solo se corta esa, y
    al renovar el relevo (Aplicar, versión nueva del plugin) las sesiones en curso siguen con su proceso hasta
    que el espectador cierre el canal: solo se sustituye el proceso principal."""
    allow_reuse_address = True
    max_children = 1_000_000   # sin límite: ForkingMixIn esperaría a que acabe alguna antes de atender otra
    block_on_close = False
    session_number: int | None = None

    def __init__(self, port: int, intro: Path, reconnect: Path, dispatcharr_url: str, fps: int,
                 instant_seconds: float, max_wait: int, burst_seconds: int, reconnect_wait: int, stall_seconds: float,
                 min_intro: float = 8.0, cushion: float = 10.0, intro_src: str = "", reconnect_src: str = "",
                 runtime: Path | None = None, narrower: int = 16, listen: str = "127.0.0.1", hls: bool = False,
                 no_intro: bool = False, layout: list[str] | None = None):
        super().__init__((listen, port), Handler)
        self.no_intro = no_intro
        self.layout = list(layout or slots.SLOTS)   # pistas de audio fijas de toda la salida
        # (aquí `intro` es el parámetro, no el módulo)
        self.intro_base = IntroOptions(narrower=narrower, audio=tuple(self.layout))
        self.intro = intro
        self.reconnect = reconnect
        self.reconnect_wait = reconnect_wait
        self.stall_seconds = stall_seconds
        self.attempt_timeout = 12.0
        self.dispatcharr_url = dispatcharr_url.rstrip("/")
        self.fps = fps
        self.instant_seconds = instant_seconds
        self.max_wait = max_wait
        self.burst_seconds = burst_seconds
        self.min_intro = min_intro
        self.cushion = cushion
        # Intro y vídeo de reconexión con el mismo formato que cada canal (perfil, entrelazado...): si el
        # cliente copia el vídeo sin transcodificar y el formato cambia en el empalme, se queda en negro
        if no_intro:
            intro_src = reconnect_src = ""     # sin intro no se preparan versiones de los vídeos
        elif not intro_src and runtime and (runtime / "sources.json").is_file():
            try:
                saved = json.loads((runtime / "sources.json").read_text())
                intro_src, reconnect_src = saved.get("intro", ""), saved.get("reconnect", "")
            except ValueError:
                pass
        self.sources = {"intro": Path(intro_src) if intro_src else None,
                        "reconnect": Path(reconnect_src or intro_src) if (reconnect_src or intro_src) else None}
        self.runtime = runtime
        self.formats_file = runtime / "formats.json" if runtime else None
        self.variant_dir = runtime / "cache" / "variants" if runtime else None
        self._formats_lock = threading.Lock()
        self._building: set[str] = set()
        self._threads: list[threading.Thread] = []
        self._origins: dict[str, tuple] = {}
        self.formats: dict[str, dict] = {}
        if self.formats_file and self.formats_file.is_file():
            try:
                self.formats = json.loads(self.formats_file.read_text())
            except ValueError:
                self.formats = {}
        # Versiones anteriores guardaban el formato por canal: se pasa a su fuente 1
        for key in [k for k in self.formats if len(k) == 36 and k.count("-") == 4]:
            video = self.formats.pop(key)
            try:
                sources = lookup_sources(key)
            except Exception:
                sources = []
            if sources:
                self.formats.setdefault(sources[0][0], video)
        for video in {json.dumps(v, sort_keys=True): v for v in self.formats.values()}.values():
            self.ensure_variants(video)
        from .hls import HlsSessions

        self.hls = HlsSessions(self) if hls else None

    def process_request(self, request, client_address) -> None:
        try:
            head = request.recv(16, socket.MSG_PEEK)
        except OSError:
            head = b""
        if head.startswith(b"GET /health") or head.startswith(b"GET /h/"):
            # Se contesta en el proceso principal, que no hace nada más: responde siempre al momento
            threading.Thread(target=self._serve_inline, args=(request, client_address), daemon=True).start()
            return
        self.session_number = next(_SESSION_NUMBERS)
        try:
            from django.db import connections

            connections.close_all()   # una conexión a la base de datos no puede compartirse entre procesos
        except Exception:
            pass
        try:
            pid = os.fork()
        except OSError as e:
            log.warning("no se pudo crear el proceso de la sesión (%s): se atiende en el principal", e)
            threading.Thread(target=self._serve_inline, args=(request, client_address), daemon=True).start()
            return
        if pid:
            if self.active_children is None:
                self.active_children = set()
            self.active_children.add(pid)
            self.close_request(request)
            return
        # Proceso de la sesión: suelta el puerto (el relevo nuevo tiene que poder abrirlo aunque esta sesión siga)
        status = 1
        marker = self.runtime / "sesiones" / str(os.getpid()) if self.runtime else None
        try:
            self.socket.close()
            self._building, self._threads = set(), []
            if marker:
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text("")
            self.finish_request(request, client_address)
            status = 0
            # Si la sesión dejó a medias una versión de la intro, se termina antes de salir (el espectador ya
            # se fue; así queda lista para la próxima vez)
            for thread in self._threads:
                thread.join(timeout=180)
        except Exception:
            log.exception("error en el proceso de la sesión")
        finally:
            try:
                self.shutdown_request(request)
            finally:
                if marker:
                    try:
                        marker.unlink()
                    except OSError:
                        pass
                logging.shutdown()
                os._exit(status)

    def fork_session(self, run) -> int | None:
        """Lanza run() en un proceso propio (sesión HLS) y devuelve su número; None si no se pudo."""
        self.session_number = next(_SESSION_NUMBERS)
        try:
            from django.db import connections

            connections.close_all()
        except Exception:
            pass
        try:
            pid = os.fork()
        except OSError as e:
            log.warning("no se pudo crear el proceso de la sesión HLS: %s", e)
            return None
        if pid:
            return pid
        status = 1
        marker = self.runtime / "sesiones" / str(os.getpid()) if self.runtime else None
        try:
            os.setsid()      # grupo propio: al cerrarla se para también su ffmpeg
            self.socket.close()
            self._building, self._threads = set(), []
            if marker:
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text("")
            run()
            status = 0
            for thread in self._threads:
                thread.join(timeout=180)
        except BaseException:
            log.exception("error en el proceso de la sesión HLS")
        finally:
            if marker:
                try:
                    marker.unlink()
                except OSError:
                    pass
            logging.shutdown()
            os._exit(status)

    def _serve_inline(self, request, client_address) -> None:
        try:
            self.finish_request(request, client_address)
        except Exception:
            pass
        finally:
            self.shutdown_request(request)

    def _reload_formats(self) -> None:
        """Formatos aprendidos por otras sesiones (cada una en su proceso) desde que arrancó esta."""
        if self.formats_file is None or not self.formats_file.is_file():
            return
        try:
            saved = json.loads(self.formats_file.read_text())
        except (OSError, ValueError):
            return
        with self._formats_lock:
            for key, video in saved.items():
                # lo guardado manda: cada sesión (un proceso aparte) escribe ahí lo último que ha visto de su
                # fuente (cabeceras, subtítulos...), y lo que tiene en memoria el proceso principal puede ser viejo
                self.formats[key] = video

    def _variant(self, kind: str, video: dict) -> Path | None:
        src = self.sources.get(kind)
        options = intro.options_for(video, self.intro_base) if src and self.variant_dir else None
        if options is None or not src.is_file():
            return None
        return intro.target(src, self.variant_dir, options)

    def ensure_variants(self, video: dict) -> None:
        for kind in ("intro", "reconnect"):
            path = self._variant(kind, video)
            if path is None or path.is_file():
                continue
            with self._formats_lock:
                if str(path) in self._building:
                    continue
                self._building.add(str(path))
            options = intro.options_for(video, self.intro_base)

            def build(src=self.sources[kind], options=options, path=path):
                try:
                    self.variant_dir.mkdir(parents=True, exist_ok=True)
                    with open(str(path) + ".lock", "w") as lock:
                        try:
                            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        except OSError:
                            return      # otra sesión la está preparando
                        if path.is_file():
                            return
                        intro.build(src, self.variant_dir, options)
                    log.info("preparada una versión de la intro: %s %s %sx%s %s", options.profile, options.level,
                             options.width, options.height, options.field_order)
                except Exception as e:
                    log.warning("no se pudo preparar la versión de la intro (%s): %s", path.name, e)
                finally:
                    with self._formats_lock:
                        self._building.discard(str(path))
            thread = threading.Thread(target=build, daemon=True)
            thread.start()
            self._threads.append(thread)

    def remember_format(self, source: str, video: dict) -> None:
        if not video or self.formats_file is None:
            return
        with self._formats_lock:
            if self.formats.get(source) != video:
                self.formats[source] = video
                try:
                    # Varias sesiones (procesos) escriben este archivo: se mezcla con lo que haya y se sustituye
                    # de una vez
                    with open(str(self.formats_file) + ".lock", "w") as lock:
                        fcntl.flock(lock, fcntl.LOCK_EX)
                        try:
                            saved = json.loads(self.formats_file.read_text()) if self.formats_file.is_file() else {}
                        except ValueError:
                            saved = {}
                        saved.update({source: video})
                        tmp = self.formats_file.with_suffix(f".{os.getpid()}.tmp")
                        tmp.write_text(json.dumps(saved))
                        tmp.replace(self.formats_file)
                    for key, value in saved.items():
                        self.formats.setdefault(key, value)
                except OSError:
                    pass
        self.ensure_variants(video)

    def _origin(self, source: str) -> tuple | None:
        """(proveedor = lista M3U, resolución) de una fuente, para deducir formatos."""
        cached = self._origins.get(source)
        if cached is not None:
            return cached or None
        origin = ()
        try:
            from apps.channels.models import Stream

            with DB_LOCK:
                stream = Stream.objects.filter(stream_hash=source).first()
            if stream:
                stats = stream.stream_stats or {}
                origin = (stream.m3u_account_id, stats.get("resolution") or "")
        except Exception as e:
            log.debug("no puedo leer el origen de la fuente %s: %s", source, e)
        self._origins[source] = origin
        return origin or None

    def guess_format(self, source: str) -> dict | None:
        """Formato de una fuente aún no vista, deducido de las ya conocidas del mismo proveedor (y misma
        resolución si se sabe), solo si todas coinciden: p. ej. todos los canales de Movistar por UDP. En H.264 eso
        incluye las cabeceras exactas del vídeo (SPS/PPS): si todos los canales conocidos de ese proveedor y
        resolución salen del mismo codificador con las mismas, la intro de un canal nuevo va con ellas desde la
        primera vez, sin abrir nada más. Si no coinciden, se miran las del propio canal (por la misma conexión)."""
        origin = self._origin(source)
        if not origin or origin[0] is None:
            return None
        votes: dict[str, list] = {}
        for known, video in list(self.formats.items()):
            if video.get("codec_name") == "h264":
                continue        # H.264: cada fuente con sus propias cabeceras, aprendidas en su primera reproducción
            other = self._origin(known)
            if not other or other[0] != origin[0]:
                continue
            if origin[1] and other[1] and origin[1] != other[1]:
                continue
            key = json.dumps(video, sort_keys=True)
            votes.setdefault(key, [0, video])[0] += 1
        if len(votes) != 1:
            # sin fuentes conocidas, o el proveedor mezcla formatos (HD y SD, 1080i y 1080p...): no se adivina,
            # se mira el formato real de la fuente antes de la intro
            return None
        return next(iter(votes.values()))[1]

    def lang_overrides(self, source_name: str) -> list[str] | None:
        """Idiomas puestos a mano para las pistas de esa fuente (se leen en cada sesión: sin reiniciar nada)."""
        if self.runtime is None:
            return None
        try:
            saved = json.loads((self.runtime / "idiomas.json").read_text())
        except (OSError, ValueError):
            return None
        return saved.get(source_name.casefold())

    def listed_languages(self, source: str) -> list[str]:
        return self.listed(source).get("audio") or []

    def listed_subtitles(self, source: str) -> list[str]:
        return self.listed(source).get("subtitles") or []

    def listed(self, source: str) -> dict:
        """Idioma de las pistas de audio y de subtítulos de una fuente según su lista maestra HLS (la de la
        dirección de la fuente en Dispatcharr). Se pide una sola vez por fuente (unos KB) y se guarda; si no es
        una lista HLS, nada."""
        cache = self.runtime / "listas.json" if self.runtime else None
        try:
            saved = json.loads(cache.read_text()) if cache and cache.is_file() else {}
        except (OSError, ValueError):
            saved = {}
        entry = saved.get(source)
        if entry is not None and (entry.get("audio") or time.time() - entry.get("at", 0) < 6 * 3600):
            return entry
        langs, subs = [], []
        try:
            url, agent = self.source_url(source)
            if url.startswith(("http://", "https://")):
                req = urllib.request.Request(url, headers={"User-Agent": agent or "VLC/3.0.21 LibVLC/3.0.21"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    head = r.read(256 * 1024)
                if head.lstrip().startswith(b"#EXTM3U"):
                    text = head.decode("utf-8", "replace")
                    langs = slots.rendition_languages(text, "AUDIO")
                    subs = slots.rendition_languages(text, "SUBTITLES")
        except Exception as e:
            log.info("no pude leer la lista de la fuente %s: %s", source[:8], e)
        if cache is not None:
            try:
                with open(str(cache) + ".lock", "w") as lock:
                    fcntl.flock(lock, fcntl.LOCK_EX)
                    try:
                        saved = json.loads(cache.read_text()) if cache.is_file() else {}
                    except ValueError:
                        saved = {}
                    saved[source] = {"audio": langs, "subtitles": subs, "at": time.time()}
                    cache.write_text(json.dumps(saved))
            except OSError:
                pass
        return {"audio": langs, "subtitles": subs}

    def source_url(self, source: str) -> tuple[str, str | None]:
        """(dirección, agente de usuario de su cuenta) de una fuente de Dispatcharr; ("", None) si no se sabe."""
        try:
            from apps.channels.models import Stream
            from django.db import close_old_connections
        except Exception:
            return "", None
        try:
            with DB_LOCK:
                stream = Stream.objects.select_related("m3u_account").filter(stream_hash=source).first()
                url = stream.url if stream else ""
                account = stream.m3u_account if stream else None
                agent = None
                if account is not None:
                    getter = getattr(account, "get_user_agent_string", None)
                    agent = getter() if getter else None
            return url or "", agent
        except Exception as e:
            log.info("no pude leer la dirección de la fuente %s: %s", source[:8], e)
            return "", None
        finally:
            close_old_connections()

    def params_of(self, source: str) -> list | None:
        return (self.formats.get(source) or {}).get("params")

    def clips_for(self, source: str) -> tuple[Path, Path, float]:
        """(intro, reconexión, fps) para una fuente: la versión con su formato si ya existe."""
        if source not in self.formats:
            self._reload_formats()
        video = self.formats.get(source) or self.guess_format(source)
        if video:
            intro_clip, reconnect_clip = self._variant("intro", video), self._variant("reconnect", video)
            if intro_clip and reconnect_clip and intro_clip.is_file() and reconnect_clip.is_file():
                return intro_clip, reconnect_clip, intro.frame_rate(intro.options_for(video, self.intro_base))
        return self.intro, self.reconnect, self.fps


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=9722)
    ap.add_argument("--intro", default="")
    ap.add_argument("--no-intro", action="store_true")
    ap.add_argument("--audio", default=",".join(slots.SLOTS))
    ap.add_argument("--reconnect", default="")
    ap.add_argument("--reconnect-wait", type=int, default=300)
    ap.add_argument("--stall", type=float, default=4.0)
    ap.add_argument("--dispatcharr-url", default="http://127.0.0.1:9191")
    ap.add_argument("--fps", type=int, default=25)
    ap.add_argument("--instant", type=float, default=6.0)
    ap.add_argument("--max-wait", type=int, default=90)
    ap.add_argument("--burst", type=int, default=6)
    ap.add_argument("--min-intro", type=float, default=8.0)
    ap.add_argument("--cushion", type=float, default=10.0)
    ap.add_argument("--intro-narrower", type=int, default=16)
    ap.add_argument("--intro-src", default="")
    ap.add_argument("--reconnect-src", default="")
    ap.add_argument("--log", default="")
    ap.add_argument("--listen", default="127.0.0.1")
    ap.add_argument("--hls", action="store_true")
    a = ap.parse_args(argv)
    sys.path.insert(0, "/app")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "dispatcharr.settings")
    import django
    django.setup()
    # Después de django.setup(), que reconfigura el logging
    handler = logging.FileHandler(a.log) if a.log else logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.handlers[:] = [handler]
    log.setLevel(logging.INFO)
    log.propagate = False
    if not a.intro and not a.no_intro:
        ap.error("falta --intro (o --no-intro)")
    intro_path = Path(a.intro) if a.intro else None
    reconnect_path = Path(a.reconnect or a.intro) if (a.reconnect or a.intro) else None
    server = RelayServer(a.port, intro_path, reconnect_path, a.dispatcharr_url, a.fps, a.instant,
                         a.max_wait, a.burst, a.reconnect_wait, a.stall, a.min_intro, a.cushion,
                         a.intro_src, a.reconnect_src, Path(a.log).parent if a.log else None, a.intro_narrower,
                         a.listen, a.hls, a.no_intro, slots.parse_layout(a.audio))
    from irelay.process import code_version

    log.info("relevo escuchando en %s:%d %s (código %s)%s", a.listen, a.port,
             ("sin intro: solo normalización del audio" if a.no_intro else f"con la intro {a.intro}")
             + f", pistas de audio {','.join(server.layout)}", code_version(),
             ", salida HLS para Emby en /h/lista.m3u" if a.hls else "")
    server.serve_forever()


if __name__ == "__main__":
    main()
