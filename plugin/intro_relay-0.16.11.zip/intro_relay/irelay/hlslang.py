"""Idioma de las pistas de audio en la salida HLS de Dispatcharr.

Dispatcharr (live_proxy) sirve /proxy/hls/<token>/index.m3u8 como lista de reproducción simple: los segmentos
llevan el idioma de cada pista en su tabla PMT, pero el ffmpeg 5.1 de Emby no pasa ese idioma de los segmentos a
las pistas cuando lee HLS (lo hace a partir de ffmpeg 6.1). Tampoco sirve declarar los idiomas en la lista maestra
para pistas dentro de la misma lista: ffmpeg 5.1 los aplica todos a la primera pista (se queda el último). Lo que sí
respeta es una pista de audio con su propia lista (#EXT-X-MEDIA ... URI=): cada una lleva su idioma.

Así que la primera petición de la lista de cada sesión recibe una lista maestra: la imagen en index.m3u8?irelay=v y
cada pista de audio en index.m3u8?irelay=a<n>, con su idioma leído de la PMT del propio stream. Los segmentos de
esas listas son los de siempre filtrados: solo la imagen, o solo esa pista de audio, con la PMT rehecha a juego.
Los subtítulos de texto (fuentes DRM) los manda el relevo como frases con su inicio, final y texto (irelay.cues):
se quitan de la imagen y cada pista va como subtítulos WebVTT con su idioma (index.m3u8?irelay=t<n>), cada segmento
convertido a WebVTT con las frases que trae. Emby solo respeta las pistas aparte si la lista maestra tiene audio
aparte, que aquí siempre lo tiene.
Si algo no está donde se espera (otra versión de Dispatcharr) no se toca nada y se deja constancia en el log."""
from __future__ import annotations

import functools
import logging
import re
import sys

from . import cues

log = logging.getLogger("plugins.intro_relay.hlslang")

WRAP = 1 << 33
MEDIA_FLAG = "irelay"
SEGMENT_LINE = re.compile(r"^([^#\s][^\s?]*\.ts)\s*$", re.M)
READY_WAIT = 65.0          # espera máxima al primer segmento si no se puede leer el margen de Dispatcharr (s)
KEEPALIVE = 45.0           # desde que se pide la lista maestra, el cliente se da por activo hasta este tiempo (s)
KEEPALIVE_STEP = 2.0       # Dispatcharr da por perdido a un cliente HLS a los 12 s sin actividad
READY_LIMIT = 50.0         # espera máxima a la lista de Dispatcharr antes de contestar (s)
HEARTBEAT = "00:00:00.000 --> 00:00:00.040\n\u200b\n\n"   # marca de los segmentos de subtítulos sin frases
PUBLISHED_WAIT = 3.0       # con la lista de Dispatcharr ya publicada, espera máxima a leer sus pistas (s)
VIDEO_TYPES = {0x01, 0x02, 0x10, 0x1B, 0x24, 0x42, 0xEA}
AUDIO_TYPES = {0x03, 0x04, 0x0F, 0x11, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87}
AUDIO_DESCRIPTORS = {0x6A, 0x7A, 0x7B, 0x7C}   # AC-3, E-AC-3, DTS, AAC (stream_type 0x06)
SUBTITLE_DESCRIPTORS = {0x56, 0x59}            # teletexto, subtítulos DVB


def _payload(pkt: bytes) -> int | None:
    off = 4
    if pkt[3] & 0x20:
        off += 1 + pkt[4]
    return off if off < 188 else None


def parse_pmt(data: bytes):
    """(pid de la PMT, paquete de la PMT, [(stream_type, pid, descriptores, clase, idioma)]) del primer programa,
    o None. clase: 'video', 'audio' u 'otro'."""
    pmt_pid = None
    for i in range(0, len(data) - 187, 188):
        pkt = data[i:i + 188]
        if pkt[0] != 0x47 or not pkt[1] & 0x40:
            continue
        pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
        off = _payload(pkt)
        if off is None:
            continue
        off += 1 + pkt[off]          # pointer_field
        sec = pkt[off:]
        if pid == 0 and pmt_pid is None and len(sec) >= 12 and sec[0] == 0x00:
            length = ((sec[1] & 0x0F) << 8) | sec[2]
            for j in range(8, min(3 + length - 4, len(sec) - 3), 4):
                if (sec[j] << 8) | sec[j + 1]:
                    pmt_pid = ((sec[j + 2] & 0x1F) << 8) | sec[j + 3]
                    break
        elif pmt_pid is not None and pid == pmt_pid and len(sec) >= 12 and sec[0] == 0x02:
            length = ((sec[1] & 0x0F) << 8) | sec[2]
            end = min(3 + length - 4, len(sec))
            info = ((sec[10] & 0x0F) << 8) | sec[11]
            j = 12 + info
            streams = []
            while j + 5 <= end:
                stype = sec[j]
                es_pid = ((sec[j + 1] & 0x1F) << 8) | sec[j + 2]
                es_len = ((sec[j + 3] & 0x0F) << 8) | sec[j + 4]
                desc = sec[j + 5:j + 5 + es_len]
                tags, lang = set(), ""
                k = 0
                while k + 2 <= len(desc):
                    tag, dlen = desc[k], desc[k + 1]
                    tags.add(tag)
                    if tag == 0x0A and dlen >= 3 and not lang:
                        lang = desc[k + 2:k + 5].decode("latin-1").strip().lower()
                    k += 2 + dlen
                if stype == 0x06 and 0x05 in tags and cues.MARK in desc:
                    kind = "cues"
                elif stype in VIDEO_TYPES:
                    kind = "video"
                elif stype in AUDIO_TYPES or (stype == 0x06 and tags & AUDIO_DESCRIPTORS
                                              and not tags & SUBTITLE_DESCRIPTORS):
                    kind = "audio"
                elif stype == 0x06 and tags & SUBTITLE_DESCRIPTORS:
                    kind = "subtitle"
                else:
                    kind = "otro"
                streams.append((stype, es_pid, bytes(desc), kind, "".join(c for c in lang if c.isalnum())))
                j += 5 + es_len
            return pmt_pid, pkt, streams
    return None


def audio_languages(data: bytes) -> list[str] | None:
    """Idioma de cada pista de audio, en el orden de la PMT ('' si no lo declara); None si no hay PMT."""
    parsed = parse_pmt(data)
    return None if parsed is None else [lang for *_, kind, lang in parsed[2] if kind == "audio"]


def _crc32(data: bytes) -> int:
    crc = 0xFFFFFFFF
    for byte in data:
        crc ^= byte << 24
        for _ in range(8):
            crc = ((crc << 1) ^ 0x04C11DB7) if crc & 0x80000000 else crc << 1
            crc &= 0xFFFFFFFF
    return crc


def _pmt_packet(original: bytes, pmt_pid: int, streams: list) -> bytes:
    """PMT del mismo programa con solo esas pistas (mismo número de programa y versión)."""
    off = _payload(original)
    off += 1 + original[off]
    old = original[off:]
    body = bytearray(old[3:8])                       # programa, versión, sección
    pcr = streams[0][1] if streams else 0x1FFF
    body += bytes([0xE0 | (pcr >> 8), pcr & 0xFF, 0xF0, 0x00])
    for stype, pid, desc, _kind, _lang in streams:
        body += bytes([stype, 0xE0 | (pid >> 8), pid & 0xFF, 0xF0 | (len(desc) >> 8), len(desc) & 0xFF]) + desc
    length = len(body) + 4
    section = bytes([0x02, 0xB0 | (length >> 8), length & 0xFF]) + bytes(body)
    section += _crc32(section).to_bytes(4, "big")
    header = bytes([0x47, 0x40 | (pmt_pid >> 8), pmt_pid & 0xFF, 0x10 | (original[3] & 0x0F), 0x00])
    return (header + section).ljust(188, b"\xff")


def filter_segment(data: bytes, flag: str) -> bytes:
    """Solo la imagen (flag 'v') o solo la pista de audio n (flag 'a<n>'), con la PMT a juego."""
    parsed = parse_pmt(data)
    if parsed is None:
        return data
    pmt_pid, _pkt, streams = parsed
    if flag == "v":
        keep = [st for st in streams if st[3] in ("video", "subtitle")]     # los subtítulos van con la imagen
    else:
        audio = [st for st in streams if st[3] == "audio"]
        n = int(flag[1:]) if flag[1:].isdigit() else -1
        keep = [audio[n]] if 0 <= n < len(audio) else []
    pids = {st[1] for st in keep}
    out = bytearray()
    for i in range(0, len(data) - 187, 188):
        pkt = data[i:i + 188]
        pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
        if pid == 0 or pid in pids:
            out += pkt
        elif pid == pmt_pid and pkt[1] & 0x40:
            out += _pmt_packet(pkt, pmt_pid, keep)
    return bytes(out)


def segment_webvtt(data: bytes, n: int) -> bytes:
    """Las frases de la pista de texto n de un segmento, como WebVTT con el reloj del propio segmento."""
    parsed = parse_pmt(data)
    if parsed is None:
        return b"WEBVTT\n\n"
    _pmt_pid, _pkt, streams = parsed
    texts = [st for st in streams if st[3] == "cues"]
    video = next((st[1] for st in streams if st[3] == "video"), None)
    pid = texts[n][1] if 0 <= n < len(texts) else None
    base, items, pes = None, [], None

    def done(buf):
        item = cues.parse(bytes(buf)) if buf else None
        if item:
            items.append(item)

    for i in range(0, len(data) - 187, 188):
        pkt = data[i:i + 188]
        p = ((pkt[1] & 0x1F) << 8) | pkt[2]
        if p not in (pid, video):
            continue
        off = _payload(pkt)
        if off is None:
            continue
        if p == video:
            if base is None and pkt[1] & 0x40 and pkt[off:off + 3] == b"\x00\x00\x01" and pkt[off + 7] & 0x80:
                b = pkt[off + 9:off + 14]
                base = ((b[0] >> 1) & 7) << 30 | b[1] << 22 | (b[2] >> 1) << 15 | b[3] << 7 | b[4] >> 1
            continue
        if pkt[1] & 0x40:
            done(pes)
            pes = bytearray(pkt[off:])
        elif pes is not None:
            pes += pkt[off:]
    done(pes)
    if base is None:
        base = items[0][0] if items else 0
    # Una frase que empieza un poco antes que la imagen del segmento (su PES cae justo detrás del corte) no se
    # recorta: el reloj del WebVTT empieza en la más temprana
    for start, _d, _t in items:
        if 0 < (base - start) % WRAP < 10 * 90000:
            base = start
    text = cues.webvtt(base, items)
    if "-->" not in text:
        # Segmento sin frases: una marca invisible (espacio de anchura cero). Sin ella, el ffmpeg de Emby no recibe
        # nada por la pista de subtítulos mientras nadie habla y no cierra sus segmentos, y la lista de subtítulos se
        # queda parada (los reproductores de Apple la dan por muerta). Emby la quita antes de servir el segmento.
        text += HEARTBEAT
    return text.encode()


def master_playlist(langs: list[str], subs: list[str] | None = None) -> str:
    lines = ["#EXTM3U", "#EXT-X-VERSION:3", "#EXT-X-INDEPENDENT-SEGMENTS"]
    names = {"spa": "Español", "eng": "English", "qaa": "Versión original", "cat": "Català", "fre": "Français",
             "fra": "Français", "ger": "Deutsch", "deu": "Deutsch", "ita": "Italiano", "por": "Português"}
    for n, lang in enumerate(subs or []):
        attrs = [f'TYPE=SUBTITLES,GROUP-ID="subs",NAME="{names.get(lang, lang or "Subtítulos")}"']
        if lang:
            attrs.append(f'LANGUAGE="{lang}"')
        attrs.append(f'DEFAULT=NO,AUTOSELECT=YES,URI="index.m3u8?{MEDIA_FLAG}=t{n}"')
        lines.append("#EXT-X-MEDIA:" + ",".join(attrs))
    for n, lang in enumerate(langs):
        attrs = [f'TYPE=AUDIO,GROUP-ID="aud",NAME="{lang or "audio"} {n + 1}"']
        if lang:
            attrs.append(f'LANGUAGE="{lang}"')
        attrs.append("DEFAULT=YES,AUTOSELECT=YES" if n == 0 else "DEFAULT=NO,AUTOSELECT=YES")
        attrs.append(f'URI="index.m3u8?{MEDIA_FLAG}=a{n}"')
        lines.append("#EXT-X-MEDIA:" + ",".join(attrs))
    lines.append('#EXT-X-STREAM-INF:BANDWIDTH=10000000,AUDIO="aud"' + (',SUBTITLES="subs"' if subs else ""))
    lines.append(f"index.m3u8?{MEDIA_FLAG}=v")
    return "\n".join(lines) + "\n"


def _caller_request():
    """La petición de la vista hls_playlist (no se la pasa a _serve_hls_playlist)."""
    frame = sys._getframe(2)
    for _ in range(4):
        if frame is None:
            break
        req = frame.f_locals.get("request")
        if req is not None and hasattr(req, "GET"):
            return req
        frame = frame.f_back
    return None


def _flag(request) -> str | None:
    """'v', 'a<n>' o 't<n>' si la petición es de una de las listas de la lista maestra; None si no."""
    value = request.GET.get(MEDIA_FLAG) if request is not None else None
    if value == "v" or (value and value[0] in "at" and value[1:].isdigit()):
        return value
    return None


def tag_segments(text: str, flag: str) -> str:
    """Añade ?irelay=<flag> a cada segmento de una lista de reproducción."""
    return SEGMENT_LINE.sub(lambda m: f"{m.group(1)}?{MEDIA_FLAG}={flag}", text)


def install() -> bool:
    try:
        from apps.proxy.live_proxy.output.hls import views
    except Exception:
        return False   # versión de Dispatcharr sin salida HLS: nada que hacer
    original = getattr(views, "_serve_hls_playlist", None)
    original_segment = getattr(views, "_serve_hls_segment", None)
    needed = ("_load_live_session", "_resolved_format", "RedisKeys", "RedisClient", "ProxyServer", "HttpResponse",
              "StreamingHttpResponse")
    if original is None or original_segment is None or not all(hasattr(views, n) for n in needed):
        log.warning("no instalo los idiomas en HLS: esta versión de Dispatcharr no tiene lo esperado")
        return False
    # Una versión anterior del plugin ya instalada en este proceso: se sustituye por esta
    while getattr(original, "_irelay", False):
        original = original.__wrapped__
    while getattr(original_segment, "_irelay", False):
        original_segment = original_segment.__wrapped__

    def session(token):
        redis_client = views.ProxyServer.get_instance().redis_client
        loaded, error = views._load_live_session(redis_client, token)
        return (redis_client, loaded) if error is None and loaded else (None, None)

    def touch(token):
        """El cliente cuenta como activo: Dispatcharr cierra el canal si un cliente no pide nada en unos segundos
        («cliente fantasma»), y la lista maestra la da este plugin, no Dispatcharr, así que no contaba."""
        import time

        redis_client, loaded = session(token)
        if loaded is None:
            return False
        channel_id, client_id, _hash = loaded
        keys = getattr(views, "RedisKeys", None)
        key = (keys.client_metadata(channel_id, client_id) if keys is not None and hasattr(keys, "client_metadata")
               else f"live:channel:{channel_id}:clients:{client_id}")
        if redis_client.exists(key):
            redis_client.hset(key, "last_active", str(time.time()))
        return True

    def active_key(token):
        return f"irelay:activo:{token}"

    def mark_active(token):
        """El cliente ya pide listas o segmentos por sí mismo: Dispatcharr ya lo ve activo y el mantenimiento sobra."""
        try:
            views.ProxyServer.get_instance().redis_client.set(active_key(token), "1", ex=600)
        except Exception:
            pass

    def keep_alive(token):
        """Mantiene activo al cliente mientras termina de prepararse (Emby pide la lista maestra al abrir el canal
        y no vuelve a pedir nada hasta que la app empieza a reproducir, a veces más de 15 s después). Se para en
        cuanto el cliente pide algo por sí mismo, o a los KEEPALIVE s: una sesión abandonada no debe seguir viva,
        porque con fuentes que admiten una sola conexión (DRM) bloquearía la siguiente apertura del canal."""
        import time

        def run():
            sleep = getattr(getattr(views, "gevent", None), "sleep", None) or time.sleep
            end = time.monotonic() + KEEPALIVE
            while time.monotonic() < end:
                try:
                    if views.ProxyServer.get_instance().redis_client.exists(active_key(token)):
                        return
                    if not touch(token):
                        return
                except Exception:
                    return
                sleep(KEEPALIVE_STEP)

        spawn = getattr(getattr(views, "gevent", None), "spawn", None)
        try:
            if spawn is not None:
                spawn(run)
            else:
                import threading
                threading.Thread(target=run, daemon=True).start()
        except Exception as e:
            log.warning("no pude mantener activo el cliente HLS: %s", e)

    def published_master(token):
        """(lista maestra con los idiomas o None, si Dispatcharr ya ha publicado su lista para esa sesión).
        Busca las pistas en todos los segmentos de la ventana, del más nuevo al más viejo: no todos traen la PMT."""
        redis_client, loaded = session(token)
        if loaded is None:
            return None, False
        channel_id, _client_id, client_hash = loaded
        fmt = views._resolved_format(client_hash)
        import json

        raw = redis_client.get(views.RedisKeys.output_playlist(channel_id, fmt))
        if not raw:
            return None, False
        try:
            window = json.loads(raw).get("window") or []
        except ValueError:
            window = []
        if not window:
            return None, False
        buffer = views.RedisClient.get_buffer()
        for entry in reversed(window):
            try:
                data = buffer.get(views.RedisKeys.output_buffer_chunk(channel_id, fmt, int(entry["seq"])))
            except Exception:
                data = None
            master = master_for(bytes(data)) if data else None
            if master is not None:
                return master, True
        return None, True

    def fallback_master():
        """Lista maestra sin idiomas: la lista de Dispatcharr tal cual (el parámetro desconocido hace que este
        plugin no la toque, ni a ella ni a sus segmentos)."""
        return f"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-STREAM-INF:BANDWIDTH=10000000\nindex.m3u8?{MEDIA_FLAG}=m\n"

    @functools.wraps(original)
    def serve(token, *args, **kwargs):
        request = _caller_request()
        flag = _flag(request)
        if flag is not None or (request is not None and request.GET.get(MEDIA_FLAG)):
            mark_active(token)
        if flag is not None:
            response = original(token, *args, **kwargs)
            if getattr(response, "status_code", 200) != 200:
                return response
            if getattr(response, "streaming", False):
                chunks = response.streaming_content
                response.streaming_content = (
                    tag_segments(c.decode() if isinstance(c, bytes) else c, flag) for c in chunks)
            else:
                response.content = tag_segments(response.content.decode(), flag).encode()
            return response
        if request is None or request.GET.get(MEDIA_FLAG):
            return original(token, *args, **kwargs)
        if session(token)[1] is None:
            return original(token, *args, **kwargs)        # sesión no válida: la respuesta de Dispatcharr
        # Desde ya y durante KEEPALIVE s el cliente cuenta como activo: Emby pide esta lista al abrir el canal y no
        # vuelve a pedir nada hasta tenerla entera y analizada, y Dispatcharr lo daría por perdido a los 12 s
        keep_alive(token)
        # Si el canal ya tiene segmentos, la lista maestra va al momento (o la de Dispatcharr si no hay imagen y
        # audio que separar, p. ej. una radio)
        master, published = published_master(token)
        if published:
            response = views.HttpResponse(master or fallback_master(), content_type="application/vnd.apple.mpegurl")
            response["Cache-Control"] = "no-cache"
            return response
        # Canal arrancando (p. ej. la primera reproducción de una fuente lenta): se espera a que Dispatcharr publique su
        # lista, como mucho su margen de arranque y nunca más de READY_LIMIT s (el nginx de Dispatcharr corta a los 60 s
        # sin datos). La respuesta va entera y con su longitud, no en streaming: Emby la lee como si fuera el vídeo y
        # espera a que termine, y una respuesta en streaming a veces no se cerraba (con otra sesión del mismo canal
        # abierta), así que Emby se quedaba colgado con la lista ya recibida.
        import time

        budget = READY_WAIT
        try:
            budget = float(views.ConfigHelper.channel_init_grace_period()) + 5.0
        except Exception:
            pass
        budget = min(budget, READY_LIMIT)
        sleep = getattr(getattr(views, "gevent", None), "sleep", None) or time.sleep
        started, since = time.monotonic(), None
        while time.monotonic() - started < budget:
            try:
                touch(token)
                master, published = published_master(token)
            except Exception as e:
                log.warning("lista maestra HLS: %s", e)
                master, published = None, False
            if master is not None:
                break
            if published:
                since = since or time.monotonic()
                if time.monotonic() - since >= PUBLISHED_WAIT:
                    break
            sleep(0.5)
        if master is None:
            log.info("lista maestra HLS sin idiomas (no se pudieron leer las pistas a tiempo)")
        keep_alive(token)
        response = views.HttpResponse(master or fallback_master(), content_type="application/vnd.apple.mpegurl")
        response["Cache-Control"] = "no-cache"
        return response

    def master_for(data):
        """Lista maestra con el idioma de cada pista, si ese segmento trae imagen y audio; None si no."""
        try:
            parsed = parse_pmt(data) if data else None
        except Exception as e:
            log.warning("no pude leer las pistas del stream HLS: %s", e)
            return None
        kinds = [kind for *_, kind, _lang in parsed[2]] if parsed else []
        if "video" not in kinds or "audio" not in kinds:
            return None
        return master_playlist([lang for *_, kind, lang in parsed[2] if kind == "audio"],
                               [lang for *_, kind, lang in parsed[2] if kind == "cues"])

    @functools.wraps(original_segment)
    def serve_segment(token, seq, *args, **kwargs):
        mark_active(token)
        response = original_segment(token, seq, *args, **kwargs)
        flag = _flag(_caller_request())
        if flag is None or getattr(response, "status_code", 200) != 200:
            return response
        try:
            if flag[0] == "t":
                response.content = segment_webvtt(bytes(response.content), int(flag[1:]))
                response["Content-Type"] = "text/vtt; charset=utf-8"
            else:
                response.content = filter_segment(bytes(response.content), flag)
        except Exception as e:
            log.warning("no pude separar el segmento %s (%s): %s", seq, flag, e)
        return response

    serve._irelay = True
    serve_segment._irelay = True
    views._serve_hls_playlist = serve
    views._serve_hls_segment = serve_segment
    log.info("idiomas de las pistas en la salida HLS instalados (una lista por pista)")
    return True
